#include "shared_data.h"
#include "modulos\uart\uart.h"
#include "var_c30.h"


Dados dados;

unsigned char *get_dados( )
{
    return ( unsigned char * )&dados;
}

unsigned int size_of_dados( )
{
    return sizeof( dados );
}

unsigned int size_of_setup( )
{
    return sizeof( dados.setup );
}

unsigned long get_alarme_superior( )
{
    return dados.setup.alarme_superior;
}

unsigned long get_alarme_inferior( )
{
    return dados.setup.alarme_inferior;
}

unsigned long get_calibracao_ad_zero( )
{
    return dados.setup.calibracao.ad.zero;
}

unsigned long get_calibracao_ad_fs( )
{
    return dados.setup.calibracao.ad.fs;
}

void set_alarme_superior( unsigned long x )
{
    dados.setup.alarme_superior = x;
}

void set_alarme_inferior( unsigned long x )
{
    dados.setup.alarme_inferior = x;
}

void set_calibracao_ad_zero( unsigned long x )
{
    dados.setup.calibracao.ad.zero = x;
}

void set_calibracao_ad_fs( unsigned long x )
{
    dados.setup.calibracao.ad.fs = x;
}

void init_shared_data( void )
{
    set_alarme_superior( 0 );
    set_alarme_inferior( 0 );
}
