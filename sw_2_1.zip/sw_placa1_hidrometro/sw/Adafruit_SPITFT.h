
#ifndef _ADAFRUIT_SPITFT_
#define _ADAFRUIT_SPITFT_

#include "fw/fw.h"
//#include "Adafruit_GFX.h"

#define SSD1306_128_64
// #define SSD1306_128_32
// #define SSD1306_96_16
#define _width 128
#define _height 64

void      init_oled(void);

// Required Non-Transaction
void      drawPixel(int x, int y,unsigned int color);

// Transaction API
void      startWrite(void);
void      endWrite(void);
void      writePixelxy(int x, int y,unsigned int color);
void      writeFillRect(int x, int y, int w, int h,unsigned int color);
void      writeFastVLine(int x, int y, int h,unsigned int color);
void      writeFastHLine(int x, int y, int w,unsigned int color);

// Transaction API not used by GFX
void    setAddrWindow(int x, int y, int w, int h);
void      writePixel(unsigned int color);
void writePixels(unsigned int * colors, unsigned long len);
void      writeColor(unsigned int color,unsigned long len);
void      pushColor(unsigned int color);

// Recommended Non-Transaction
void      drawFastVLine(int x, int y, int h,unsigned int color);
void      drawFastHLine(int x, int y, int w,unsigned int color);
void      fillRect(int x, int y, int w, int h,unsigned int color);


void      drawRGBBitmap(int x, int y,unsigned int *pcolors, int w, int h);

unsigned int  color565(unsigned char r, unsigned char g, unsigned char b);

void        writeCommand(unsigned char cmd);
void        spiWrite(unsigned char dado);
unsigned char     spiRead(void);

#endif
