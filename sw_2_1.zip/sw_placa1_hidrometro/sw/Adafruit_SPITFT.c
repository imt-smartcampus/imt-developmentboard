/***************************************************
  This is our library for generic SPI TFT Displays with
  address windows and 16 bit color (e.g. ILI9341, HX8357D, ST7735...)

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution
 ****************************************************/

#include "Adafruit_SPITFT.h"
#include "Adafruit_SPITFT_Macros.h"

// Pass 8-bit (each) R,G,B, get back 16-bit packed color
unsigned int color565(unsigned char r, unsigned char g, unsigned char b)
{
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | ((b & 0xF8) >> 3);
}

void init_oled(void)
{
    // Control Pins
    TRIS_OLED_DC = 0;
    OLED_DC = 0;
    //TRIS_OLED_CS = 0;
    //OLED_CS = 1;

    // toggle RST low to reset
    //TRIS_OLED_RESET = 0;
    //OLED_RESET = 1;
    //delay_ms(100);
    //OLED_RESET = 0;;
    //delay_ms(100);
    //OLED_RESET = 1;;
    //delay_ms(200);
}
//macros

/*
 * Transaction API
 * */

void startWrite(void){
    //SPI_BEGIN_TRANSACTION();
    //OLED_CS = 0;;
}

void endWrite(void){
    //OLED_CS = 1;
    //SPI_BEGIN_TRANSACTION
}

void writeCommand(unsigned char cmd){
    OLED_DC = 0;
    spiWrite(cmd);
    OLED_DC = 1;
}

void pushColor(unsigned int color)
{
  startWrite();
  spiWrite(color>>8);
  spiWrite(color);
  endWrite();
}


void writePixel(unsigned int color)
{
  spiWrite(color>>8);
  spiWrite(color);
}

void writePixels(unsigned int * colors, unsigned long len)
{
    unsigned long i;

    for(i=0; i<(len * 2); i+=2)
    {
        SSPI_WRITE(((unsigned char*)(colors))[i+1]);
        SSPI_WRITE(((unsigned char*)(colors))[i]);
    }
}

void writeColor(unsigned int color, unsigned long len)
{

unsigned char hi = color >> 8, lo = color;
unsigned long t;

    for ( t=len; t; t--){
        spiWrite(hi);
        spiWrite(lo);
    }

}

void writePixelxy(int x, int y, unsigned int color)
{
    if((x < 0) ||(x >= _width) || (y < 0) || (y >= _height)) return;
    setAddrWindow(x,y,1,1);
    writePixel(color);
}

void writeFillRect(int x, int y, int w, int h, unsigned int color)
{
    if((x >= _width) || (y >= _height)) return;
    int x2 = x + w - 1, y2 = y + h - 1;
    if((x2 < 0) || (y2 < 0)) return;

    // Clip left/top
    if(x < 0) {
        x = 0;
        w = x2 + 1;
    }
    if(y < 0) {
        y = 0;
        h = y2 + 1;
    }

    // Clip right/bottom
    if(x2 >= _width)  w = _width  - x;
    if(y2 >= _height) h = _height - y;

    long len = (long)w * h;
    setAddrWindow(x, y, w, h);
    writeColor(color, len);
}

void writeFastVLine(int x, int y, int h, unsigned int color)
{
    writeFillRect(x, y, 1, h, color);
}

void writeFastHLine(int x, int y, int w, unsigned int color)
{
    writeFillRect(x, y, w, 1, color);
}

void drawPixel(int x, int y, unsigned int color)
{
    startWrite();
    writePixelxy(x, y, color);
    endWrite();
}

void drawFastVLine(int x, int y, int h, unsigned int color)
{
    startWrite();
    writeFastVLine(x, y, h, color);
    endWrite();
}

void drawFastHLine(int x, int y, int w, unsigned int color)
{
    startWrite();
    writeFastHLine(x, y, w, color);
    endWrite();
}

void fillRect(int x, int y, int w, int h, unsigned int color)
{
    startWrite();
    writeFillRect(x,y,w,h,color);
    endWrite();
}

// Adapted from https://github.com/PaulStoffregen/ILI9341_t3
// by Marc MERLIN. See examples/pictureEmbed to use this.
// 5/6/2017: function name and arguments have changed for compatibility
// with current GFX library and to avoid naming problems in prior
// implementation.  Formerly drawBitmap() with arguments in different order.
void drawRGBBitmap(int x, int y,unsigned int *pcolors, int w, int h)
{

    int x2, y2; // Lower-right coord
    if(( x             >= _width ) ||      // Off-edge right
       ( y             >= _height) ||      // " top
       ((x2 = (x+w-1)) <  0      ) ||      // " left
       ((y2 = (y+h-1)) <  0)     ) return; // " bottom

    int bx1=0, by1=0, // Clipped top-left within bitmap
            saveW=w;      // Save original bitmap width value
    if(x < 0) { // Clip left
        w  +=  x;
        bx1 = -x;
        x   =  0;
    }
    if(y < 0) { // Clip top
        h  +=  y;
        by1 = -y;
        y   =  0;
    }
    if(x2 >= _width ) w = _width  - x; // Clip right
    if(y2 >= _height) h = _height - y; // Clip bottom

    pcolors += by1 * saveW + bx1; // Offset bitmap ptr to clipped top-left
    startWrite();
    setAddrWindow(x, y, w, h); // Clipped area
    while(h--) { // For each (clipped) scanline...
      writePixels(pcolors, w); // Push one (clipped) row
      pcolors += saveW; // Advance pointer by one full (unclipped) line
    }
    endWrite();
}

