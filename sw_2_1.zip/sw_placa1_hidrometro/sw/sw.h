/****************************************************************************************\
 * 	                         software LORA node                                       *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#ifndef	_SW_H_
#define	_SW_H_

#include "../fw/fw.h"

// configura��es de aplica��o em **** app.h ****

/********************************************\
 *                Constantes                *
\********************************************/

// Op��es para desenho:
#define ESQUERDA                        0
#define CENTRO                          1
#define DIREITA                         2

/********************************************\
 *                  Flags:                  *
\********************************************/

#define FS_TX_LORA_OK                           flags_sw.bit0  // Inicia transmiss�o de pacote em UART1
#define FS_TX_MAC_OK                            flags_sw.bit1  // Inicia transmiss�o de pacote em UART1
#define FS_TX_LORA_ERR                          flags_sw.bit2  // Inicia transmiss�o de pacote em UART1
#define FS_TX_LORA_BUSY                         flags_sw.bit3  // Inicia transmiss�o de pacote em UART1
#define FS_TX_LORA_INV                          flags_sw.bit4  // Inicia transmiss�o de pacote em UART1
#define FS_RX_MAC_OK                            flags_sw.bit5  // Inicia transmiss�o de pacote em UART1
#define FS_JOIN_ACCEPTED                        flags_sw.bit6  // Inicia transmiss�o de pacote em UART1
#define FS_PERMITE_SLEEP                        flags_sw.bit7  // Inicia transmiss�o de pacote em UART1
#define FS_TX_NOT_JOINED                        flags_sw.bit8  // Inicia transmiss�o de pacote em UART1
#define FS_TX_NOT_FREE_CH                       flags_sw.bit9  // Inicia transmiss�o de pacote em UART1
#define FS_GET_STATUS                           flags_sw.bit10  // Inicia transmiss�o de pacote em UART1
#define FS_LORA_INICIADO                        flags_sw.bit11  // Inicia transmiss�o de pacote em UART1
#define FS_GET_FCNT                             flags_sw.bit12  // Inicia transmiss�o de pacote em UART1
#define FS_GET_VCC                              flags_sw.bit13  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_INICIADO                         flags_sw.bit14  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_POSICAO_OK                       flags_sw.bit15  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_DATA_OK                          flags_sw.bit16  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_UTC_OK                           flags_sw.bit17  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_FINALIZADO                       flags_sw.bit18  // Inicia transmiss�o de pacote em UART1
#define FS_GPS_REQUEST                          flags_sw.bit19  // Inicia transmiss�o de pacote em UART1
#define FS_UART1_INICIADO                       flags_sw.bit20  // Inicia transmiss�o de pacote em UART1
#define FS_UART1_FINALIZADO                     flags_sw.bit21  // Inicia transmiss�o de pacote em UART1
#define FS_UART1_DATA_OK                        flags_sw.bit22  // Inicia transmiss�o de pacote em UART1
#define FS_UART1_START_SM                       flags_sw.bit23  // Inicia transmiss�o de pacote em UART1
#define FS_UART3_INICIADO                       flags_sw.bit24  // Inicia transmiss�o de pacote em UART1
#define FS_UART3_FINALIZADO                     flags_sw.bit25  // Inicia transmiss�o de pacote em UART1
#define FS_UART3_DATA_OK                        flags_sw.bit26  // Inicia transmiss�o de pacote em UART1
#define FS_UART3_START_SM                       flags_sw.bit27  // Inicia transmiss�o de pacote em UART1

extern union unsigned_long flags_sw;
#define TIMEOUT_POWERSAVE                       45     // 45 segundos

typedef enum
{
CONTROL_OFF,
CONTROL_INICIAR,
CONTROL_ON,
} SM_CONTROL;


typedef enum
{
    LORA_OCIOSO = 0,
    LORA_INICIALIZA,
    LORA_TX,
    LORA_GET_FCNT,
    LORA_SLEEP,
    LORA_AGUARDA_RESPOSTA,
    LORA_GET_STATUS,
    LORA_FINALIZA
}Sm_lora;
extern Sm_lora sm_lora;

typedef enum
{
    GPS_OCIOSO = 0,
    GPS_INICIALIZA,
    GPS_LOCALIZANDO,
    GPS_FINALIZA
}Sm_gps;
extern Sm_gps sm_gps;

typedef enum
{
    UART3_OCIOSO = 0,
    UART3_INICIALIZA,
    UART3_AGUARDANDO_RX,
    UART3_FINALIZA
}Sm_uart3;
extern Sm_uart3 sm_uart3;

typedef enum
{
    UART1_OCIOSO = 0,
    UART1_INICIALIZA,
    UART1_AGUARDANDO_RX,
    UART1_FINALIZA
}Sm_uart1;
extern Sm_uart1 sm_uart1;

/****************************************************************************************\
 *   		                 Defini��o de estruturas                    		        *
\****************************************************************************************/

void inicializa_sw( void );

unsigned long trata_pct_uart1_rx( void );
unsigned long trata_pct_uart3_rx( void );
unsigned long trata_pct_lora_rx( void );
unsigned long busca_tam_numero_buffer( unsigned char *buffer );
void sm_processo_uart1( void );
void sm_processo_uart3( void );

void sm_processo_lora( void );  // UART2
void sm_processo_gps ( void ); // UART1
void sm_processo_rfid ( void );// UART1
void sm_processo_encoder( void );  //
void sm_processo_buzzer(void);
void sm_processo_pid( void );

void atualiza_pwm_1 ( unsigned int esforco );
void configura_pwm_1( unsigned int dc);
unsigned char verifica_estabilidade( unsigned char opcao );

void le_setup( void );
float le_dado_setup( unsigned char command );
unsigned char salva_setup( void );
void carrega_setup_default( void );
void atualiza_registro_setup (unsigned char command, float dado );


void trata_power_save( void );
void atualiza_dados_gps( void );

void escreve_texto_lcd_flash( int x, int y, const unsigned char *buffer, unsigned char size, unsigned int color  );
void escreve_texto_lcd( int x, int y, unsigned char *buffer, unsigned char size, unsigned int color  );

void testdrawbitmap(const unsigned char *bitmap, unsigned char w, unsigned char h);
void testdrawchar(void);
void testdrawcircle(void);
void testfillrect(void);
void testdrawtriangle(void);
void testfilltriangle(void);
void testdrawroundrect(void);
void testfillroundrect(void);
void testdrawrect(void);
void testdrawline();
void testscrolltext(void);

#if( TRACE_HABILITADO == SIM )
void tx_valor_trace( long valor, unsigned char casas_decimais );
#endif

/****************************************************************************************\
 * 	  	                      Macros              		        *
\****************************************************************************************/

/****************************************************************************************\
 * 	  	                      Mensagens de error ou warning               		        *
\****************************************************************************************/

#if( TIPO_SW == SW_RELEASE )
#if( TRACE_HABILITADO == SIM )
#warning "TRACE est� ativado em modo RELEASE"
#endif
#else
#warning "Modo TESTE DE SW habilitado"
#endif

#endif //_SW_H_ 
