#ifndef _ADAFRUIT_GFX_H
#define _ADAFRUIT_GFX_H


#include "gfxfont.h"
#include "..\fw\fw.h"

  void Adafruit_GFX(int w, int h); // Constructor

  // This MUST be defined by the subclass:
   void drawPixel(int x, int y, unsigned int color);

  // TRANSACTION API / CORE DRAW API
  // These MAY be overridden by the subclass to provide device-specific
  // optimized code.  Otherwise 'generic' versions are used.
   void startWrite(void);
   void writePixel(int x, int y,unsigned int color);
   void writeFillRect(int x, int y, int w, int h,unsigned int color);
   void writeFastVLine(int x, int y, int h,unsigned int color);
   void writeFastHLine(int x, int y, int w,unsigned int color);
   void writeLine(int x0, int y0, int x1, int y1,unsigned int color);
   void endWrite(void);

  // CONTROL API
  // These MAY be overridden by the subclass to provide device-specific
  // optimized code.  Otherwise 'generic' versions are used.
   void setRotation(char r);
  // void invertDisplay(bool i);

  // BASIC DRAW API
  // These MAY be overridden by the subclass to provide device-specific
  // optimized code.  Otherwise 'generic' versions are used.
   
    // It's good to implement those, even if using transaction API
    void drawFastVLine(int x, int y, int h, unsigned int color);
    void drawFastHLine(int x, int y, int w, unsigned int color);
    void fillRect(int x, int y, int w, int h, unsigned int color);
    void fillScreen(unsigned int color);
    // Optional and probably not necessary to change
    void drawLine(int x0, int y0, int x1, int y1, unsigned int color);
    void drawRect(int x, int y, int w, int h, unsigned int color);

  // These exist only with Adafruit_GFX (no subclass overrides)
  void drawCircle(int x0, int y0, int r,unsigned int color);
    void drawCircleHelper(int x0, int y0, int r, char cornername, unsigned int color);
    void fillCircle(int x0, int y0, int r,unsigned int color);
    void fillCircleHelper(int x0, int y0, int r, char cornername, int delta,unsigned int color);
    void drawTriangle(int x0, int y0, int x1, int y1,      int x2, int y2,unsigned int color);
    void fillTriangle(int x0, int y0, int x1, int y1,      int x2, int y2,unsigned int color);
    void drawRoundRect(int x0, int y0, int w, int h,      int radius,unsigned int color);
    void fillRoundRect(int x0, int y0, int w, int h,      int radius,unsigned int color);
//    drawBitmap(int x, int y, const char bitmap[],      int w, int h, int color),
//    drawBitmap(int x, int y, const char bitmap[],      int w, int h, int color, int bg),
    void drawBitmap(int x, int y, const unsigned char *bitmap,      int w, int h,unsigned int color);
//    drawBitmap(int x, int y, char *bitmap,      int w, int h, int color, int bg),
    void drawXBitmap(int x, int y, const unsigned char bitmap[],      int w, int h,unsigned int color);
    void drawGrayscaleBitmap(int x, int y, const unsigned char bitmap[],      int w, int h);
//    drawGrayscaleBitmap(int x, int y, char *bitmap,      int w, int h),
//    drawGrayscaleBitmap(int x, int y,      const char bitmap[], const char mask[],      int w, int h),
//    drawGrayscaleBitmap(int x, int y,      char *bitmap, char *mask, int w, int h),
    void drawRGBBitmap(int x, int y,  const unsigned int bitmap[], int w, int h) ;
//    void drawRGBBitmap(int x, int y, const unsigned char *bitmap,      int w, int h);
//    drawRGBBitmap(int x, int y,      const int bitmap[], const char mask[],      int w, int h),
//    drawRGBBitmap(int x, int y,      int *bitmap, char *mask, int w, int h),
    void drawChar(int x, int y, unsigned char c,  unsigned int color, unsigned int bg, unsigned char size);
    void setCursor(int x, int y);
    void setTextColor(int c);
//    setTextColor(int c, int bg),
    void setTextSize(char s);
    void  setTextWrap(char w);
    void cp437(char x);
    void setFont(const GFXfont *f  );
    void getTextBounds(char *string, int x, int y,      int *x1, int *y1, int *w, int *h);
//     void getTextBounds(const __FlashStringHelper *s, int x, int y, int *x1, int *y1, int *w, int *h);

//
   void write(char);

  int height(void);
  int width(void);

  unsigned char getRotation(void);

  // get current cursor position (get rotation safe maximum values, using: width() for x, height() for y)
  int getCursorX(void);
  int getCursorY(void);

  void    charBounds(char c, int *x, int *y, int *minx, int *miny, int *maxx, int *maxy);

extern  int    _width;
extern  int   _height; // Display w/h as modified by current rotation
extern  int   cursor_x;
extern  int   cursor_y;
extern  int    textcolor;
extern  int textbgcolor;
extern  char    textsize;
extern  char  rotation;
extern  char    wrap;   // If set, 'wrap' text at right edge of display
extern  char  _cp437; // If set, use correct CP437 charset (default is off)
extern  GFXfont    *gfxFont;
extern char vccstate;
#endif // _ADAFRUIT_GFX_H
