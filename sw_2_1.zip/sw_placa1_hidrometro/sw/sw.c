/****************************************************************************************\
 * 	                            softeware LORA node                                  *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "sw.h"

/****************************************************************************************\
 *   		                 Defini��o de vari�veis de flag             		        *
\****************************************************************************************/

union unsigned_long flags_sw;                       // Flags de software

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do software em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:
SM_CONTROL sm_control = CONTROL_OFF;

/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do software em mem�ria de dados          	*
\****************************************************************************************/
#define TEXTO_IMT_1     "INSTITUTO MAUA"
#define TEXTO_IMT_2     "DE TECNOLOGIA"
#define TEXTO_VAL       "=> "
#define TEXTO_COR       "Cor"
#define TEXTO_TEMP      "oC"

// - Globais ao sistema:

Sm_lora sm_lora;
Sm_uart1 sm_uart1;
Sm_gps sm_gps;
Sm_uart3 sm_uart3;

/****************************************************************************************\
 *           		                  Fun��o principal   		                        *
\****************************************************************************************/
int main( void )
{
    static unsigned char contador = 0;
    unsigned char aux = 0;

    #if( TIPO_SW == SW_TESTE )
    testa_firmware();
    #endif

    // modulo de deep sleep - inicio
    flags_sw.value = 0;
    init_shared_data();

    aux = pic_init();
    if (aux != 0 ) // voltou de um sleep?
    {
        #ifdef ENVIA_RFID     //manda RFID             "0Frrrrrrrr"
        unsigned char i = 0;
        for ( i = 0; i < sizeof(dados.rfid); i++)
        {
            dados.rfid[i] = 0x30;
        }
        #endif

        if (aux == 2)
        {
            FS_LORA_INICIADO = 1;
            inicializa_int0();
            IFS3bits.RTCIF = 0;
        }
        if (aux == 5)
        {
            FS_LORA_INICIADO = 1;
            TRISGbits.TRISG9 = 0;
            LED_STATUS = 1;
            delay_us(100);
            LED_STATUS = 0;
            inicializa_int0();

            #ifdef ENVIA_RFID     //manda RFID             "0Frrrrrrrr"
            #else
                dados.contador_permanente++; // debug simplesmente inc vari�vel para uso geral, no caso para contar toda entra no sleep
                dados.pos_encoder = 1;

                #ifndef  INT0_TXLORA_SEMPRE
                trata_power_save();     // dorme por 60 segundos
                #endif
                #ifdef ENVIA_ENCODER
                dados.inicializacao_especial = 1;
                #endif
            #endif
        }
    }

    inicializa_sw();
    TRISF  = TRISF & 0xFFFB;     
    RST_GPS = 0;
    FS_GPS_FINALIZADO = 0;    // modulo de deep sleep - fim
    FS_UART3_FINALIZADO = 0;    // modulo de deep sleep - fim
    FS_UART3_START_SM = 1;
    FS_GPS_REQUEST = 0;            // for�a ler gps

    #ifdef DISPLAY_SPI
        inicializa_lcd();
        escreve_texto_lcd_flash( 20, 0, (const unsigned char *)TEXTO_IMT_1,1, WHITE);
        escreve_texto_lcd_flash( 20, 10,(const unsigned char *)TEXTO_IMT_2,1, WHITE);
        display();
    #endif

    while ( dados.inicializacao_especial )
    {
        ClrWdt();
         // ESPERANDO CAPTURE QUE PROCESSA O sm_processo_encoder();
        #ifdef ENVIA_ENCODER
            sm_processo_encoder();
        #endif
        if( F_1000MS )
        {
            F_1000MS = 0;
            contador++;
            if (contador >= 10 ) //10 segundos
            {
                contador = 0;
                // se deu 5 segundo e n�o apertou o Int0 dorme novamente.
                trata_power_save();     // dorme por 60 segundos
            }
        }
    }

    while( 1 )
    {
        ClrWdt();
        if( F_1MS )
        {
            F_1MS = 0;
            #ifdef ATIVA_PID
                sm_processo_pid();
            #endif
        }
        if( F_10MS )
        {
            F_10MS = 0;
            if (FS_PERMITE_SLEEP)
            {
                FS_PERMITE_SLEEP = 0;
                trata_power_save();     // dorme por 60 segundos
            }            
            sm_processo_uart3();        // PINOS DE EXPANS�O (SONAR OU SMARTMETER NBR14522)
            sm_processo_uart1();        // PINO 50 (GPS OU RFID)
            sm_processo_lora();     //inicializa e a cada minuto manda uma msg

            atualiza_temperatura_ntc10k(); // le ad e usa calculo para ntc
            atualiza_temperatura_pt100();   // le ad e usa calculo para pt100
            atualiza_4_20ma();              // le ad e usa calculo para 4 a 20mA

            #ifdef ENVIA_ENCODER
                sm_processo_encoder();
            #endif

            #ifdef BUZZER_ON_RB15
                sm_processo_buzzer();
            #endif
        }
    }
    return( 0 );
}

void sm_processo_encoder(void)
{
    if (dados.pos_encoder < 2)
    {
        LED_1 = 0;
        LED_2 = 0;
        LED_3 = 0;
        dados.selecao_encoder = 0;
    }
    else if (dados.pos_encoder < 10)
    {
        LED_1 = 1;
        LED_2 = 0;
        LED_3 = 0;
        dados.selecao_encoder = 1;
    }
    else if (dados.pos_encoder < 20)
    {
        LED_1 = 0;
        LED_2 = 1;
        LED_3 = 0;
        dados.selecao_encoder = 2;
    }
    else
    {
        LED_1 = 0;
        LED_2 = 0;
        LED_3 = 1;
        dados.selecao_encoder = 3;
    }
}

void sm_processo_buzzer(void)
{
    static unsigned char old_pos = -1;
    unsigned char pos;

    pos = 0;
    if (PORTFbits.RF6 == 1)
    {
        pos = 1;
    }

    switch(pos)
    {
        case 0:
            configura_pwm_hw( PWM_HW_0 , PWM_HW_DUTY );  // liga
            break;
        case 1:
            configura_pwm_hw( PWM_HW_0 , 0);  //desliga
            break;
        default:
            break;
    }
    old_pos = pos;

    dados.pos_encoder = pos;
}
/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/
/****************************************************************************************\
 * trata_power_save                                                 	                *
 * Rotina de tratamento para entrar em sleep e diminuir o consumo 		                *
 *                                                                                      *
 * Par�metros: void														                *
 * Retorno   : void														                *
\****************************************************************************************/
void trata_power_save( void )
{

        unsigned int aux = 0;
        DSGPR0 = (unsigned int)dados.contador_permanente;
        DSGPR0 = (unsigned int)dados.contador_permanente;
        aux = (( 0X00FF0000 & dados.contador_permanente)>>16);
        aux += ((0x00FF & dados.upctr)<<8);
        DSGPR1 = aux;
        DSGPR1 = aux;
        // device continues operation here after it wakes from Sleep by the Change Notice Pin
#ifndef NUNCA_DORME
        inicializa_adc(ADC_OFF);
        desliga_perifericos();
        desliga_app();

    #if( defined( MODO_DEBUG ) )
        unsigned int i = 0;
        for (i = 0; i < 30; i++)   // 60 segundos
        {
            delay_ms(1000);
        }
    #else
        CLKDIV = 0x0700;    /* set for 4MHz FRC oscillator */
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        DSCON = 0;
        DSCON = 0;
        RCON = 0;
        RCON = 0;
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        DSCONbits.DSEN = 1; //set the deep sleep enable bit
        DSCONbits.DSEN = 1;
        DSCONbits.DSEN = 1;
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        DSCONbits.DSEN = 1;
        DSCONbits.DSEN = 1; //set the deep sleep enable bit
        DSCONbits.DSEN = 1;
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Sleep();
        // acordamos ap�s watchdog timer
        Nop();
        Nop();
        Nop();
    #endif

        // se for DEEP SLEEP N�O CAI AQUI NO WAKE UP, CAI NO 0X0000 ISTO � NO VOID MAIN (VOID)
        dados.upctr = ((0xFF00 & DSGPR1)>>8);
        dados.contador_permanente = DSGPR0;
        dados.contador_permanente += ((long)(0x00FF & DSGPR1)<<16);
        TRISF  = TRISF & 0xFFFB;
        DSCONbits.RELEASE = 0;

        T2CONbits.TON = 1;                              // Liga Timer2
        T4CONbits.TON = 1;                              // Liga Timer3
        liga_app();         // liga transistor de alimenta��o 3v3 para
        liga_perifericos();
        FS_GPS_FINALIZADO = 0;
#endif

}

/****************************************************************************************\
 * sm_processo_lora                                                 	                *
 * Rotina de maquina de estado pra comunica��o com m�dulo LORA 		                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void sm_processo_lora( void )
{
#define     TIMEOUT_AGUARDA_RESPOSTA_LORA           3000           // 50 segundos
#define     TIMEOUT_TX_MIN                          3           // 30 milisegundos
#define     TIMEOUT_TX                              600           // 6 segundos
#define     TIMEOUT_SM                              30           // 300 milisegundos
#define     QTD_RESP_DEFAULT                        1
#define     QTD_RESP_TX                             2              //1 para tx mac UNCNF / 2 para cnf
#define     MAX_TENTATIVAS_TX                       2
#define     MAX_ERROS                               2       // maior que 1 = 2

    static unsigned char sub_state_lora = 0;
    static Sm_lora proximo_state_lora = LORA_OCIOSO;
    static Sm_lora ultimo_state_lora = LORA_OCIOSO;
    static unsigned int timeout_aguarda_resposta_lora = 0;
    static unsigned long timeout_tx = TIMEOUT_TX_MIN;
    static unsigned int timeout_sm = 200;               // 2s usado em timer de maquina de estado sem delay
    static unsigned int num_resp_tx = 0;
    static unsigned int qtd_resp_tx = QTD_RESP_DEFAULT;
    static unsigned char num_tentativas = 0;
    static unsigned char num_erros = 0;
    static unsigned long status = 0;
    static unsigned int mac_state = 0;
    unsigned long aux_long = 0;
    unsigned char aux = 0;
    unsigned char i = 0;


    switch(sm_lora)
    {
        case LORA_OCIOSO:
            timeout_tx--;
            if (timeout_tx > 0x7FFFFFF)
            {
                timeout_tx = 0;
            }
            if (timeout_tx == 0)
            {
                timeout_tx = TIMEOUT_TX;
                timeout_aguarda_resposta_lora = 0;
                qtd_resp_tx = QTD_RESP_DEFAULT;
                proximo_state_lora = LORA_INICIALIZA;
                ultimo_state_lora = LORA_INICIALIZA;
                sm_lora = LORA_INICIALIZA;
                num_resp_tx = 0;
                num_tentativas = 0;
                if (FS_LORA_INICIADO)
                {
                    sub_state_lora = 8;
                }
                else
                {
                    sub_state_lora = 0;
                }
            }

            if( F_PORTA_LORA_PCT_RX )       // apenas busca dados e atualiza flags
            {
                F_PORTA_LORA_PCT_RX = 0;
                trata_pct_lora_rx();
            }
            break;
        case LORA_INICIALIZA:
            switch (sub_state_lora)
            {
                case 0:
                    insere_string_flash_uart_2((const unsigned char *)"sys factoryRESET\r\n");
                    tx_pct_uart_2();
                    delay_ms(3000);
                    dados.upctr = 1;

                    // **** usar para pegar o hardware EUI
                    insere_string_flash_uart_2((const unsigned char *)"sys get hweui\r\n");
                    F_PORTA_LORA_PCT_RX = 0;
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    tx_pct_uart_2();
                    delay_ms(100);

                    #ifndef ESPECIFICAR_EUI_PROPRIO
                    insere_string_flash_uart_2((const unsigned char *)"mac set deveui ");
                    insere_bytes_uart_2((unsigned char *)&uart_2.rx[0],16);
                    insere_string_flash_uart_2((const unsigned char *)"\r\n");
                    #else   // usar para especificar um EUI pr�definido SENAO FOR PREDEFINIDO COMENTAR
                    insere_string_flash_uart_2((const unsigned char *)"mac set deveui ");
                    insere_string_flash_uart_2((const unsigned char *)EUI_PROPRIO);
                    insere_string_flash_uart_2((const unsigned char *)"\r\n");
                    #endif
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    delay_ms(100);

                    for (i = 0; i < 72; i++)
                    {
                        insere_string_flash_uart_2((const unsigned char *)"mac set ch status "); // tempo em segundos entre tx zero
                        dec_para_ascii((long)i,buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);          //2byteS  //3
                        insere_string_flash_uart_2((const unsigned char *)" off\r\n");
                        uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                        F_PORTA_LORA_PCT_RX = 0;
                        tx_pct_uart_2();
                        delay_ms(40);
                    }
                    for (i = 0; i < 8; i++) // set subband
                    {
                        insere_string_flash_uart_2((const unsigned char *)"mac set ch status "); // tempo em segundos entre tx zero
                        dec_para_ascii((long)i,buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);          //2byteS  //3
                        insere_string_flash_uart_2((const unsigned char *)" on\r\n");
                        uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                        F_PORTA_LORA_PCT_RX = 0;
                        tx_pct_uart_2();
                        delay_ms(40);
                    }

                    insere_string_flash_uart_2((const unsigned char *)"mac set appeui 1111111111111111\r\n");
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();                
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    proximo_state_lora = LORA_INICIALIZA;
                    ultimo_state_lora = LORA_INICIALIZA;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 1:
                    insere_string_flash_uart_2((const unsigned char *)"mac forceENABLE\r\n"); // tempo em segundos entre tx zero
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 2:
                    insere_string_flash_uart_2((const unsigned char *)"sys get hweui\r\n");
                    F_PORTA_LORA_PCT_RX = 0;
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    tx_pct_uart_2();
                    delay_ms(300);

                    #ifndef ESPECIFICAR_DEVADDR_PROPRIO // **** usar para especificar um devaddr pr�definido INICIO
                    insere_string_flash_uart_2((const unsigned char *)"mac set devaddr ");
                    insere_bytes_uart_2((unsigned char *)&uart_2.rx[8],8);
                    insere_string_flash_uart_2((const unsigned char *)"\r\n");
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"mac set devaddr "); // HIDRO1
                    insere_string_flash_uart_2((const unsigned char *)DEVADDR_PROPRIO); // HIDRO1
                    insere_string_flash_uart_2((const unsigned char *)"\r\n"); // HIDRO1
                    #endif // **** usar para especificar um devaddr pr�definido FIM
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 3:
                    //Reseta o m�dulo LoRa
                    insere_string_flash_uart_2((const unsigned char *)"mac set appskey "); // DET
                    insere_string_flash_uart_2((const unsigned char *)APPSKEY); // DET
                    insere_string_flash_uart_2((const unsigned char *)"\r\n"); // DET
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 4:
                    insere_string_flash_uart_2((const unsigned char *)"mac set nwkskey "); //DET
                    insere_string_flash_uart_2((const unsigned char *)NWKSKEY); // DET
                    insere_string_flash_uart_2((const unsigned char *)"\r\n"); // DET
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 5:
                    insere_string_flash_uart_2((const unsigned char *)"mac set adr on\r\n");  // n�o obrigat�rio, pode ser conflito com o adr on
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 6:
                    //insere_string_flash_uart_2((const unsigned char *)"radio set pwr 20\r\n");
                    //tx_pct_uart_2();
                    //delay_ms(100);
                    //insere_string_flash_uart_2((const unsigned char *)"mac set pwridx 10\r\n");
                    //tx_pct_uart_2();
                    //delay_ms(100);

                    insere_string_flash_uart_2((const unsigned char *)"mac set dr 1\r\n");
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    break;
                case 7://Salva os par�metros configurados
                    insere_string_flash_uart_2((const unsigned char *)"mac save\r\n");      // n�o obrigat�rio pois a cada tx � feita a inicializa��o
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    timeout_aguarda_resposta_lora = 0;
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    break;
                case 8:                                        //Tenta se conectar na rede
                    #ifdef ENVIA_KWH
                    if (FS_UART3_FINALIZADO == 0)
                    {
                        break;
                    }
                    #endif
                    insere_string_flash_uart_2((const unsigned char *)"mac join abp\r\n");
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    qtd_resp_tx = 2;
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    proximo_state_lora = LORA_INICIALIZA;
                    ultimo_state_lora = LORA_INICIALIZA;
                    break;
                case 9:                     //Salva os par�metros configurados
                    insere_string_flash_uart_2((const unsigned char *)"mac set upctr "); //
                    aux = formata_str_valor( dados.upctr, 0, 8, DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[0],aux);   //1bytes
                    insere_string_flash_uart_2((const unsigned char *)"\r\n");
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    qtd_resp_tx = QTD_RESP_DEFAULT;
                    proximo_state_lora = sm_lora;
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    timeout_sm = 0;
                    break;
                case 10:                     //Salva os par�metros configurados
                    insere_string_flash_uart_2((const unsigned char *)"sys get vdd\r\n"); //
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    FS_GET_VCC = 1;
                    qtd_resp_tx = QTD_RESP_TX;
                    proximo_state_lora = sm_lora;
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    timeout_aguarda_resposta_lora = 0;
                    timeout_sm = 0; //depois que inicializa ja manda TX na sequencia sem delay
                    break;
                case 11: /// SUBSTATE TIMEOUT
                    timeout_sm++;
                    FS_UART3_START_SM = 1;
                    #ifdef AGUARDA_ESTABILIZACAO
                        #ifdef ENVIA_GPS
                            if ((timeout_sm >=  TIMEOUT_ESTABILIZACAO ) || ( dados.gps.lat_deg ))       // 60 segundos
                        #else
                            if (timeout_sm >=  TIMEOUT_ESTABILIZACAO )        // 2 segundos
                        #endif
                    #else
                    if (timeout_sm >= TIMEOUT_SM )
                    #endif
                    {
                        timeout_sm = 0;
                        FS_LORA_INICIADO = 1;
                        timeout_tx = 0; //depois que inicializa ja manda TX na sequencia sem delay
                        sm_lora = LORA_GET_STATUS;
                        proximo_state_lora = LORA_TX;
                        #ifdef PWM_ON_RB15
                            adc.sensor_capacitivo_max = 0;
                            adc.sensor_capacitivo_min = 1024;
                        #endif
                    }
                    break;
                default:
                    sub_state_lora = 0;
                    break;
            }
            break;

        case LORA_TX:
            if (FS_GPS_REQUEST == 0)
            {
                #ifdef ENVIA_UNCNF
                insere_string_flash_uart_2((const unsigned char *)"mac tx uncnf 100 "); // checar flag FS_TX_MAC_OK se ok
                #else
                insere_string_flash_uart_2((const unsigned char *)"mac tx cnf 100 "); // checar flag FS_TX_MAC_OK se ok
                #endif

                #ifdef ATIVA_PID
                insere_string_flash_uart_2((const unsigned char *)"10"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.esforco_pid1),buffer_ascii);           // MANDA BOT�O DE INTERRUP��O
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                #endif

                #ifdef ENVIA_SENSOR_INT0                //manda contador no INT0
                insere_string_flash_uart_2((const unsigned char *)"10"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.pos_encoder),buffer_ascii);           // MANDA BOT�O DE INTERRUP��O
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                #endif
                #ifdef ENVIA_ENCODER                //manda contador no INT0
                insere_string_flash_uart_2((const unsigned char *)"10"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.selecao_encoder),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                #endif

                #ifdef ENVIA_CONTADOR_PERMANENTE                //manda contador no INT0
                insere_string_flash_uart_2((const unsigned char *)"0B"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.contador_permanente),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[2],6);          //2byteS  //3
                #endif

                #ifdef ENVIA_KWH
                insere_string_flash_uart_2((const unsigned char *)"0E"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.kwh),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[2],6);          //2byteS  //3
                #endif

                #ifdef ENVIA_AN10  //manda AN13 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef AN10_NTC10K
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_ntc10k[0]),buffer_ascii);
                    #elif defined(AN10_PT100)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_pt100[0]),buffer_ascii);
                    #elif defined(AN10_4_20MA)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.corrente_4_20ma[0]),buffer_ascii);
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(adc.dados.canais.v_an10),buffer_ascii);
                    #endif
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3

                    #ifdef DISPLAY_SPI
                        formata_str_valor( dados.temperatura_celcius, UMA_CASA_DECIMAL, 5,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                        escreve_texto_lcd( 80, 50, buffer_ascii,1, WHITE);
                        escreve_texto_lcd_flash( -1, -1, (const unsigned char *)TEXTO_TEMP,1, WHITE);
                        display();
                    #endif
                #endif

                #ifdef ENVIA_AN11  //manda AN13 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef AN11_NTC10K
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_ntc10k[1]),buffer_ascii);
                    #elif defined(AN11_PT100)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_pt100[1]),buffer_ascii);
                    #elif defined(AN11_4_20MA)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.corrente_4_20ma[1]),buffer_ascii);
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(adc.dados.canais.v_an11),buffer_ascii);
                    #endif
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3

                    #ifdef DISPLAY_SPI
                        formata_str_valor( dados.temperatura_celcius, UMA_CASA_DECIMAL, 5,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                        escreve_texto_lcd( 80, 50, buffer_ascii,1, WHITE);
                        escreve_texto_lcd_flash( -1, -1, (const unsigned char *)TEXTO_TEMP,1, WHITE);
                        display();
                    #endif
                #endif
                #ifdef ENVIA_AN12  //manda AN12 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef CAPACITIVO_ON_RB15
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    aux_long = ( adc.sensor_capacitivo_max - adc.sensor_capacitivo_min);
                    dword_para_hex((long)(aux_long),buffer_ascii);
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                        #ifdef DISPLAY_SPI
                            escreve_texto_lcd_flash( 0, 30, (const unsigned char *)TEXTO_VAL,1, WHITE);
                            formata_str_valor( aux_long, ZERO_CASAS_DECIMAIS, 4,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                            escreve_texto_lcd( -1, -1, buffer_ascii,2, WHITE );
                        #endif
                    #else
                        #ifdef AN12_NTC10K
                        insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                        dword_para_hex((long)(dados.temperaturas_ntc10k[2]),buffer_ascii);
                        #elif defined(AN12_PT100)
                        insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                        dword_para_hex((long)(dados.temperaturas_pt100[2]),buffer_ascii);
                        #elif defined(AN12_4_20MA)
                        insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                        dword_para_hex((long)(dados.corrente_4_20ma[2]),buffer_ascii);
                        #else
                        insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                        dword_para_hex((long)(adc.dados.canais.v_an12),buffer_ascii);
                        #endif
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                    #endif
                #endif
                #ifdef ENVIA_AN13  //manda AN13 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef AN13_NTC10K
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_ntc10k[3]),buffer_ascii);
                    #elif defined(AN13_PT100)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_pt100[3]),buffer_ascii);
                    #elif defined(AN13_4_20MA)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.corrente_4_20ma[3]),buffer_ascii);
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(adc.dados.canais.v_an13),buffer_ascii);
                    #endif
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3

                    #ifdef DISPLAY_SPI
                        formata_str_valor( dados.temperatura_celcius, UMA_CASA_DECIMAL, 5,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                        escreve_texto_lcd( 80, 50, buffer_ascii,1, WHITE);
                        escreve_texto_lcd_flash( -1, -1, (const unsigned char *)TEXTO_TEMP,1, WHITE);
                        display();
                    #endif
                #endif
                #ifdef ENVIA_AN14  //manda AN13 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef AN14_NTC10K
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_ntc10k[4]),buffer_ascii);
                    #elif defined(AN14_PT100)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_pt100[4]),buffer_ascii);
                    #elif defined(AN14_4_20MA)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.corrente_4_20ma[4]),buffer_ascii);
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(adc.dados.canais.v_an14),buffer_ascii);
                    #endif
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3

                    #ifdef DISPLAY_SPI
                        formata_str_valor( dados.temperatura_celcius, UMA_CASA_DECIMAL, 5,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                        escreve_texto_lcd( 80, 50, buffer_ascii,1, WHITE);
                        escreve_texto_lcd_flash( -1, -1, (const unsigned char *)TEXTO_TEMP,1, WHITE);
                        display();
                    #endif
                #endif
                #ifdef ENVIA_AN15  //manda AN13 // usando sonar maxsonar com 3v3 = ~3,2mV/2cm This Analog Voltage output steps in 2cm increments
                    #ifdef AN15_NTC10K
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_ntc10k[5]),buffer_ascii);
                    #elif defined(AN15_PT100)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.temperaturas_pt100[5]),buffer_ascii);
                    #elif defined(AN15_4_20MA)
                    insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(dados.corrente_4_20ma[5]),buffer_ascii);
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    dword_para_hex((long)(adc.dados.canais.v_an12),buffer_ascii);
                    #endif
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3

                    #ifdef DISPLAY_SPI
                        formata_str_valor( dados.temperatura_celcius, UMA_CASA_DECIMAL, 5,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                        escreve_texto_lcd( 80, 50, buffer_ascii,1, WHITE);
                        escreve_texto_lcd_flash( -1, -1, (const unsigned char *)TEXTO_TEMP,1, WHITE);
                        display();
                    #endif
                #endif
                #ifdef ENVIA_SENSOR_COR
                    insere_string_flash_uart_2((const unsigned char *)"0D"); //1 checar flag FS_TX_MAC_OK se ok
                    aux_long = dados.sensor_cor;
                    dword_para_hex((long)(aux_long),buffer_ascii);
                    insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                        #ifdef DISPLAY_SPI
                            escreve_texto_lcd_flash( 0, 50, (const unsigned char *)TEXTO_COR,1, WHITE);
                            formata_str_valor( aux_long, ZERO_CASAS_DECIMAIS, 4,DESPREZA_ZEROS_ESQUERDA, buffer_ascii );
                            escreve_texto_lcd( -1, -1, buffer_ascii,2, WHITE);
                            display();
                        #endif
                #endif

                #ifdef ENVIA_DHT     //manda TEMP E UMID             "01TTTT02UUUU"
                insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.temperatura_celcius),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                insere_string_flash_uart_2((const unsigned char *)"02"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.umidade),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                #endif
       
                #ifdef ENVIA_RFID     //manda RFID             "0Frrrrrrrr"
                insere_string_flash_uart_2((const unsigned char *)"0F"); //1 checar flag FS_TX_MAC_OK se ok
                insere_bytes_uart_2((unsigned char *)&dados.rfid[0],10);          //2byteS  //3
                #endif

                #ifdef ENVIA_GIROSCOPIO                // manda Girosc�pio
                atualiza_acelerometro();
                insere_string_flash_uart_2((const unsigned char *)"01"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.acelerometro.temperature),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                insere_string_flash_uart_2((const unsigned char *)"05");    // 4 giro
                dword_para_hex((long)dados.acelerometro.gx,buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //6
                dword_para_hex((long)dados.acelerometro.gy,buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //8
                dword_para_hex((long)dados.acelerometro.gz,buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //10
                #endif

                #ifdef ENVIA_GPS                // manda GPS
                //atualiza_acelerometro();

                insere_string_flash_uart_2((const unsigned char *)"0A");    //1  GPS
                dword_para_hex((long)getLatitudeDegrees(),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);            // bytes 2
                dword_para_hex((long)(dados.gps.lat_decimals),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[2],6);      //1byte 6
                dword_para_hex((long)getLongitudeDegrees(),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);         //2byte 7
                dword_para_hex((long)(dados.gps.longit_decimals),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[2],6);    //4bytes 10
                #endif

                #ifdef ENVIA_VBAT_VIA_RN2903         //manda Vbat
                insere_string_flash_uart_2((const unsigned char *)"0C"); //1 checar flag FS_TX_MAC_OK se ok
                dword_para_hex((long)(dados.nivel_vcc),buffer_ascii);
                insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);          //2byteS  //3
                #endif

                insere_string_flash_uart_2((const unsigned char *)"\r\n");
                uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                F_PORTA_LORA_PCT_RX = 0;
                tx_pct_uart_2();
                ultimo_state_lora = sm_lora;
                sm_lora = LORA_AGUARDA_RESPOSTA;
                timeout_aguarda_resposta_lora = 0;
                proximo_state_lora = LORA_GET_FCNT;
                qtd_resp_tx = QTD_RESP_TX;
                timeout_tx = TIMEOUT_TX; //depois desse TX, entra em espera de TIMEOUT_TX
            }
            else
            {
                #define AGUARDA_GPS
                #if( defined( AGUARDA_GPS ) )
                if ( FS_GPS_FINALIZADO )
                #endif
                {
                    #ifdef ENVIA_UNCNF
                    insere_string_flash_uart_2((const unsigned char *)"mac tx uncnf 100 "); // checar flag FS_TX_MAC_OK se ok
                    #else
                    insere_string_flash_uart_2((const unsigned char *)"mac tx cnf 100 "); // checar flag FS_TX_MAC_OK se ok
                    #endif
                    //dados.nivel_bateria = (adc.dados.canais.v_bat / 14); // 0X40 = 1,9V -0X5B = 2,5v - 0X6C = 3,0V - 0X7A = 3,3V
                    //insere_string_flash_uart_2((const unsigned char *)"00"); // 1 checar flag FS_TX_MAC_OK se ok
                    //dword_para_hex((unsigned long)dados.nivel_bateria,buffer_ascii);
                    //insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);          //1byte  //2

                    //    if (FS_GPS_UTC_OK )
                    //    {
                    //        insere_string_flash_uart_2((const unsigned char *)"08");    //3  hora
                    //        dword_para_hex((unsigned long)dados.gps.utc_hour,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);               //1byte 4
                    //        dword_para_hex((unsigned long)dados.gps.utc_min,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);               //1byte 5
                    //        dword_para_hex((unsigned long)dados.gps.utc_sec,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);               //1byte 6
                    //    }
                    //    if (FS_GPS_DATA_OK )
                    //    {
                    //        insere_string_flash_uart_2((const unsigned char *)"09");    //7  DATA
                    //        dword_para_hex((unsigned long)dados.gps.utc_dayOfMonth,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);               //1byte 8
                    //        dword_para_hex((unsigned long)dados.gps.utc_month,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);               //1byte 9
                    //        dword_para_hex((unsigned long)dados.gps.utc_year,buffer_ascii);
                    //        insere_bytes_uart_2((unsigned char *)&buffer_ascii[4],4);               //1byte 10
                    //    }

                    //if (FS_GPS_POSICAO_OK)
                    {
                        insere_string_flash_uart_2((const unsigned char *)"0A");    //1  GPS
                        dword_para_hex((long)getLatitudeDegrees(),buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);            // bytes 2
                        dword_para_hex((long)(dados.gps.lat_decimals),buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);      //1byte 6
                        dword_para_hex((long)getLongitudeDegrees(),buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[6],2);         //2byte 7
                        dword_para_hex((long)(dados.gps.longit_decimals),buffer_ascii);
                        insere_bytes_uart_2((unsigned char *)&buffer_ascii[2],6);    //4bytes 10
                    }
                    insere_string_flash_uart_2((const unsigned char *)"\r\n");
                    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                    F_PORTA_LORA_PCT_RX = 0;
                    tx_pct_uart_2();
                    ultimo_state_lora = LORA_TX;
                    timeout_aguarda_resposta_lora = 0;
                    sm_lora = LORA_AGUARDA_RESPOSTA;
                    proximo_state_lora = LORA_GET_FCNT;
                    qtd_resp_tx = QTD_RESP_TX;
                    timeout_tx = TIMEOUT_TX; //depois desse TX, entra em espera de TIMEOUT_TX
                }
            }
            break;

       case LORA_GET_FCNT:
            // **** usar para pegar o hardware EUI
            insere_string_flash_uart_2((const unsigned char *)"\r\n");
            F_PORTA_LORA_PCT_RX = 0;
            uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
            tx_pct_uart_2();
            delay_ms(50);

            insere_string_flash_uart_2((const unsigned char *)"mac get upctr\r\n");
            uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
            F_PORTA_LORA_PCT_RX = 0;
            tx_pct_uart_2();
            FS_GET_FCNT = 1;
            ultimo_state_lora = sm_lora;
            sm_lora = LORA_AGUARDA_RESPOSTA;
            timeout_aguarda_resposta_lora = 0;
            proximo_state_lora = LORA_SLEEP;
            qtd_resp_tx = QTD_RESP_DEFAULT;
            timeout_tx = TIMEOUT_TX; //depois desse TX, entra em espera de TIMEOUT_TX
            break;

       case LORA_SLEEP:
            #ifndef NUNCA_DORME
                #ifdef DEEP_SLEEP_1MINUTO
                    insere_string_flash_uart_2((const unsigned char *)"sys sleep 60000\r\n"); //1 minutos de sleep, sera resetado
                #else
                    insere_string_flash_uart_2((const unsigned char *)"sys sleep 900000\r\n"); //15 minutos de sleep, sera resetado
                #endif
                uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                F_PORTA_LORA_PCT_RX = 0;
                tx_pct_uart_2();
            #endif
            ultimo_state_lora = sm_lora;
            sm_lora = LORA_FINALIZA;
            proximo_state_lora = LORA_FINALIZA;
            qtd_resp_tx = 0;        // ignora resposta na volta do sleep
            timeout_tx = 0; //depois desse TX, ja mando o proximo na sequencia sem delay
            break;

        case LORA_AGUARDA_RESPOSTA:
            timeout_aguarda_resposta_lora++;
            if (timeout_aguarda_resposta_lora >= TIMEOUT_AGUARDA_RESPOSTA_LORA)
            {
                timeout_aguarda_resposta_lora = 0;
                num_tentativas++;
                num_erros++;
                if (num_tentativas >= MAX_TENTATIVAS_TX)
                {
                    sm_lora = LORA_GET_FCNT;
                    FS_LORA_INICIADO = 0;
                    break;
                }
                else
                {
                    sm_lora = ultimo_state_lora;
                    break;
                }
            }

            if( F_PORTA_LORA_PCT_RX )
            {
                F_PORTA_LORA_PCT_RX = 0;
                status = trata_pct_lora_rx();
                timeout_aguarda_resposta_lora = 0; // aguarda mais um tempo
                num_resp_tx++;                         

                if (FS_GET_VCC)
                { // salva ultimo frame v�lido enviado
                    FS_GET_VCC = 0;
                    dados.nivel_vcc = status;
                    sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                    sub_state_lora++;               // incrementa um substado
                    num_resp_tx = 0;
                    break;
                }
                if (FS_GET_FCNT)
                { // salva ultimo frame v�lido enviado
                    FS_GET_FCNT = 0;
                    dados.upctr = status;
                    sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                    sub_state_lora++;               // incrementa um substado
                    num_resp_tx = 0;
                    break;
                }
                else if (FS_GET_STATUS)
                {
                    FS_GET_STATUS = 0;
                    mac_state = (unsigned int)((status && 0x0000000E)>>1);
                    if ( (status & 0x00000001) != 0x00000001) // not joined
                    {                        
                        sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                        proximo_state_lora = LORA_INICIALIZA;
                        ultimo_state_lora = LORA_INICIALIZA;
                        sub_state_lora = 8;
                        num_resp_tx = 0;
                        break;
                    }
                    if ( (status & 0x00000080) == 0x00000080) // mac paused
                    {
                        sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                        proximo_state_lora = LORA_INICIALIZA;
                        ultimo_state_lora = LORA_INICIALIZA;
                        sub_state_lora = 1;
                        num_resp_tx = 0;
                        break;
                    }
                    else if ((mac_state == 0) || (mac_state == 6)) // ok pode tranmitir
                    {
                        sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                        num_resp_tx = 0;
                        break;
                    }
                    else
                    {
                        // transmitindo
                        num_erros++;
                        sm_lora = LORA_GET_STATUS; // busca status
                        if ( num_erros > MAX_ERROS )
                        {
                            sm_lora = LORA_GET_FCNT;
                            FS_LORA_INICIADO = 0;
                        }
                        break;
                    }
                }

                if ( qtd_resp_tx == 0)      // n�o � necess�rio tratar a resposta seja ela qual for
                {
                    sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                    sub_state_lora++;             // incrementa um substado
                    num_resp_tx = 0;
                    break;
                }

                if ( FS_TX_LORA_OK || FS_JOIN_ACCEPTED )
                {
                    if (num_resp_tx >= qtd_resp_tx)
                    {
                        sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                        sub_state_lora++;               // incrementa um substado
                        num_resp_tx = 0;
                    } // else continua aguardando
                    break;
                }
                else if( FS_TX_MAC_OK  || FS_RX_MAC_OK )
                {
                    FS_GPS_REQUEST = 0;

                    // s� pra debug inicio
                    LED_STATUS = 1;
                    delay_ms(100);
                    LED_STATUS = 0;

                    if (FS_RX_MAC_OK)
                    {
                        if (( uart_2.rx[ 11 ] == '0' ) && ( uart_2.rx[ 12 ] == 'A' ))
                        {
                            FS_GPS_REQUEST = 1;
                            sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                            proximo_state_lora = LORA_INICIALIZA;
                            ultimo_state_lora = LORA_INICIALIZA;
                            sub_state_lora = 11;
                            timeout_sm = TIMEOUT_SM;
                            num_resp_tx = 0;
                            break;
                        }
                        else if (( uart_2.rx[ 11 ] == '0' ) && ( uart_2.rx[ 12 ] == '0' ))
                        {
                            if (( uart_2.rx[ 13 ] == '0' ) && ( uart_2.rx[ 14 ] == '0' ))
                            {
                                LED_STATUS = 0; //DESLIGA LED
                            }
                            else if ( ( uart_2.rx[ 13 ] == '0' ) && ( uart_2.rx[ 14 ] == '1' ) )
                            {
                                LED_STATUS = 1; // LIGA LED
                            }
                            break;
                        }
                    }
                    else
                    {
                        sm_lora = proximo_state_lora; // volta para o mesmo estado principal
                        sub_state_lora++;               // incrementa um substado
                        num_resp_tx = 0;
                    }
                    break;
                }
                else if ( (FS_TX_NOT_FREE_CH) || (FS_TX_LORA_ERR) || (FS_TX_LORA_INV) || ( FS_TX_LORA_BUSY  ))
                {
                    num_erros++;
                    if ( num_erros > MAX_ERROS )
                    {
                        sm_lora = LORA_GET_FCNT;
                        FS_LORA_INICIADO = 0;
                        break;
                    }
                    if (  FS_TX_LORA_INV )
                    {
                        insere_string_flash_uart_2((const unsigned char *)"mac set dr 1\r\n"); // invalid data length entao muda data rate
                        uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
                        F_PORTA_LORA_PCT_RX = 0;
                        tx_pct_uart_2();
                        sm_lora = LORA_AGUARDA_RESPOSTA;
                        qtd_resp_tx = QTD_RESP_DEFAULT;
                        proximo_state_lora = LORA_INICIALIZA;
                        ultimo_state_lora = LORA_INICIALIZA;
                        sub_state_lora = 8;
                        num_resp_tx = 0;
                        break;
                    }
                       // s� aguarda
                    sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                    proximo_state_lora = LORA_INICIALIZA;
                    ultimo_state_lora = LORA_INICIALIZA;
                    sub_state_lora = 11;
                    num_resp_tx = 0;
                    break;
                }
                else if ( FS_TX_NOT_JOINED  )
                {
                    sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                    proximo_state_lora = LORA_INICIALIZA;
                    ultimo_state_lora = LORA_INICIALIZA;
                    sub_state_lora = 1;
                    num_resp_tx = 0;
                    break;
                }
                else // qq resposta diferente do esperado reinicia a m�quina
                {
                    num_erros++;
                    num_resp_tx = 0;
                    if ( num_erros > MAX_ERROS )
                    {
                        sm_lora = LORA_GET_FCNT;
                        FS_LORA_INICIADO = 0;
                    }
                    else
                    {
                        timeout_tx = 0;        // ja manda reinicializar na sequencia sem delay
                        sm_lora = LORA_INICIALIZA; // volta para o mesmo estado principal
                        proximo_state_lora = LORA_INICIALIZA;
                        ultimo_state_lora = LORA_INICIALIZA;
                        sub_state_lora = 0;
                        num_resp_tx = 0;
                    }
                    break;
                }
            }
            break;

        case LORA_GET_STATUS:
            FS_GET_STATUS = 1; // permite sleep apos tx lora
            insere_string_flash_uart_2((const unsigned char *)"mac get status\r\n");
            uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
            F_PORTA_LORA_PCT_RX = 0;
            tx_pct_uart_2();
            sm_lora = LORA_AGUARDA_RESPOSTA;
            timeout_aguarda_resposta_lora = 0;
            qtd_resp_tx = QTD_RESP_DEFAULT;
            break;

        case LORA_FINALIZA:
            FS_PERMITE_SLEEP = 1; // permite sleep apos tx lora
            timeout_aguarda_resposta_lora = 0; // aguarda mais um tempo
            sm_lora = LORA_OCIOSO;
            ultimo_state_lora = LORA_OCIOSO;
            proximo_state_lora = LORA_OCIOSO;
            num_erros = 0;
            num_tentativas = 0;
            timeout_tx = 0;        // ja manda reinicializar na sequencia sem delay
            LED_STATUS = 0;
            delay_ms(100);
            // inc frame counter
            if (FS_LORA_INICIADO == 0)
            {
                dados.upctr++;
            }
            #ifdef NUNCA_DORME
                flags_sw.value = flags_sw.value && 0xFFFFC000; //APAGA FLAG DE SW DO LORA
                #ifdef DEEP_SLEEP_1MINUTO
                    timeout_tx = 6000;  // 1 minuta
                #else
                    timeout_tx = 48000;
                #endif
                            // 8 minutos
                FS_LORA_INICIADO = 1;
            #endif
            break;
        default:
            break;
    }
}

void sm_processo_uart3 ( void )
{
    #ifdef ENVIA_SONDA
    #endif

    #ifdef ENVIA_KWH
    unsigned char dummy[10] =  {        0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55};
    unsigned char cmd_start =           0x99;
    unsigned char numero_serie[4] =  {  0x01,0x97,0x86,0x81};
    unsigned char send_data[64] = {     0x23,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
                                        0x00,0x00,0x00,0x00};
    unsigned char send_chksum[2] =  {   0x48,0x49};
    #endif

    #ifdef ENVIA_KWH
    #define     TIMEOUT_AGUARDA_RESPOSTA_UART3                50           // 200 milisegundos
    static unsigned int timeout_aguarda_resposta_uart3 = 0;
    

    if( F_PORTA_UART3_PCT_RX )
    {
        F_PORTA_UART3_PCT_RX = 0;
        trata_pct_uart3_rx();
    }

    switch(sm_uart3)
    {
        case UART3_OCIOSO:
            if (( FS_UART3_START_SM == 1) && (FS_UART3_FINALIZADO == 0))
            {
                FS_UART3_DATA_OK = 0;
                sm_uart3 = UART3_INICIALIZA;
            }
            break;
        case UART3_INICIALIZA:
            uart_3.tam_tx = 0;
            insere_bytes_uart_3((unsigned char *)&dummy[0],sizeof(dummy)); // DET
            insere_byte_uart_3(cmd_start);
            insere_bytes_uart_3((unsigned char *)&numero_serie[0],sizeof(numero_serie)); // DET
            insere_bytes_uart_3((unsigned char *)&send_data[0],sizeof(send_data)); // DET
            insere_bytes_uart_3((unsigned char *)&send_chksum[0],sizeof(send_chksum)); // DET
            uart_3.tam_rx = 0;  // LIMPA SUJEIRAS.
            F_PORTA_UART3_PCT_RX = 0;
            tx_pct_uart_3();
            sm_uart3 = UART3_AGUARDANDO_RX;
            break;
        case UART3_AGUARDANDO_RX:
            timeout_aguarda_resposta_uart3++;
            if (timeout_aguarda_resposta_uart3 >= TIMEOUT_AGUARDA_RESPOSTA_UART3)
            {
                timeout_aguarda_resposta_uart3 = 0;
                sm_uart3 = UART3_FINALIZA;
            }

            if ( FS_UART3_DATA_OK  )
            {
                sm_uart3 = UART3_FINALIZA;
            }
            break;

        case UART3_FINALIZA:
            FS_UART3_FINALIZADO = 1;
            sm_uart3 = UART3_OCIOSO;
            break;
    }
    #endif
}

void sm_processo_uart1 ( void )
{


    #ifdef ENVIA_GPS
        sm_processo_gps();
    #endif

    #ifdef ENVIA_RFID
        if( F_PORTA_UART1_PCT_RX )
        {
            F_PORTA_UART1_PCT_RX = 0;
            trata_pct_uart1_rx();
        }
        sm_processo_rfid();
    #endif
}

void sm_processo_rfid ( void )
{
    #define     TIMEOUT_AGUARDA_RESPOSTA_UART1                50           // 200 milisegundos
    static unsigned int timeout_aguarda_resposta_uart1 = 0;

    switch(sm_uart1)
    {
        case UART1_OCIOSO:
            if (FS_UART1_FINALIZADO == 0)
            {
                FS_UART1_DATA_OK = 0;
                sm_uart1 = UART1_INICIALIZA;
            }
            break;
        case UART1_INICIALIZA:
            uart_1.tam_tx = 0;
            sm_uart1 = UART1_AGUARDANDO_RX;
            break;
        case UART1_AGUARDANDO_RX:
            timeout_aguarda_resposta_uart1++;
            if (timeout_aguarda_resposta_uart1 >= TIMEOUT_AGUARDA_RESPOSTA_UART1)
            {
                timeout_aguarda_resposta_uart1 = 0;
                sm_uart1 = UART1_FINALIZA;
            }

            if ( FS_UART1_DATA_OK  )
            {
                sm_uart1 = UART1_FINALIZA;
            }
            break;

        case UART1_FINALIZA:
            FS_UART1_FINALIZADO = 1;
            sm_uart1 = UART1_OCIOSO;
            break;
    }
}

void sm_processo_gps ( void )
{
#define     TIMEOUT_AGUARDA_RESPOSTA_GPS                4500           // 45 segundos
#define     TIMEOUT_SM_GPS                              100           // 3 segundo
#define     MAX_ERROS_GPS                               3

    static unsigned char sub_state_gps = 0;
    static Sm_gps proximo_state_gps = GPS_OCIOSO;
    static Sm_gps ultimo_state_gps = GPS_OCIOSO;
    static unsigned int timeout_aguarda_resposta_gps = 0;
    static unsigned int timeout_sm_gps = 0;
    static unsigned char gps_iniciado = 0;


    switch(sm_gps)
    {
        case GPS_OCIOSO:
            if ((FS_GPS_REQUEST == 1) || (gps_iniciado == 0))
            {
                gps_iniciado = 1;
                RST_GPS = 1;
                proximo_state_gps = GPS_INICIALIZA;
                ultimo_state_gps = GPS_OCIOSO;
                sm_gps = GPS_INICIALIZA;
                sub_state_gps = 0;
            }
            break;
        case GPS_INICIALIZA:
            switch (sub_state_gps)
            {
                case 0:
                    insere_string_flash_uart_1((const unsigned char *) PMTK_FULL_POWER  );
                    tx_pct_uart_1();
                    timeout_sm_gps = 0;
                    sub_state_gps++;
                    break;
                case 1:
                    timeout_sm_gps++;
                    if (timeout_sm_gps >= 1 ) //10milis
                    {
                        timeout_sm_gps = 0;
                        sub_state_gps++;
                    }
                    break;
                case 2:
                    //insere_string_flash_uart_1((const unsigned char *)PMTK_SET_NMEA_OUTPUT_RMCONLY); // tempo em segundos entre tx zero
                    //tx_pct_uart_1();
                    timeout_sm_gps = 0;
                    sub_state_gps++;
                    break;
                case 3:
                    timeout_sm_gps++;
                    if (timeout_sm_gps >= 1 ) //10miliseg
                    {
                        timeout_sm_gps = 0;
                        proximo_state_gps = GPS_LOCALIZANDO;
                        ultimo_state_gps = GPS_INICIALIZA;
                        sm_gps = GPS_LOCALIZANDO;
                        sub_state_gps = 0;
                    }
                    break;
                default:
                    sub_state_gps = 0;
                    break;
            }
            break;
        case GPS_LOCALIZANDO:
            timeout_aguarda_resposta_gps++;
            if (timeout_aguarda_resposta_gps >= TIMEOUT_AGUARDA_RESPOSTA_GPS)
            {
                timeout_aguarda_resposta_gps = 0;
                sm_gps = GPS_FINALIZA;
            }

            if( F_PORTA_UART1_PCT_RX )
            {
                F_PORTA_UART1_PCT_RX = 0;
                trata_pct_uart1_rx();
           }

            if ((dados.gps.lat_deg != 0) && ( dados.gps.longit_deg != 0))
            {
                FS_GPS_POSICAO_OK = 1;
            }

            if ( dados.gps.utc_hour != 0)
            {
                FS_GPS_UTC_OK = 1;
            }
            if (( dados.gps.utc_year != 0) && ( dados.gps.utc_year != 2080))
            {
                FS_GPS_DATA_OK = 1;
            }

            if ( FS_GPS_DATA_OK && FS_GPS_UTC_OK && FS_GPS_POSICAO_OK )
            {
                sm_gps = GPS_FINALIZA;
            }
            break;

        case GPS_FINALIZA:
            FS_GPS_FINALIZADO = 1;
            insere_string_flash_uart_1((const unsigned char *)SL868A_SET_STDBY_CMD);
            tx_pct_uart_1();
            sm_gps = GPS_OCIOSO;
            RST_GPS = 0;
            break;
    }
}

void sm_processo_pid( void )
{
    static unsigned int  timeout = 1;

    timeout --;
    if (timeout == 0)               // entra a cada ms
    {
        timeout = (unsigned int)(1000.0 / dados.setup.sample_freq);      // 10ms

        //verifica limites
        if (dados.setup.setpoint_pid1 > 9999.0)
        {
            dados.setup.setpoint_pid1 = 9999.9;
        }

        if( dados.pid_estavel == ESTAVEL)
        {
            configura_registros_controle( 3, 3, 1); //( 3, 3, 1)//r�pido, NAO USAR ZERO, n para multiplicar e deixar o kp ki e kd maiores. e com sistema mais lento
        }
        else
        {
            configura_registros_controle( 1, 1, 1); //r�pido, NAO USAR ZERO, n para multiplicar e deixar o kp ki e kd maiores. e com sistema mais lento
        }

        // m�quina de estado
        switch (sm_control)
        {
            case CONTROL_ON:
                dados.valor_pid1_atual = ((float)dados.temperaturas_ntc10k[1]/10.0);

                //verifica regi�o pr�xima do alvo
                dados.esforco_pid1 = algoritmo_pid_controle( PID_1, dados.valor_pid1_atual, dados.setup.setpoint_pid1 );

                atualiza_pwm_1( (unsigned int)dados.esforco_pid1 );            // atualiza pedal conforme pid de rota��o por pedal
                dados.estabilidade_pid1 = verifica_estabilidade( PID_1 );                  // sa�das : ESTAVEL ou INSTAVEL
                
                break;
            case CONTROL_INICIAR:
                inicializa_controle();
                dados.esforco_pid1 = 0;
                atualiza_pwm_1( dados.esforco_pid1 );
                configura_registros_controle( 1, 1, 1); // r�pido, NAO USAR ZERO
                inicia_pid_controle( PID_1, 0, 0 );
                sm_control = CONTROL_ON;
                break;
            case CONTROL_OFF:
                dados.esforco_pid1 = 0;
                atualiza_pwm_1( 0 );
                configura_registros_controle( 1, 1, 1 ); // r�pido, NAO USAR ZERO
                finaliza_pid_controle( PID_1 );
                sm_control = CONTROL_INICIAR;
                break;
         }
    }
}


/****************************************************************************************\
 * trata_pct_serial_rx                                                                  *
 * Rotina para tratamento do pacote serial recebido. Os pacotes recebidos aqui referem- *
 * se aos dados enviados pelo leitor de c�digo de barras                                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
unsigned long trata_pct_lora_rx( void )
{
    union unsigned_long aux;
    FS_TX_LORA_OK = 0;
    FS_TX_LORA_ERR = 0;
    FS_TX_LORA_BUSY = 0;
    FS_TX_LORA_INV = 0;
    FS_TX_MAC_OK = 0;
    FS_JOIN_ACCEPTED = 0;
    FS_RX_MAC_OK = 0;
    FS_TX_NOT_JOINED = 0;
    FS_TX_NOT_FREE_CH = 0;

    aux.value = 0;

    if (( uart_2.rx[ 0 ] == 'o') && ( uart_2.rx[ 1 ] == 'k'))
    {
        FS_TX_LORA_OK = 1;
    }
    else if (( uart_2.rx[ 0 ] == 'm') && ( uart_2.rx[ 1 ] == 'a') && ( uart_2.rx[ 2 ] == 'c')
             && ( uart_2.rx[ 3 ] == '_') && ( uart_2.rx[ 4 ] == 't') && ( uart_2.rx[ 5 ] == 'x') && ( uart_2.rx[ 6 ] == '_')
                && ( uart_2.rx[ 7 ] == 'o') && ( uart_2.rx[ 8 ] == 'k'))
    {
        FS_TX_MAC_OK = 1; // tramiss�o sem sucesso
    }
    else if (( uart_2.rx[ 0 ] == 'a') && ( uart_2.rx[ 1 ] == 'c') && ( uart_2.rx[ 2 ] == 'c') && ( uart_2.rx[ 3 ] == 'e')
            && ( uart_2.rx[ 4 ] == 'p') && ( uart_2.rx[ 5 ] == 't') && ( uart_2.rx[ 6 ] == 'e') && ( uart_2.rx[ 7 ] == 'd'))
    {
        FS_JOIN_ACCEPTED = 1; // tramiss�o sem sucesso
    }
    else if (( uart_2.rx[ 0 ] == 'm') && ( uart_2.rx[ 1 ] == 'a') && ( uart_2.rx[ 2 ] == 'c')
             && ( uart_2.rx[ 3 ] == '_') && ( uart_2.rx[ 4 ] == 'e') && ( uart_2.rx[ 5 ] == 'r') && ( uart_2.rx[ 6 ] == 'r'))
    {
        FS_TX_LORA_ERR = 1; // tramiss�o sem sucesso
    }
    else if (( uart_2.rx[ 0 ] == 'b') && ( uart_2.rx[ 1 ] == 'u') && ( uart_2.rx[ 2 ] == 's') && ( uart_2.rx[ 3 ] == 'y') )
    {
        FS_TX_LORA_BUSY = 1;
    }
    else if (( uart_2.rx[ 0 ] == 'i') && ( uart_2.rx[ 1 ] == 'n') && ( uart_2.rx[ 2 ] == 'v'))
    {
        FS_TX_LORA_INV = 1;
    }
    else if (( uart_2.rx[ 0 ] == 'm') && ( uart_2.rx[ 1 ] == 'a') && ( uart_2.rx[ 2 ] == 'c')
         && ( uart_2.rx[ 3 ] == '_') && ( uart_2.rx[ 4 ] == 'r') && ( uart_2.rx[ 5 ] == 'x') && ( uart_2.rx[ 6 ] == ' ')
         && ( uart_2.rx[ 7 ] == '1') && ( uart_2.rx[ 8 ] == '0') && ( uart_2.rx[ 9 ] == '0') && ( uart_2.rx[ 10 ] == ' '))
    {
        FS_RX_MAC_OK = 1; // tramiss�o sem sucesso
    }
    else if (( uart_2.rx[ 0 ] == 'n') && ( uart_2.rx[ 1 ] == 'o') && ( uart_2.rx[ 2 ] == 't')
         && ( uart_2.rx[ 3 ] == '_') && ( uart_2.rx[ 4 ] == 'j') && ( uart_2.rx[ 5 ] == 'o') && ( uart_2.rx[ 6 ] == 'i')
                && ( uart_2.rx[ 7 ] == 'n') && ( uart_2.rx[ 8 ] == 'e') && ( uart_2.rx[ 9 ] == 'd'))
    {
        FS_TX_NOT_JOINED = 1; // tramiss�o sem sucesso
    }
    else if (( uart_2.rx[ 0 ] == 'n') && ( uart_2.rx[ 1 ] == 'o') && ( uart_2.rx[ 2 ] == '_')
         && ( uart_2.rx[ 3 ] == 'f') && ( uart_2.rx[ 4 ] == 'r') && ( uart_2.rx[ 5 ] == 'e') && ( uart_2.rx[ 6 ] == 'e')
                && ( uart_2.rx[ 7 ] == '_') && ( uart_2.rx[ 8 ] == 'c') && ( uart_2.rx[ 9 ] == 'h'))
    {
        FS_TX_NOT_FREE_CH = 1; // tramiss�o sem sucesso
    }
    else
    {
        aux.value = ascii_para_dec( &uart_2.rx[0], busca_tam_numero_buffer (&uart_2.rx[0]));
    }
    uart_2.tam_rx = 0;

    return ( aux.value);
}

/****************************************************************************************\
 * trata_pct_uart3_rx                                                                  *
 * Rotina para tratamento do pacote serial recebido. Os pacotes recebidos aqui referem- *
 * se aos dados enviados pelo leitor de c�digo de barras                                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
unsigned long trata_pct_uart3_rx( void )
{
    union unsigned_int aux;
    aux.value = 0;

    #ifdef ENVIA_KWH
    if ( uart_3.rx[ 0 ] == 0x23)
    {
        aux.value = bcd_para_dec(uart_3.rx[9]);
        aux.value += bcd_para_dec(uart_3.rx[8])*100;
        aux.value += bcd_para_dec(uart_3.rx[7])*10000;
        aux.value += bcd_para_dec(uart_3.rx[6])*1000000;
        aux.value += bcd_para_dec(uart_3.rx[5])*100000000;
        dados.kwh = aux.value;
        FS_UART3_DATA_OK = 1;
    }
    #endif

    #ifdef ENVIA_SONAR
    #define QTD_MEDIA_SONAR 16
    static unsigned int buffer_valor[ QTD_MEDIA_SONAR ];
    static unsigned char ponteiro = 0;
    unsigned char i;
    if (( uart_3.rx[ 0 ] == 'R') && ( uart_3.rx[ 3 ] == 0x0D))
    {        
        aux.value = ascii_para_dec( &uart_3.rx[1], busca_tam_numero_buffer (&uart_3.rx[1]));
        buffer_valor[ponteiro] = aux.value;

        ponteiro++;
        if (ponteiro == QTD_MEDIA_SONAR)
        {
            ponteiro = 0;
        }
        aux.value = 0;
        for( i = 0 ; i < QTD_MEDIA_SONAR ; i++ )
        {
            aux.value += buffer_valor[i];
        }
        dados.nivel_sonar = aux.value /  QTD_MEDIA_SONAR;
    }
    #endif

    uart_3.tam_rx = 0;
    return ( aux.value);
}


unsigned long busca_tam_numero_buffer( unsigned char *buffer )
{
    unsigned char c;
    unsigned char tamanho = 0;

    while( sizeof(buffer) )
    {
        c = *buffer++;
        if( ( c < '0' ) || ( c > '9' ) )
        {
            return( tamanho );
        }
        tamanho++;

    }
    return( tamanho );
}

/****************************************************************************************\
 * trata_pct_uart1_rx                                                                  *
 * Rotina para tratamento do pacote serial recebido. Os pacotes recebidos aqui referem- *
 * se aos dados enviados pelo leitor de c�digo de barras                                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
unsigned long trata_pct_uart1_rx( void )
{
    union unsigned_int aux;
    aux.value = 0;

    #ifdef ENVIA_RFID
    unsigned char i = 0;
    if ( ( uart_1.rx[ 0 ] == 0x02) && ( uart_1.rx[ 13 ] == 0x03) )
    {
        for ( i = 0; i < 10; i++)
        {
            dados.rfid[i] = uart_1.rx[ i + 1 ];
        }
        FS_UART1_DATA_OK = 1;
    }
    #endif

    #ifdef ENVIA_GPS
    if (uart_1.rx[0] == '$')
    {
        // FAZER A TRATATIVA DOS DADSO RECEBIDOS DO MODULO GPS AQUI
        parseGpsRxMsg();
        processGpsRxMsg();
    }
    #endif

    uart_1.tam_rx = 0;
    return ( aux.value);
}


/****************************************************************************************\
 * inicializa_sw     													                *
 * Rotina de inicializa��o do software                          		                *
 *                                                                                      *
 * Par�metros: void														                *
 * Retorno   : void														                *
\****************************************************************************************/
void inicializa_sw( void )
{
    inicializa_fw();
}

/****************************************************************************************\
 * tx_valor_trace     													                *
 * Rotina que transmite um valor, com ou sem casas decimais, pela serial de trace       *
 *                                                                                      *
 * Par�metros: valor num�rico e n�mero de casas decimais                                *
 * Retorno   : void														                *
\****************************************************************************************/
#if( TRACE_HABILITADO == SIM )

void tx_valor_trace( long valor, unsigned char casas_decimais )
{
    unsigned char buf[ TAM_BUFFER_ASC + 5 ];

    formata_menu.str_valor( valor, casas_decimais, 0, DESPREZA_ZEROS_ESQUERDA, buf );
    tx_string_porta_serial( buf );
}
#endif


/*
---$GPRMC,225446,A,4916.45,N,12311.12,W,000.5,054.7,191194,020.3,E*68
    225446       Time of fix 22:54:46 UTC
    A            Navigation receiver warning A = OK, V = warning
    4916.45,N    Latitude 49 deg. 16.45 min North
    12311.12,W   Longitude 123 deg. 11.12 min West
    000.5        Speed over ground, Knots
    054.7        Course Made Good, True
    191194       Date of fix  19 November 1994
    020.3,E      Magnetic variation 20.3 deg East
    *68          mandatory checksum
 */
//Global structures used in deep sleep library
#ifdef DISPLAY_SPI

        #define NUMFLAKES 10
        #define XPOS 0
        #define YPOS 1
        #define DELTAY 2
        #define LOGO16_GLCD_HEIGHT 16
        #define LOGO16_GLCD_WIDTH  16
//        const unsigned char  logo16_glcd_bmp[] =
//        { 0b00000000, 0b11000000,
//          0b00000001, 0b11000000,
//          0b00000001, 0b11000000,
//          0b00000011, 0b11100000,
//          0b11110011, 0b11100000,
//          0b11111110, 0b11111000,
//          0b01111110, 0b11111111,
//          0b00110011, 0b10011111,
//          0b00011111, 0b11111100,
//          0b00001101, 0b01110000,
//          0b00011011, 0b10100000,
//          0b00111111, 0b11100000,
//          0b00111111, 0b11110000,
//          0b01111100, 0b11110000,
//          0b01110000, 0b01110000,
//          0b00000000, 0b00110000 };
        #if (SSD1306_LCDHEIGHT != 64)
        #error("Height incorrect, please fix Adafruit_SSD1306.h!");
        #endif
        // by default, we'll generate the high voltage from the 3.3v line internally! (neat!)

void testdrawbitmap(const unsigned char *bitmap, unsigned char w, unsigned char h) {
  unsigned char icons[NUMFLAKES][3];
unsigned char f;
  // initialize
  for (  f=0; f< NUMFLAKES; f++) {
    icons[f][XPOS] = (width());
    icons[f][YPOS] = 0;
    icons[f][DELTAY] = 6;

  }

  while (1) {
      unsigned char f;
    // draw each icon
    for (  f=0; f< NUMFLAKES; f++) {
      drawBitmap(icons[f][XPOS], icons[f][YPOS], bitmap, w, h, WHITE);
    }
    display();
    delay_ms(200);

    // then erase it + move it
    for (  f=0; f< NUMFLAKES; f++) {
       drawBitmap(icons[f][XPOS], icons[f][YPOS], bitmap, w, h, BLACK);
      // move it
      icons[f][YPOS] += icons[f][DELTAY];
      // if its gone, reinit
      if (icons[f][YPOS] > height()) {
        icons[f][XPOS] = width();
        icons[f][YPOS] = 0;
        icons[f][DELTAY] = 6;
      }
    }
   }
}
void escreve_texto_lcd_flash( int x, int y, const unsigned char *buffer, unsigned char size, unsigned int color  )
{
    setTextSize(size);
    setTextColor(color);

    if ((x != -1) && (y != -1))
    {
        setCursor(x,y);
    }

    while( *buffer != '\0')
    {
        write(  *buffer++);
    }
}

void escreve_texto_lcd( int x, int y, unsigned char *buffer, unsigned char size, unsigned int color )
{
    setTextSize(size);
    setTextColor(color);

    if ((x != -1) && (y != -1))
    {
        setCursor(x,y);
    }

    while(*buffer != '\0' )
    {
        write(  *buffer++);
    }
}

void testdrawchar(void) {
  setTextSize(1);
  setTextColor(WHITE);
  setCursor(0,0);
unsigned char i;

  for (  i=0; i < 168; i++) {
    if (i == '\n') continue;
    write(i);
//    if ((i > 0) && (i % 21 == 0))
//      println();
  }
  display();
}

void testdrawcircle(void) {
    int i;
  for (  i=0; i<height(); i+=2) {
    drawCircle(width()/2, height()/2, i, WHITE);
    display();
  }
}

void testfillrect(void) {
  unsigned char color = 1;
  int i;
  for (  i=0; i<height()/2; i+=3) {
    // alternate colors
    fillRect(i, i, width()-i*2, height()-i*2, color%2);
    display();
    color++;
  }
}

void testdrawtriangle(void) {
    int i;
  for (  i=0; i< min(width(),height())/2; i+=5)
  {
    drawTriangle(width()/2, height()/2-i,
                     width()/2-i, height()/2+i,
                     width()/2+i, height()/2+i, WHITE);
    display();
  }
}

void testfilltriangle(void) {
  unsigned char color = WHITE;
  int i;
  for (  i=min(width(),height())/2; i>0; i-=5) {
    fillTriangle(width()/2, height()/2-i,
                     width()/2-i, height()/2+i,
                     width()/2+i, height()/2+i, WHITE);
    if (color == WHITE) color = BLACK;
    else color = WHITE;
    display();
  }
}

void testdrawroundrect(void) {
    int i;
  for (  i=0; i<height()/2-2; i+=2) {
    drawRoundRect(i, i, width()-2*i, height()-2*i, height()/4, WHITE);
    display();
  }
}

void testfillroundrect(void) {
  unsigned char color = WHITE;
int i;
for (  i=0; i<height()/2-2; i+=2) {
    fillRoundRect(i, i, width()-2*i, height()-2*i, height()/4, color);
    if (color == WHITE) color = BLACK;
    else color = WHITE;
    display();
  }
}

void testdrawrect(void) {
int i;
for (  i=0; i<height()/2; i+=2) {
    drawRect(i, i, width()-2*i, height()-2*i, WHITE);
    display();
  }
}

void testdrawline() {
int i;
for (  i=0; i<width(); i+=4) {
    drawLine(0, 0, i, height()-1, WHITE);
    display();
  }
  for (  i=0; i<height(); i+=4) {
    drawLine(0, 0, width()-1, i, WHITE);
    display();
  }
  delay_ms(250);

  clearDisplay();
    drawLine(0, height()-1, i, 0, WHITE);
    display();

  for (  i= (height()-1); i>=0; i-=4)
  {
    drawLine(0, height()-1, width()-1, i, WHITE);
    display();
  }
  delay_ms(250);

  clearDisplay();
  for (  i=width()-1; i>=0; i-=4) {
    drawLine(width()-1, height()-1, i, 0, WHITE);
    display();
  }
  for (  i=height()-1; i>=0; i-=4) {
    drawLine(width()-1, height()-1, 0, i, WHITE);
    display();
  }
  delay_ms(250);

  clearDisplay();
  for (  i=0; i<height(); i+=4) {
    drawLine(width()-1, 0, 0, i, WHITE);
    display();
  }
  for (  i=0; i<width(); i+=4) {
    drawLine(width()-1, 0, i, height()-1, WHITE);
    display();
  }
  delay_ms(250);
}

void testscrolltext(void) {
  setTextSize(2);
  setTextColor(WHITE);
  setCursor(10,0);
  clearDisplay();
  //println("scroll");
  display();

  startscrollright(0x00, 0x0F);
  delay_ms(2000);
  stopscroll();
  delay_ms(1000);
  startscrollleft(0x00, 0x0F);
  delay_ms(2000);
  stopscroll();
  delay_ms(1000);
  startscrolldiagright(0x00, 0x07);
  delay_ms(2000);
  startscrolldiagleft(0x00, 0x07);
  delay_ms(2000);
  stopscroll();
}
#endif

/****************************************************************************************\
 * atualiza_acelerador     				                                                    *
 * Rotina para chavear as sa�das botton da ponte H do brushless                         *
 *                                                                                      *
 * Par�metros: void             					                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void atualiza_pwm_1 ( unsigned int esforco )
{
    configura_pwm_1( esforco );
}

void configura_pwm_1( unsigned int dc)
{
    configura_pwm_hw( PWM_HW_0, dc );  // ligado em dc%
}

unsigned char verifica_estabilidade( unsigned char opcao )
{
    static unsigned int buffer[CONTROLE_TOTAL_PID] = {0};
    static unsigned char contador_hi[CONTROLE_TOTAL_PID] = {0};
    static unsigned char contador_lo[CONTROLE_TOTAL_PID] = {0};
    static unsigned char histerese[CONTROLE_TOTAL_PID] = {40};
    static unsigned char retorno_anterior[CONTROLE_TOTAL_PID] = {INSTAVEL };

    static unsigned int var_controle = 0;

    switch (opcao)
    {
        case PID_1:
            var_controle = dados.valor_pid1_atual;
            buffer[ opcao ] = dados.setup.setpoint_pid1;
            break;
        default:
            var_controle = 0;
            break;
    }

    if (( buffer[ opcao ] <= var_controle + histerese[opcao]) && ( buffer[ opcao ] + histerese[opcao] >= var_controle) )// janela de histerese de +-20 rpm
    {
        contador_lo[ opcao ] = 0;
        contador_hi[ opcao ]++;
        if (contador_hi[ opcao ] >= QTD_MEDIA_ESTABILIDADE )
        {
            contador_hi[ opcao ] = 0;
            retorno_anterior[ opcao ] = ESTAVEL;
        }
    }
    else
    {
        contador_hi[ opcao ] = 0;
        contador_lo[ opcao ]++;
        if (contador_lo[ opcao ] >= QTD_MEDIA_ESTABILIDADE )
        {
            contador_lo[ opcao ] = 0;
            retorno_anterior[ opcao ] = INSTAVEL;
        }
    }

return ( retorno_anterior[ opcao ] );
}

