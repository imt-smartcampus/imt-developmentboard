/****************************************************************************************\
 * 	                         software LORA node                                       *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#ifndef APP_H
#define	APP_H

/********************************************\
 *          setup de aplica��o                *
\********************************************/
//CONFIGURA��O ESSENCIAL
#define APPSKEY                         "2b7e151628aed2a6abf7158809cf4f3c"
#define NWKSKEY                         "2b7e151628aed2a6abf7158809cf4f3c"

//#define DEEP_SLEEP_1MINUTO           // comentar para enviar a cada 8 minutos
//#define NUNCA_DORME                   // comentar para usar pid sempre alerta

//CONFIGURA��O ESPEC�FICA - N�O USAR
//#define ESPECIFICAR_EUI_PROPRIO                           // comentar, pois � melhor usar o eui de fabrica
#ifdef ESPECIFICAR_EUI_PROPRIO
    #define EUI_PROPRIO                   "0004a30b001a5ea3" // 16 bytes em ascii ex "000ef57f3b456763"
#endif

//#define ESPECIFICAR_DEVADDR_PROPRIO                         // comentar, pois � melhor usar o devaddr como parte do eui de fabrica
#ifdef ESPECIFICAR_DEVADDR_PROPRIO
    #define DEVADDR_PROPRIO                   "001a5ea3" // ultimos 8 bytes em ascii do EUI_PROPRIO ex "3b456763"
#endif

// DEFINE SE A MENSAGEM � DO TIPO CONFIRMADA OU N�O CONFIRMADA (NAO CONFIRMADA � MAIS RAPIDA E GASTA MENOS ENERGIA)
#define ENVIA_UNCNF                                         // comente para enviar mensagem confirmada
    #ifndef ENVIA_UNCNF
    #define ENVIA_CNF
    #endif

//#define ATIVA_PID
    #ifdef ATIVA_PID
        #define PWM_ON_RB15     // pwm para criar sensor capacitivo em RB15 com leitura em AN12 (na� usar com BUZZER_ON_RB15)
    #endif

//#define EEPROM_ON


//#define CAPACITIVO_ON_RB15      // usado pra criar buzzer ou sensor capacitivo
    #ifdef CAPACITIVO_ON_RB15
        #define PWM_ON_RB15 // pwm para criar sensor capacitivo em RB15 com leitura em AN12 (na� usar com BUZZER_ON_RB15)
    #endif
//#define BUZZER_ON_RB15      // usado pra criar buzzer ou sensor capacitivo
    #ifdef BUZZER_ON_RB15
        #define PWM_ON_RB15 // pwm para criar sensor capacitivo em RB15 com leitura em AN12 (na� usar com BUZZER_ON_RB15)
    #endif

//#define DISPLAY_SPI

//#define ENVIA_ENCODER
    #ifdef ENVIA_ENCODER
        #define INT0_TXLORA_SEMPRE  // MANDA PARA O LORAWAN CADA ACIONAMENTO DO int0, POR EX. BOTAO EMERGENCIA
    #endif

// DEFINE QUAIS PACOTES DE DADOS SER�O ENVIADOS
// *** sempre mandar ENVIA_VBAT_VIA_RN2903 ***

//#define ENVIA_SENSOR_INT0             //  usado para enviar a posi��o da chave que aciona o INT0 (contato de porta por ex.)
    #ifdef ENVIA_SENSOR_INT0
        #define INT0_TXLORA_SEMPRE  // MANDA PARA O LORAWAN CADA ACIONAMENTO DO int0, POR EX. BOTAO EMERGENCIA
    #endif

//#define ENVIA_CONTADOR_PERMANENTE     // manda contador no INT0 a cada X tempo     "0bCCCCCC" (hidrometros, pulsos etc)

//define ENVIA_AN10                    //manda AN10                    "0dVVVV
        #ifdef ENVIA_AN10
            //#define AN10_NTC10K
            #define AN10_PT100
            //#define AN10_4_20MA
        #endif
//#define ENVIA_AN11                    //manda AN11                    "0dVVVV
        #ifdef ENVIA_AN11
            #define AN11_NTC10K
            //#define AN11_PT100
            #define AN11_4_20MA
        #endif
//#define ENVIA_AN12                    //manda AN12                    "0dVVVV
        #ifdef ENVIA_AN12
            #define AN12_NTC10K
           // #define AN12_PT100
           // #define AN12_4_20MA
        #endif
//#define ENVIA_AN13                    //manda AN13                    "0dVVVV
        #ifdef ENVIA_AN13
            #define AN13_NTC10K
           // #define AN13_PT100
           // #define AN13_4_20MA
        #endif
//#define ENVIA_AN14                    //manda AN14                    "0dVVVV
        #ifdef ENVIA_AN14
           // #define AN14_NTC10K
           // #define AN14_PT100
            #define AN14_4_20MA
        #endif
//#define ENVIA_AN15                    //manda AN15                    "0dVVVV
        #ifdef ENVIA_AN15
           // #define AN15_NTC10K
            #define AN15_PT100
            #define AN15_4_20MA
        #endif

//#define ENVIA_SENSOR_COR              // envia sensor de cor de pois de ter calculado o Delta com AN12 do sensor capacitivo
//#define ENVIA_SONAR                   //manda VALOR RX VIA UART      "0dVVVV
//#define ENVIA_GIROSCOPIO              // manda Girosc�pio             "05xxxxyyyyzzzz"
#define ENVIA_GPS                       // manda GPS "0A LL DD DD DD ll dd dd dd"   (E9 09E2E6 B6 57D61B) = (-23.6479102,-46.5756443)
    #ifdef ENVIA_GPS
        #define AGUARDA_ESTABILIZACAO
    #endif

//#define ENVIA_KWH                       //manda kw/h recebido via uart3 "0eWWWWWW"

//#define ENVIA_DHT22                   //manda TEMP E UMID             "01TTTT02UUUU"
    #ifdef ENVIA_DHT22
        #define ENVIA_DHT
    #endif
//#define ENVIA_DHT11                 //manda TEMP E UMID             "01TTTT02UUUU"
    #ifdef ENVIA_DHT11
        #define ENVIA_DHT
    #endif

//#define ENVIA_RFID                //manda RFID             "0eTTTT02UUUU"

//#define AGUARDA_ESTABILIZACAO                //AGUARDA x SEGUNDOS
    #ifdef AGUARDA_ESTABILIZACAO
        #ifdef ENVIA_GPS
            #define TIMEOUT_ESTABILIZACAO   6000         // 1000 x 10ms = 10s
        #else
            #define TIMEOUT_ESTABILIZACAO   1500         // 1000 x 10ms = 10s
        #endif
    #endif

//sempre deixar esse habilitado
#define ENVIA_VBAT_VIA_RN2903       //manda Vbat                    "0cVVVV"


// Total de canais:
#ifdef ENVIA_AN15
    #define ADC_NUM_CANAIS              6
#else
    #ifdef ENVIA_AN14
        #define ADC_NUM_CANAIS              5
    #else
       #ifdef ENVIA_AN13
            #define ADC_NUM_CANAIS              4
        #else
            #ifdef ENVIA_AN12
                #define ADC_NUM_CANAIS              3
            #else
                #ifdef ENVIA_AN11
                    #define ADC_NUM_CANAIS              2
                #else
                    #define ADC_NUM_CANAIS              1       // s� an12
                #endif
            #endif
        #endif
    #endif
#endif

#define PWM_HW_DUTY     500

#endif	/* APP_H */

