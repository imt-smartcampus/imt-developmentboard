
/*
 * Control Pins
 * */
#include "../fw/fw.h"


/*
 * Software SPI Macros
 * */

#define spiRead() le_byte_spi1_master_hw()
#define spiWrite(dado) escreve_byte_spi1_master_hw( dado)


#define SSPI_BEGIN_TRANSACTION()
#define SSPI_END_TRANSACTION()
#define SSPI_WRITE(v)           spiWrite(v)
#define SSPI_WRITE16(s)         SSPI_WRITE((s) >> 8); SSPI_WRITE(s)
#define SSPI_WRITE32(l)         SSPI_WRITE((l) >> 24); SSPI_WRITE((l) >> 16); SSPI_WRITE((l) >> 8); SSPI_WRITE(l)

/*
 * Hardware SPI Macros
 * */

//#define SPI_OBJECT  SPI
//#define HSPI_SET_CLOCK()
//
//#define HSPI_BEGIN_TRANSACTION() HSPI_SET_CLOCK()
//#define HSPI_END_TRANSACTION()

// Standard Byte-by-Byte SPI

//#define HSPI_WRITE16(s)          HSPI_WRITE((s) >> 8); HSPI_WRITE(s)
//#define HSPI_WRITE32(l)          HSPI_WRITE((l) >> 24); HSPI_WRITE((l) >> 16); HSPI_WRITE((l) >> 8); HSPI_WRITE(l)
//#define HSPI_WRITE_PIXELS(c,l)   for(unsigned lond i=0; i<(l); i+=2){ HSPI_WRITE(((unsigned char*)(c))[i+1]); HSPI_WRITE(((unsigned char*)(c))[i]); }
//
//
//#define SPI_BEGIN()             if(_sclk < 0){SPI_OBJECT.begin();}
//#define SPI_BEGIN_TRANSACTION() if(_sclk < 0){HSPI_BEGIN_TRANSACTION();}
//#define SPI_END_TRANSACTION()   if(_sclk < 0){HSPI_END_TRANSACTION();}
#define SPI_WRITE16(s)          SSPI_WRITE16(s)
#define SPI_WRITE32(l)          SSPI_WRITE32(l)

