/****************************************************************************************\
 * 	                          firmware LORA node                                      *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#include "fw.h"


// PIC24FJ128GA306 Configuration Bit Settings
#if( defined( MODO_DEBUG ) )
_CONFIG1( WDTPS_PS16384 & FWPSA_PR128 & WINDIS_OFF & ICS_PGx1 & GWRP_OFF & GCP_OFF & JTAGEN_OFF & FWDTEN_WDT_DIS )
_CONFIG2( IOL1WAY_ON & FCKSM_CSDCMD & FNOSC_FRC & IESO_OFF & POSCMD_HS )
_CONFIG3( WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM & SOSCSEL_OFF )
_CONFIG4( DSSWEN_OFF & DSWDTEN_OFF & DSBOREN_OFF )
#else
_CONFIG1( WDTPS_PS8192 & FWPSA_PR128  & WINDIS_OFF & ICS_PGx1 & GWRP_OFF & GCP_OFF & JTAGEN_OFF & FWDTEN_WDT_SW & LPCFG_ON )
_CONFIG2( BOREN1_EN & OSCIOFCN_OFF & IOL1WAY_ON & FCKSM_CSDCMD & FNOSC_FRC & IESO_OFF & POSCMD_NONE & ALTVREF_DLT_AV_DLT_CV )
_CONFIG3( WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM & SOSCSEL_OFF )

#ifdef DEEP_SLEEP_1MINUTO
    _CONFIG4( DSWDTPS_DSWDTPS10 & DSWDTOSC_LPRC & DSBOREN_ON & DSWDTEN_ON & DSSWEN_ON )
#else
    _CONFIG4( DSWDTPS_DSWDTPS14 & DSWDTOSC_LPRC & DSBOREN_ON & DSWDTEN_ON & DSSWEN_ON )
#endif

// tambem mudar o sleep do modulo rn2903
//"sys sleep 900000\r\n"); //900 segundos de sleep

#endif
/****************************************************************************************\
 * 	  	                            Configuration Bits                                 	*
\****************************************************************************************/

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do software em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao firmware:


// - Globais ao sistema:


/****************************************************************************************\
 *   		                 Defini��o de vari�veis de flag             		        *
\****************************************************************************************/

union unsigned_char flags_fw;


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do software em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao firmware:

// - Globais ao sistema:
//==================================================================================
//== INST�NCIA DAS VARI�VEIS GLOBAIS DECLARADAS NESTE M�DULO                      ==
//==================================================================================


/****************************************************************************************\
 *                                         Traps                                        *
\****************************************************************************************/

void _ISR_NO_PSV _OscillatorFail( void )
{
    INTCON1bits.OSCFAIL = 0;

    #if( TRACE_HABILITADO == SIM )
    tx_string_flash_porta_serial( ( const unsigned char * )"OscillatorFail\r\n" );
    #endif
}

void _ISR_NO_PSV _AddressError( void )
{
    INTCON1bits.ADDRERR = 0;

    #if( TRACE_HABILITADO == SIM )
    tx_string_flash_porta_serial( ( const unsigned char * )"AddressError\r\n" );
    #endif
}

void _ISR_NO_PSV _StackError( void )
{
    INTCON1bits.STKERR = 0;

    #if( TRACE_HABILITADO == SIM )
    tx_string_flash_porta_serial( ( const unsigned char * )"StackError\r\n" );
    #endif
}

void _ISR_NO_PSV _MathError( void )
{
    INTCON1bits.MATHERR = 0;

    #if( TRACE_HABILITADO == SIM )
    tx_string_flash_porta_serial( ( const unsigned char * )"MathError\r\n" );
    #endif
}

unsigned char pic_init(void)
{
    unsigned char Result = 0;
            
    dados.upctr = ((0xFF00 & DSGPR1)>>8);
    dados.contador_permanente = DSGPR0;
    dados.contador_permanente += ((long)(0x00FF & DSGPR1)<<16);
   
    if (RCONbits.DPSLP)
    {
        if(DSWAKEbits.DSMCLR==TRUE)
        {
            Result = 1;
        //deep sleep wakeup source is MCLR
        }
        else if(DSWAKEbits.DSRTCC==TRUE)
        {
            Result = 2;
        //deep sleep wakeup source is RTCC
        }
        else if(DSWAKEbits.DSWDT==TRUE)
        {
            Result = 3;
        //deep sleep wakeup source is DSWDT
        }
        else if(DSWAKEbits.DSFLT==TRUE)
        {
            Result = 4;
        //deep sleep wakeup source is Falut in deep sleep configuration
        }
        else if(DSWAKEbits.DSINT0==TRUE)
        {//deep sleep wakeup source is INT0
            Result = 5;
        }
        else if(DSCONbits.DSBOR==TRUE)
        {
            Result = 6;
        //deep sleep wakeup source is DSBOR
        }
        else
        {
            Result = 7;
        }
    }
    else if(RCONbits.SLEEP)
    {
        Result=8;
        RCONbits.SLEEP = 0;
        DSCONbits.RELEASE = 0;
    }
    else if(RCONbits.WDTO)
    {
        Result=9;
        RCONbits.WDTO = 0;
        DSCONbits.RELEASE = 0;
    }
    else if(RCONbits.EXTR)
    {
        Result=10;
        RCONbits.EXTR = 0;
        DSCONbits.RELEASE = 0;
    }
    else if(RCONbits.SWR)
    {
        Result=11;
        RCONbits.SWR = 0;
        DSCONbits.RELEASE = 0;
    }
    else if(RCONbits.POR)
    {
        Result=12;
        RCONbits.POR = 0;
        DSGPR0 = 0;
        DSGPR1 = 0;
    }
    else
    { //Unknown state
        Result = 0;         /* assume we are a Power On reset */
        DSGPR0 = 0;
        DSGPR0 = 0;
        DSGPR1 = 0;
        DSGPR1 = 0;
    }

    RCONbits.DPSLP = 0;
    DSCONbits.RELEASE = 0;
    DSCONbits.RELEASE = 0;
   
    return (Result);
}


/****************************************************************************************\
 *                                  Vetor de interrup��o    	                        *
\****************************************************************************************/

/****************************************************************************************\
 *                          RTCC Interrupt Service Routine -                         *
 *                                                                                      *
 * Descri��o: entra quanto receber borda de descida do contador                         *
 * Prioridade: 4 (normal)                                                               *
\****************************************************************************************/

// service routine
void _ISR_NO_PSV _RTCCInterrupt(void)
{
    IFS3bits.RTCIF = 0;
}


/****************************************************************************************\
 *                          INT1 Interrupt Service Routine - BT1                        *
 *                                                                                      *
 * Descri��o: entra quanto receber borda de descida do contador                         *
 * Prioridade: 4 (normal)                                                               *
\****************************************************************************************/
void _ISR_NO_PSV _INT0Interrupt( void )
{
    IFS0bits.INT0IF = 0;                              // Limpa flag de interrup��o INT1
    dados.contador_permanente++;
    TRISGbits.TRISG9 = 0;
    LED_STATUS = 1;
    delay_us(100);
    LED_STATUS = 0;
    #ifdef ENVIA_ENCODER
        dados.inicializacao_especial = 0;
    #endif

}


/****************************************************************************************\
 *                          INT1 Interrupt Service Routine - BT1                        *
 *                                                                                      *
 * Descri��o: entra quanto receber o pressionamento do bot�o                             *
 * Prioridade: 4 (normal)                                                               *
\****************************************************************************************/
void _ISR_NO_PSV _INT1Interrupt( void )
{
    IFS1bits.INT1IF = 0;                              // Limpa flag de interrup��o INT1

    if( INTCON2bits.INT1EP == 1 )
    {
        FF_BT1 = 1; // Borda de descida: BT1 press
    }
    else
    {       
        FF_BT1 = 0; // Borda de subida: BT1 lib
    }
    INTCON2bits.INT1EP ^= 1;
}

/****************************************************************************************\
 *                              Implementa��o das fun��es                               *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_fw            				                                            *
 * Rotina de inicializa��o do firmware-base                                             *
 *                                                                                      *
 * Par�metros: void             					                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void inicializa_fw( void )
{
    unsigned char aux = 0;

    CLKDIV = 0x0100;    /* set for 4MHz FRC oscillator */
    RCFGCALbits.RTCEN = 0; //ERRATA

    /*** TRISes, PORTs e LATCHs: ***/
    PORTB  = 0x0FF7;
    PORTC  = 0x0000;
    PORTD  = 0xFBBE;
    PORTE  = 0x0000;
    PORTF  = 0xFFFF;
    PORTG  = 0x0000;

    LATB  = 0x4FF7;
    LATC  = 0x0000;
    LATD  = 0xFBBE;
    LATE  = 0x0000;
    LATF  = 0xFFFF;
    LATG  = 0x0000;

    TRISB  = 0x0FF7;
    TRISC  = 0x0000;
    TRISD  = 0xFA3C;
    TRISE  = 0x0000;
    TRISF  = 0xFFFB;
    TRISG  = 0x0000;

    #ifdef ENVIA_AN10
        TRIS_AN_RB10 = 1;
    #endif
    #ifdef ENVIA_AN11
        TRIS_AN_RB11 = 1;
    #endif
    #ifdef ENVIA_AN12
        TRIS_AN_RB12 = 1;
    #endif
    #ifdef ENVIA_AN13
        TRIS_AN_RB13 = 1;
    #endif
    #ifdef ENVIA_AN14
        TRIS_AN_RB14 = 1;
    #endif
    #ifdef ENVIA_AN15
        TRIS_AN_RB15 = 1;
    #endif

    PORTB  = 0x4FF7;
    PORTC  = 0x0000;
    PORTD  = 0xFBBE;
    PORTE  = 0x0000;
    PORTF  = 0xFFFF;
    PORTG  = 0x0000;

    LATB  = 0x4FF7;
    LATC  = 0x0000;
    LATD  = 0xFBBE;
    LATE  = 0x0000;
    LATF  = 0xFFFF;
    LATG  = 0x0000;

    ANSB  = 0x0000;                                 // RB12 como anal�gico
    #ifdef ENVIA_AN10
        ANSB  = (ANSB | 0x0400);                                 // RB10 como anal�gico
    #endif
    #ifdef ENVIA_AN11
        ANSB  = (ANSB | 0x0800);                                 // RB11 como anal�gico
    #endif
    #ifdef ENVIA_AN12
        ANSB  = (ANSB | 0x1000);                                 // RB12 como anal�gico
    #endif
    #ifdef ENVIA_AN13
        ANSB  = (ANSB | 0x2000);                                 // RB12 como anal�gico
    #endif
    #ifdef ENVIA_AN14
        ANSB  = (ANSB | 0x4000);                                 // RB12 como anal�gico
    #endif
    #ifdef ENVIA_AN15
        ANSB  = (ANSB | 0x8000);                                 // RB12 como anal�gico
    #endif

    ANSD  = 0x0000;                                 // Demais como digitais
    ANSE  = 0x0000;                                 // Demais como digitais
    ANSG  = 0x0000;                                 // Demais como digitais

    ODCB = 0x0000;                                  // Nenhum pino como open drain
    ODCC = 0x0000;                                  // Nenhum pino como open drain
    ODCD = 0x0000;                                  // Nenhum pino como open drain
    ODCE = 0x0000;                                  // Nenhum pino como open drain
    ODCF = 0x0000;                                  // 

    DSCONbits.DSEN = 0; //set the deep sleep enable bit
    DSCONbits.DSEN = 0;
    DSCONbits.RELEASE = 0;
    DSCONbits.RELEASE = 0;


    desliga_perifericos(); // garente restart perfeito geral
    liga_app();         // liga transistor de alimenta��o 3v3 para

    // WDT & estabilishment
    #if( defined( MODO_DEBUG ) )
    RCONbits.SWDTEN = 0;
    #else
    RCONbits.SWDTEN = 1;
    #if( defined( AGUARDA_ESTABILIZA_SISTEMA ) )
    while( !RCONbits.WDTO )
        ;
    #endif
    #endif

    // Zera vari�veis
    flags_fw.value = 0;

    liga_perifericos();

#ifdef EEPROM_ON
    le_byte_eeprom_spi( END_EEPROM_USO_GERAL + OFFSET_USO_GERAL_TESTE_MEMORIA ); // dummy byte
    aux = le_byte_eeprom_spi( END_EEPROM_USO_GERAL + OFFSET_USO_GERAL_TESTE_MEMORIA );
    if( aux != MEMORIA_NAO_INICIADA )
    {
        carrega_setup_default();
        salva_setup();
    }
    le_setup();
#else
    carrega_setup_default();
#endif

    #ifdef ATIVA_PID
        inicializa_controle();
        configura_registros_controle( 1, 1, 1 ); // r�pido, NAO USAR ZERO
    #endif
}

void desabilita_interrupcoes( void )
{
    // Desabilita todas as interrup��es
    //IEC0 = 0x0000;                              // DESABLE INT0
    IEC1 = 0x0000;
    IEC2 = 0x0000;
    //IEC3 = 0x0000;
    IEC4 = 0x0000;
    IEC5 = 0x0000;
    IEC6 = 0x0000;
    IEC7 = 0x0000;
    //IFS0 = 0x0000;                              // FLAG INT0 = 0
    IFS1 = 0x0000;
    IFS2 = 0x0000;
    //IFS3 = 0x0000;
    IFS4 = 0x0000;
    IFS5 = 0x0000;
    IFS6 = 0x0000;
    IFS7 = 0x0000;

    INTCON1 = 0x8000;                               // Nesting desabilitado
    INTCON2 = 0x0001;                               // INT0 borda de descida
}

void liga_perifericos( void )
{

    reset_LoRa();
    #ifdef ENVIA_DHT    //manda TEMP E UMID             "01TTTT02UUUU"
    atualiza_leitura_dht(); // le dth22 antes de qualquer inicializa��o
    #endif

    #ifdef DISPLAY_SPI
    inicializa_spi1_master_hw();
    #else
        #ifndef ENVIA_ENCODER
            inicializa_i2c2_master_hw();
        #endif
    #endif

    inicializa_adc(ADC_ON);
    inicializa_timer();

    #ifdef PWM_ON_RB15
        RPOR14bits.RP29R  = 18;                     // OC1 no pino RB15
        inicializa_pwm_hw();
        configura_pwm_hw( PWM_HW_0 , 0);  // 50% DE DUTY-CICLE
    #endif
    #ifdef CAPACITIVO_ON_RB15
        RPOR14bits.RP29R  = 18;                     // OC1 no pino RB15
        inicializa_pwm_hw();
        configura_pwm_hw( PWM_HW_0 , PWM_HW_DUTY);  // 50% DE DUTY-CICLE
    #endif
    #ifdef BUZZER_ON_RB15
        RPOR14bits.RP29R  = 18;                     // OC1 no pino RB15
        inicializa_pwm_hw();
        configura_pwm_hw( PWM_HW_0 , PWM_HW_DUTY);  // 50% DE DUTY-CICLE
    #endif


    inicializa_uart( UART_1, BR_9600, PARIDADE_NONE );          // UART GPS
    inicializa_uart( UART_2, BR_57600, PARIDADE_NONE );         // UART LORA
    #ifndef PWM_ON_RB15
        #ifndef BUZZER_ON_RB15
            #ifndef ENVIA_ENCODER
                #ifndef ENVIA_AN15
                    inicializa_uart( UART_3, BR_9600, PARIDADE_NONE );         // UART3 auxilitar rb14 rb15 borneira
                #endif
            #endif
        #endif
    #endif
    inicializa_io();
    RTCCInit();
    inicializa_int0();
    #ifdef ENVIA_GIROSCOPIO          // manda Girosc�pio             "05xxxxyyyyzzzz"
    inicializa_acelerometro();
    #endif
    uart_2.tam_rx = 0;  // LIMPA SUJEIRAS.
    tx_pct_uart_2();

    #ifdef ENVIA_ENCODER
        LED_1_TRIS = 0;
        LED_2_TRIS = 0;
        LED_3_TRIS = 0;
        LED_1 = 0;
        LED_2 = 0;
        LED_3 = 0;
        inicializa_captures();
        //inicializa_cn();
    #endif
 }

void desliga_perifericos( void )
{
    #ifdef DISPLAY_SPI
    // Redireciona os ports
    RPINR20bits.SDI1R = 22;                         // SPI1 SDI no pino RP22
    RPOR5bits.RP10R  = 7;                          // SPI1 SDO no pino RP10 (SDA se fosse i2c)
    RPOR8bits.RP17R  = 8;                          // SPI1 SCK no pino RP17 (SCL se fosse i2c)
    #endif

    RPINR18bits.U1RXR = 23;                         // USART1 RX1 no pino RP23
    RPOR12bits.RP24R  = 3;                          // USART1 TX1 no pino RP24
    RPINR19bits.U2RXR = 4;                          // USART2 RX2 no pino RP4
    RPOR1bits.RP2R  = 5;                            // USART2 TX2 no pino RP2

    #ifndef PWM_ON_RB15
        #ifndef BUZZER_ON_RB15
            #ifndef ENVIA_ENCODER
                RPINR17bits.U3RXR = 14;                         // USART3 RX3 no pino RP14
                RPOR14bits.RP29R  = 28;                         // USART3 TX3 no pino RP29
            #endif
        #endif
    #endif
    RPINR0bits.INT1R = 8;                           // BT1 em INT1 no pino RP8

    #ifdef PWM_ON_RB15 
        RPOR14bits.RP29R  = 0;                     // OC1 no pino RB15
    #endif
    #ifdef BUZZER_ON_RB15
        RPOR14bits.RP29R  = 0;                     // OC1 no pino RB15
    #endif

    desabilita_interrupcoes();

    /*** Configura��o dos resistores de pull-up: ***/
    CNPU1 = 0x0000;								    // Desabilita Pull-up nos pinos
    CNPU2 = 0x0000;								    // Desabilita Pull-up nos pinos
    CNPU3 = 0x0000;								    // Desabilita Pull-up nos pinos
    CNPU4 = 0x0000;								    // Desabilita Pull-up nos pinos
    CNPU5 = 0x0000;								    // Desabilita Pull-up nos pinos
    CNPU6 = 0x0000;								    // Desabilita Pull-up nos pinos

    /*** configura��o de input change ***/
    CNEN1 = 0x0000;
    CNEN2 = 0x0000;
    CNEN3 = 0x0000;
    CNEN4 = 0x0000;
    CNEN5 = 0x0000;
    CNEN6 = 0x0000;

    /*** Configura��o da SPI: ***/
    SPI1STAT = 0x2000;                              // SPI1 desativada
    SPI2STAT = 0x2000;                              // SPI2 desativada

    /*** Configura��o da I2C: ***/
    I2C1CON = 0x2000;                               // I2C1 desativada
    I2C2CON = 0x2000;                               // I2C1 desativada

    /*** Configura��o da UART: ***/
    U1MODE = 0x2000;                                // UART1 desativada
    U2MODE = 0x2000;                                // UART2 desativada
    U3MODE = 0x2000;                                // UART2 desativada
    U4MODE = 0x2000;                                // UART2 desativada

    /*** Configura��o do ADC: ***/
    AD1CON1  = 0x0000;
    AD1CSSL  = 0x0000;
    AD1CSSH  = 0x0000;
    
    #ifdef ENVIA_ENCODER
        LED_1_TRIS = 1;
        LED_2_TRIS = 1;
        LED_3_TRIS = 1;
        LED_1 = 0;
        LED_2 = 0;
        LED_3 = 0;
    #endif

    #ifdef BUZZER_ON_RB15
        PWM_TRIS=1;
        PWM_PIN=1;
    #endif
    #ifdef PWM_ON_RB15
        PWM_TRIS=1;
        PWM_PIN=1;
    #endif
}


/****************************************************************************************\
 * inicializa_int0                                                                      *
 * Rotina de configura��o da interrup��o para borda de descida (CONTADOR)               *
 *                                                                                      *
 * Par�metros: void             					                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void inicializa_int0( void )
{
    TRISFbits.TRISF6 = 1;
    CNPU6bits.CN84PUE = 1;
    INTCON2bits.INT0EP = 1;
    IFS0bits.INT0IF = 0;
    IPC0bits.INT0IP = 7;
    IEC0bits.INT0IE = 1;
}

/****************************************************************************************\
 * inicializa_int1                                                                      *
 * Rotina de configura��o da interrup��o para borda de descida (para BT1)               *
 *                                                                                      *
 * Par�metros: void             					                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void inicializa_int1( void )
{
    INTCON2bits.INT1EP = 1;
    IFS1bits.INT1IF = 0;
    IPC5bits.INT1IP = 4;
    IEC1bits.INT1IE = 0;
}

/****************************************************************************************\
 * liga                                                                                 *
 * Rotina que liga o rs232                                                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void liga_app( void )
{
    POWER_APP = 1;
}

/****************************************************************************************\
 * desliga                                                                              *
 * Rotina que desliga o rs232                                                     *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void desliga_app( void )
{
    POWER_APP = 0;
}


/****************************************************************************************\
 * atualiza_temperatura           				                                        *
 * Rotina para ler a temperatura do MCP3551                                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void atualiza_leitura_dht( void )
{
    // Min. 1s
    #ifdef ENVIA_DHT22
    unsigned char dht_crc = 0;
    unsigned char dht_error = 0;
    union unsigned_int aux;

    dht_error = read_dht22(); // Check dht_dat variable after this funciton
    dht_crc = dht_dat[0] + dht_dat[1] + dht_dat[2] + dht_dat[3]; // check check_sum
    if (dht_dat[4] != dht_crc || dht_error > 0)
    {   //erro sensor
        //dados.umidade = 0;
        //dados.temperatura_celcius = 0;
    }
    else
    {   //sensor ok
        aux.value = dht_dat[0] * 255;
        aux.value += dht_dat[1];
        dados.umidade = aux.value;
        aux.value = dht_dat[2] * 255;
        aux.value +=  dht_dat[3];
        dados.temperatura_celcius = aux.value;
    }
    #endif
    #ifdef ENVIA_DHT11
    unsigned char dht_crc = 0;
    unsigned char dht_error = 0;
    union unsigned_int aux;

    dht_error = read_dht(); // dummy
    dht_error = read_dht(); // Check dht_dat variable after this funciton

    dht_crc = dht_dat[0] + dht_dat[1] + dht_dat[2] + dht_dat[3]; // check check_sum
    if (dht_dat[4] != dht_crc || dht_error > 0)
    {   //erro sensor
        //dados.umidade = 0;
        //dados.temperatura_celcius = 0;
    }
    else
    {   //sensor ok
        aux.value = dht_dat[0] * 10;
        aux.value += ( dht_dat[1] & 0x0F );
        dados.umidade = aux.value;
        aux.value = dht_dat[2] * 10;
        aux.value += ( dht_dat[3] & 0x0F );
        dados.temperatura_celcius = aux.value;
    }
    #endif

}

// para ntc10k
#define VOLT_REF					3290.0		/** Reference voltage for AFEC,in mv. */
#define MAX_DIGITAL					4095.0		/** The maximal digital value */
#define TERMISTORNOMINAL				10000.0		// Valor do termistor na temperatura nominal
#define TEMPERATURENOMINAL				25.0		// Temp. nominal descrita no Manual
#define NUMAMOSTRAS					5			// N�mero de amostragens para
#define BCOEFFICIENT					3950.0		// Beta do nosso Termistor	//  +/-2%
#define SERIESRESISTOR					10010.0		// valor do resistor em s�rie


// para pt100
#define VOLT_REF					3290.0		/** Reference voltage for AFEC,in mv. */
#define MAX_DIGITAL					4095.0		/** The maximal digital value */
#define PT100OFFSET                                     4602.3		// Valor do termistor na temperatura nominal
#define PT100COEFF                                      2.7429		// valor do resistor em s�rie

// para 4 a 20mA
#define CORRENTECOEFF                                   0.05321       // para RL de 150.0 ohms
#define CORRENTEOFFSET                                  0.0

void atualiza_temperatura_ntc10k( void )
{
    static float media[ADC_NUM_CANAIS][NUMAMOSTRAS];
    static unsigned char contador = 0;
    static float temperatura = 0.0;
    unsigned char i = 0;
    unsigned char j = 0;
    unsigned long aux;
    signed int result = 0;

    // Converte para Celsius

    for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
    {
        media[i][contador] = adc.dados.canal[i];
    }

    contador++;
    if (contador >= NUMAMOSTRAS)
    {
        contador = 0;
        for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
        {
            aux = 0;
            temperatura = 0.0;
            for (j = 0; j < NUMAMOSTRAS; j++)
            {
                aux += media[i][j];
            }
            aux /= NUMAMOSTRAS;

            if (aux != 0)
            {
                temperatura = (MAX_DIGITAL / (float)aux) - 1;
                temperatura = (SERIESRESISTOR / temperatura) / TERMISTORNOMINAL;
                temperatura = (log(temperatura));							// ln(R/Ro)
                temperatura /= BCOEFFICIENT;							// 1/B * ln(R/Ro)
                temperatura += (1.0 / (TEMPERATURENOMINAL + 273.15));		// + (1/To)
                temperatura = (1.0 / temperatura);						// Inverte o valor
                temperatura -= 273.15;
                temperatura *= 10.0;
                result = (signed int)temperatura;

                if (result > 2500)
                {
                        dados.temperaturas_ntc10k[i] = 2500;
                }
                else if (result < -2500)
                {
                        dados.temperaturas_ntc10k[i] = -2500;
                }
                else
                {
                        dados.temperaturas_ntc10k[i] = result;
                }
            }
        }
    }
}

void atualiza_temperatura_pt100( void )
{
    static float media[ADC_NUM_CANAIS][NUMAMOSTRAS];
    static unsigned char contador = 0;
    static float temperatura = 0.0;
    unsigned char i = 0;
    unsigned char j = 0;
    unsigned long aux;
    signed int result = 0;

    // Converte para Celsius
    for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
    {
        media[i][contador] = adc.dados.canal[i];
    }

    contador++;
    if (contador >= NUMAMOSTRAS)
    {
        contador = 0;
        for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
        {
            aux = 0;
            temperatura = 0.0;
            for (j = 0; j < NUMAMOSTRAS; j++)
            {
                aux += media[i][j];
            }
            aux /= NUMAMOSTRAS;

            if (aux != 0)
            {
                temperatura = (float)aux * ( VOLT_REF / MAX_DIGITAL );
                temperatura *= PT100COEFF;      // y = 2.7429x - 4602.3
                temperatura -= PT100OFFSET;
                
                result = (signed int)temperatura;

                if (result > 2500)
                {
                        dados.temperaturas_pt100[i] = 2500;
                }
                else if (result < -2500)
                {
                        dados.temperaturas_pt100[i] = -2500;
                }
                else
                {
                        dados.temperaturas_pt100[i] = result;
                }
            }
        }
    }
}

void atualiza_4_20ma( void )
{
    static float media[ADC_NUM_CANAIS][NUMAMOSTRAS];
    static unsigned char contador = 0;
    static float corrente = 0.0;
    unsigned char i = 0;
    unsigned char j = 0;
    unsigned long aux;
    signed int result = 0;

    // Converte para Celsius
    for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
    {
        media[i][contador] = adc.dados.canal[i];
    }

    contador++;
    if (contador >= NUMAMOSTRAS)
    {
        contador = 0;
        for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
        {
            aux = 0;
            corrente = 0.0;
            for (j = 0; j < NUMAMOSTRAS; j++)
            {
                aux += media[i][j];
            }
            aux /= NUMAMOSTRAS;

            if (aux != 0)
            {
                corrente = (float)aux;
                corrente *= CORRENTECOEFF;      // y = 2.7429x - 4602.3
                corrente -= CORRENTEOFFSET;

                result = (signed int)corrente;

                if (result > 2500)
                {
                        dados.corrente_4_20ma[i] = 2500;
                }
                else if (result < -2500)
                {
                        dados.corrente_4_20ma[i] = -2500;
                }
                else
                {
                        dados.corrente_4_20ma[i] = result;
                }
            }
        }
    }
}

void _ISR_NO_PSV _CNInterrupt( void )
{

    IFS1bits.CNIF = 0;		// Clear Input Change Notification Flag
    atualiza_encoder();                        // Verifica sentido de giro do disco
}

void inicializa_cn( void )
{
    ENC1_TRIS = 1;
    ENC2_TRIS = 1;

    _CN12IE = 1;   // Enable Input Change Notification Interrupt on RB15 pin (Rotary)
   // _CN32IE = 1;   // Enable Input Change Notification Interrupt on RB14 pin (Rotary)

    _CNIF = 0;	// Clear Input Change Notification Flag
    _CNIP = 4;	// Set priority of Input Change Notification Interrupt
    _CNIE = 1;	// Enable Input Change Notification Interrupt
}


void configura_registros_controle( float f1, float f2,float f3 )
{
    if ( f1 == 0)
    {
        f1 = 1.0;
    }
    if ( f2 == 0)
    {
        f2 = 1.0;
    }
    if ( f3 == 0)
    {
        f3 = 1.0;
    }

#if (  defined( PID_1 ) )
    // Carrega par�metros de controle da bomba de fluxo positivo
    controle.pid[ PID_1 ].N  = dados.setup.pid[PID_1].n;      // P�lo limitador do ganho derivativo
    controle.pid[ PID_1 ].H  = dados.setup.pid[PID_1].h;      // Intervalo de amostragem para PID, em segundos
    controle.pid[ PID_1 ].TT = dados.setup.pid[PID_1].tt;     // Tempo de tracking para o anti-windup
    controle.pid[ PID_1 ].bp = dados.setup.pid[PID_1].bp * f1;     // Banda proporcional
    controle.pid[ PID_1 ].ti = dados.setup.pid[PID_1].ti * f1;     // Tempo integral
    controle.pid[ PID_1 ].td = dados.setup.pid[PID_1].td;     // Tempo derivativo
#endif
}

void carrega_setup_default( void )
{

    dados.setup.pid[PID_1].n = PID_1_N;
    dados.setup.pid[PID_1].h = PID_1_H;
    dados.setup.pid[PID_1].tt = PID_1_TT;
    dados.setup.pid[PID_1].bp = PID_1_BP;
    dados.setup.pid[PID_1].ti = PID_1_TI;
    dados.setup.pid[PID_1].td = PID_1_TD;

    dados.setup.alarme_inferior     = ALARME_INFERIOR;
    dados.setup.alarme_superior     = ALARME_SUPERIOR;
    dados.setup.setpoint_pid1       = SETPOINT_PID1;

    dados.setup.halls_por_volta     = HALLS_POR_VOLTA;
    dados.setup.offset_torque       = OFFSET_TORQUE;
    dados.setup.at_degrau           = AT_DEGRAU;

    dados.setup.histerese_at        = HISTERESE_AT;
    dados.setup.sample_at           = SAMPLE_AT ;
    dados.setup.ganho_bp            = GANHO_BP;
    dados.setup.offset_ti           = OFFSET_TI;
    dados.setup.fator_ti_td         = FATOR_TI_TD;
    dados.setup.lim_inf_ctrl_bp     = LIM_INF_CTRL_BP;
    dados.setup.lim_sup_ctrl_bp     = LIM_SUP_CTRL_BP;
    dados.setup.lim_inf_ctrl_ti     = LIM_INF_CTRL_TI;
    dados.setup.lim_sup_ctrl_ti     = LIM_SUP_CTRL_TI;
    dados.setup.lim_inf_ctrl_td     = LIM_INF_CTRL_TD;
    dados.setup.lim_sup_ctrl_td     = LIM_SUP_CTRL_TD;
    dados.setup.sample_freq         = SAMPLE_FREQ;
    dados.setup.max_duty_mosfet     = MAX_DUTY_MOSFET;
    dados.setup.min_rpm_control_on  = MIN_RPM_CONTROL_ON;
}

void atualiza_registro_setup (unsigned char command, float dado )
{
    union unsigned_long aux_f;
    unsigned char *p;

    aux_f.value = *(unsigned long*)&dado;
    p = (unsigned char *)&(dados.setup.pid[PID_1].n);
    p += (command * sizeof(float));

    p[0] =  aux_f.byte_low;
    p[1] =  aux_f.byte_high;
    p[2] =  aux_f.byte_medium;
    p[3] =  aux_f.byte_upper;

}

void le_setup( void )
// poe na ram a programa��o correspondente
{
    unsigned int endereco;
    unsigned char *p;
    unsigned int i;

    endereco = END_BASE_BD;
    p = (unsigned char *)&(dados.setup);

    for( i = 0 ; i < sizeof( dados.setup ) ; i++ )
    {
        #ifdef EEPROM_ON
            p[i] =  le_byte_eeprom_spi( endereco++ );
        #endif
    }
}

float le_dado_setup( unsigned char command )
{
    float  ret;
    union unsigned_long aux_f;
    unsigned int endereco;
    unsigned char *p;

    endereco = (command * sizeof(float) );
    p = (unsigned char *)&(dados.setup);

    aux_f.byte_low      = p[endereco++];
    aux_f.byte_high     = p[endereco++];
    aux_f.byte_medium   = p[endereco++];
    aux_f.byte_upper    = p[endereco++];
    ret = aux_f.value;

    return (ret);
}


unsigned char salva_setup( void )
// poe a programa�ao a ram na eeprom,
{
    static unsigned int endereco;
    static unsigned char *p;
    static unsigned int i;

    endereco = END_BASE_BD;
    p = (unsigned char *)&(dados.setup);

    for( i = 0; i < sizeof( dados.setup ); i++)
    {
        #ifdef EEPROM_ON
            if (le_byte_eeprom_spi(endereco) != p[i] )
            {
                escreve_byte_eeprom_spi( endereco , p[i] );
            }
        #endif
        endereco++;
    }
    return (1);
}
