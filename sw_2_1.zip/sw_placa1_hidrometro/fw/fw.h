/****************************************************************************************\
 * 	                       firmware LORA node                                         *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _FW_H_
#define _FW_H_

#include "../sw/app.h"                            // Arquivo de defini��o de vari�veis e fun��es do m�dulo de temperatura e umidade

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "..\modulos\rtc\rtcc.h"
#include "math.h" 
#include "..\port.h"
#include "..\uc.h"
#include "..\sw\app.h"
#include "..\shared_data.h"
#include "..\modulos\adc\adc.h"
#include "..\modulos\rot_aux\rot_aux.h"
#include "..\modulos\uart\uart.h"
#include "..\modulos\io\io.h"
#include "..\modulos\i2c\mod_i2c_master_hw.h"
#include "..\modulos\spi\spi_master_hw.h"
#include "..\modulos\accel\MPU9250.h"
#include "..\modulos\lora\lora.h"
#include "..\modulos\pwm\pwm_hw.h"
#include "..\modulos\capture\capture.h"
#include "..\modulos\gps\smeErrorCode.h"
#include "..\modulos\gps\sl868aModel.h"
#include "..\modulos\gps\sl868aParser.h"
#include "..\modulos\gps\sl868a.h"
#include "..\modulos\dth\dth.h"                            // Arquivo de defini��o de vari�veis e fun��es do m�dulo de temperatura e umidade
#include "..\modulos\encoder\encoder.h"
#include "..\modulos\controle\controle.h"
#include "..\modulos\eeprom\eeprom_i2c.h"
#include "..\modulos\timer\timer.h"

#include "../sw/Adafruit_SSD1306.h"

#define	max(a,b)	(((a) > (b)) ? (a) : (b))
#define	min(a,b)	(((a) < (b)) ? (a) : (b))


extern union unsigned_char flags_fw;
#define FF_BT1                              flags_fw.bit0

#define TRACE_HABILITADO                    NAO

#define DIP1                                io.entradas.entrada[0]
#define VALOR_MAX_PWM                       100

//MEDIA PARA ALTERAR O DAC
#define QTD_MEDIA                           8

// *********** Endere�os da EEPROM externa *************
#define MEMORIA_NAO_INICIADA                    0x5A
#define OFFSET_USO_GERAL_TESTE_MEMORIA          0xFFFF
#define END_EEPROM_USO_GERAL                    0x0000
#define END_BASE_BD                             0x0010

// *************** defines pid ************************
#define INSTAVEL                                0
#define ESTAVEL                                 1

// Comente esta linha caso n�o queira utilizar PID
#define PID_1                                                   0

#define ALARME_INFERIOR                                         2.0
#define ALARME_SUPERIOR                                         6.0
#define SETPOINT_PID1                                           4.0 //GRAUS CELCIUS

#define PID_1_N                                                 20.0        // original 1.0
#define PID_1_H                                                 5.0         // original 0.2
#define PID_1_TT						3.0           // original 20.0 N�O PODE SER ZERO
#define PID_1_BP						500.0       // menor fica mais r�pido!
#define PID_1_TI						2000.0        // menor janela de menor tempo
#define PID_1_TD						0.0

#define HALLS_POR_VOLTA                                         360.0             // bordas de subida
#define OFFSET_TORQUE                                           0.0

#define AT_DEGRAU                                               100.0
#define HISTERESE_AT			                        100.0
#define	SAMPLE_AT                                               0.02
#define GANHO_BP                                                1.0
#define OFFSET_TI                                               2.5
#define FATOR_TI_TD                                             0.0         // SEM DERIVATIVO
#define LIM_INF_CTRL_BP                                         1.0
#define LIM_SUP_CTRL_BP                                         10000.0
#define LIM_INF_CTRL_TI                                         0.0
#define LIM_SUP_CTRL_TI                                         10000.0
#define LIM_INF_CTRL_TD                                         0.0
#define LIM_SUP_CTRL_TD                                         10000.0
#define SAMPLE_FREQ                                             50.0            //Hz
#define MAX_DUTY_MOSFET                                         50.0           // 90%
#define MIN_RPM_CONTROL_ON                                      0                 //
// ***************************** fim defines pid *****************************




//------------------------------------
//-- Caracteres de Controle (ASCII) --
//------------------------------------
#define ASCII_NULL            0x00   //Null
#define ASCII_SOH             0x01   //Start of Heading
#define ASCII_STX             0x02   //Start of Text
#define ASCII_ETX             0x03   //End of Text
#define ASCII_EOT             0x04   //End of Transmission
#define ASCII_ENQ             0x05   //Enquiry
#define ASCII_ACK             0x06   //Acknowledge
#define ASCII_BEL             0x07   //Bell
#define ASCII_BS              0x08   //Backspace
#define ASCII_TAB             0x09   //Horizontal Tab
#define ASCII_LF              0x0A   //Line Feed (New Line)
#define ASCII_VT              0x0B   //Vertical Tab
#define ASCII_FF              0x0C   //Form Feed (New Page)
#define ASCII_CR              0x0D   //Carriage Return
#define ASCII_SO              0x0E   //Shift Out
#define ASCII_SI              0x0F   //Shift In
#define ASCII_DLE             0x10  //Data Link Escape
#define ASCII_DC1             0x11  //Device Control 1
#define ASCII_DC2             0x12  //Device Control 2
#define ASCII_DC3             0x13  //Device Control 3
#define ASCII_DC4             0x14  //Device Control 4
#define ASCII_NAK             0x15  //Negative Acknowledge
#define ASCII_SYN             0x16  //Sunchronous Idle
#define ASCII_ETB             0x17  //End of Transmission Block
#define ASCII_CAN             0x18  //Cancel
#define ASCII_EM              0x19  //End of Medium
#define ASCII_SUB             0x1A  //Substitute
#define ASCII_ESC             0x1B  //Escape
#define ASCII_FS              0x1C  //File Separator
#define ASCII_GS              0x1D  //Group Separator
#define ASCII_RS              0x1E  //Recor Separator
#define ASCII_US              0x1F  //Unit Separator

#define PORTA_UART1_QTD_TX                     UART_1_QTD_TX
#define PORTA_UART1_QTD_RX                     UART_1_QTD_RX
#define F_PORTA_UART1_TX                       F_UART_1_TX
#define F_PORTA_UART1_PCT_RX                   F_UART_1_PCT_RX
#define PORTA_UART1                            UART_1
#define porta_uart1                            uart_1

#define PORTA_GPS_QTD_TX                     UART_1_QTD_TX
#define PORTA_GPS_QTD_RX                     UART_1_QTD_RX
#define F_PORTA_GPS_TX                       F_UART_1_TX
#define F_PORTA_GPS_PCT_RX                   F_UART_1_PCT_RX
#define PORTA_GPS                            UART_1
#define porta_gps                            uart_1

#define PORTA_LORA_QTD_TX                     UART_2_QTD_TX
#define PORTA_LORA_QTD_RX                     UART_2_QTD_RX
#define F_PORTA_LORA_TX                       F_UART_2_TX
#define F_PORTA_LORA_PCT_RX                   F_UART_2_PCT_RX
#define PORTA_LORA                            UART_2
#define porta_lora                            uart_2

#define PORTA_UART3_QTD_TX                     UART_3_QTD_TX
#define PORTA_UART3_QTD_RX                     UART_3_QTD_RX
#define F_PORTA_UART3_TX                       F_UART_3_TX
#define F_PORTA_UART3_PCT_RX                   F_UART_3_PCT_RX
#define PORTA_UART3                            UART_3
#define porta_UART3                            uart_3

// Define the RTCC default initialization.
#define RTCC_DEFAULT_DAY         1        // Date
#define RTCC_DEFAULT_MONTH       9        // Month
#define RTCC_DEFAULT_YEAR       17        // Year
#define RTCC_DEFAULT_WEEKDAY     1        // Day
#define RTCC_DEFAULT_HOUR       01        // hour
#define RTCC_DEFAULT_MINUTE     22        // Minute
#define RTCC_DEFAULT_SECOND     33        // Second

//==================================================================================
//== VARI�VEIS GLOBAIS                                                            ==
//==================================================================================

void desabilita_interrupcoes( void );
void liga_perifericos( void );
void desliga_perifericos( void );
unsigned char pic_init(void);
void inicializa_fw( void );
void inicializa_int0( void );
void inicializa_int1( void );

void liga_app( void );
void desliga_app( void );

void configura_registros_controle( float f1, float f2,float f3 );
void carrega_setup_default( void );
void atualiza_registro_setup (unsigned char command, float dado );
void le_setup( void );
float le_dado_setup( unsigned char command );
unsigned char salva_setup( void );

void atualiza_leitura_dht( void );
void atualiza_temperatura_ntc10k( void );
void atualiza_temperatura_pt100( void );
void atualiza_4_20ma( void );

void _ISR_NO_PSV _CNInterrupt( void );
void inicializa_cn( void );

/****************************************************************************************\
 * 	  	                      Macros              		        *
\****************************************************************************************/

#define print_lora(s)            insere_string_flash_uart_2(s)
#define print_gps(s)             insere_string_flash_uart_1((const unsigned char*)s); tx_pct_uart_1()

#endif
