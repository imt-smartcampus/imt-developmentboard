#ifndef SHARED_DATA_H
#define	SHARED_DATA_H

#include  "fw/fw.h"                           // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware


typedef struct
{
    float pitch;
    float yaw;
    float roll;
    float ax;
    float ay;
    float az;
    float gx;
    float gy;
    float gz;
    float mx;
    float my;
    float mz; // variables to hold latest sensor data values
    int temperature;
} Acelerometro;

typedef struct
{
    unsigned char   warning;         // indica gps ruim se = 1
    signed int      lat_deg;
    unsigned long   lat_decimals;  // always 6 digit, measurement = 1/100000
    unsigned char   lat_direction; // 1= north/+,  0 = South/-
    signed int      longit_deg;
    unsigned long   longit_decimals;  //always 6 digit, measurement = 1/100000
    unsigned char   longit_direction; // 1= East/+, 0 = West/-
    unsigned int    altitude;
    unsigned char   quality;
    unsigned char   n_satellites;
    unsigned char   utc_hour;
    unsigned char   utc_min;
    unsigned char   utc_sec;
    unsigned int    utc_sec_decimals;
    unsigned int    utc_year;
    unsigned char   utc_month;
    unsigned char   utc_dayOfMonth;
    double          speed_knots;
    double          course;
} sl868aCachedDataT;

typedef struct
{
    float alarme_inferior;
    float alarme_superior;
    float setpoint_pid1;
    float halls_por_volta ;
    float offset_torque;
    float at_degrau;
    float histerese_at;
    float sample_at;
    float ganho_bp;
    float offset_ti;
    float fator_ti_td;
    float lim_inf_ctrl_bp;
    float lim_sup_ctrl_bp;
    float lim_inf_ctrl_ti;
    float lim_sup_ctrl_ti;
    float lim_inf_ctrl_td;
    float lim_sup_ctrl_td;
    float sample_freq;
    float max_duty_mosfet;
    float min_rpm_control_on;

    struct
    {
        struct
        {
            unsigned long zero;
            unsigned long fs;
        } ad;
    } calibracao;

    struct
    {
        float n;
        float h;
        float tt;
        float bp;
        float ti;
        float td;
    }pid[3];

} Setup;

typedef struct
{
    unsigned char inicializacao_especial;                 // recebe valor do rn2903

    unsigned int nivel_vcc;                 // recebe valor do rn2903
    unsigned char nivel_bateria;            // 
    unsigned char nivel_sonar;              // recebe dados do adc an12
    Setup setup;                            // para ser usado com uma memoria externa (n�o implementado)
    sl868aCachedDataT gps;                  // chip telit
    Acelerometro acelerometro;              // mpu9520
    unsigned char upctr;                    // contador de framecouter do lora que � salvo no deepsleep
    unsigned long contador_permanente;      // contador permanente que � salvo no deepsleep
    unsigned long kwh;                      // recebido via uart3
    unsigned char rfid[10];                 // recebido via uart1

    int temperatura_celcius;                // DTH22 ou 11
    int umidade;                            // DHT22 ou 11

    float valor_pid1_atual;
    float esforco_pid1;
    unsigned char estabilidade_pid1;
    unsigned char pid_estavel;               //

    char pos_encoder;                 // recebe valor do encoder rotativo
    char selecao_encoder;                 // recebe valor do rn2903
    unsigned int sensor_cor ;

    int temperaturas_ntc10k[ADC_NUM_CANAIS];
    int temperaturas_pt100[ADC_NUM_CANAIS];
    int corrente_4_20ma[ADC_NUM_CANAIS];
    
} Dados;

extern Dados dados;

unsigned char *get_dados( );
unsigned int size_of_dados( );
unsigned int size_of_setup( );

unsigned long get_alarme_superior( );
unsigned long get_alarme_inferior( );
unsigned long get_calibracao_ad_zero( );
unsigned long get_calibracao_ad_fs( );
unsigned long get_id_sensor( );
unsigned long get_id_concentrador( );

void set_alarme_superior( unsigned long x );
void set_alarme_inferior( unsigned long x );
void set_calibracao_ad_zero( unsigned long x );
void set_calibracao_ad_fs( unsigned long x );
void set_id_sensor( unsigned long x );
void set_id_concentrador( unsigned long x );

void init_shared_data( void );

#endif

