#ifndef PORT_H
#define	PORT_H

#include <p24FJ128GA306.h>   

/**************************************************\
 *                       UART GPS                 *
\**************************************************/
// Entradas:
#define RX1                             PORTDbits.RD1

// Sa�das:
#define TX1                             LATDbits.LATD2
#define RST_GPS                         LATDbits.LATD0

/**************************************************\
 *                       UART lora                *
\**************************************************/
// Entradas:
#define RX2                             PORTDbits.RD9
#define RTS_LORA                        PORTDbits.RD11

// Sa�das:
#define TX2                             LATDbits.LATD8
#define RESET_LORA                      LATDbits.LATD7
#define TRIS_RESET_LORA                 TRISDbits.TRISD7
#define CTS_LORA                        LATDbits.LATD10

/**************************************************\
 *                     IO                         *
\**************************************************/
// Entradas:
#define TRIS_AN_RB10                    TRISBbits.TRISB10
#define AN_RB10                         PORTBbits.RB10
#define TRIS_AN_RB11                    TRISBbits.TRISB11
#define AN_RB11                         PORTBbits.RB11
#define TRIS_AN_RB12                    TRISBbits.TRISB12
#define AN_RB12                         PORTBbits.RB12
#define TRIS_AN_RB13                    TRISBbits.TRISB13
#define AN_RB13                         PORTBbits.RB13
#define TRIS_AN_RB14                    TRISBbits.TRISB14
#define AN_RB14                         PORTBbits.RB14
#define TRIS_AN_RB15                    TRISBbits.TRISB15
#define AN_RB15                         PORTBbits.RB15

#define TRIS_BT1                        TRISFbits.TRISF6
#define BT1                             PORTFbits.RF6

#define ENC1_TRIS                       TRISBbits.TRISB14	//
#define ENC1_IO                         PORTBbits.RB14
#define ENC2_TRIS                       TRISBbits.TRISB15	//
#define ENC2_IO                         PORTBbits.RB15

// Saidas:
// Mapeamento dos TRIS para a I2C master por HW:
#define SCL1                            TRISFbits.TRISF5
#define SDA1                            TRISFbits.TRISF4
#define LED_STATUS                      LATGbits.LATG9

#define PWM_TRIS                        TRISBbits.TRISB15
#define PWM_PIN                         PORTBbits.RB15

#define LED_2_TRIS                      TRISFbits.TRISF4
#define LED_3_TRIS                      TRISFbits.TRISF5
#define LED_1_TRIS                      TRISBbits.TRISB12
#define LED_2                           LATFbits.LATF4
#define LED_3                           LATFbits.LATF5
#define LED_1                           LATBbits.LATB12

/**************************************************\
 *                ACELEROMETRO                     *
\**************************************************/

#define nCS_ACEL                        LATFbits.LATF2
#define INTCMPS_ACEL                    LATFbits.LATF3
#define INT_MPU_ACEL                    LATFbits.LATF6
#define SDA_ACEL                        LATFbits.LATF4
#define SDL_ACEL                        LATFbits.LATF5
// Mapeamento dos TRIS para a I2C master por HW:
#define SDA2                            TRISFbits.TRISF4
#define SCL2                            TRISFbits.TRISF5
/**************************************************\
 *                     SPI                         *
\**************************************************/
// If using software SPI (the default case):
#define TRIS_OLED_DC                   TRISBbits.TRISB14
#define OLED_DC                        LATBbits.LATB14
#define TRIS_SCK                       TRISFbits.TRISF5
#define TRIS_SDO                       TRISFbits.TRISF4
#define SCK                            LATFbits.LATF5
#define SDO                            LATFbits.LATF4
//#define TRIS_OLED_CS                   TRISBbits.TRISB13
//#define OLED_CS                        LATBbits.LATB13
//#define OLED_RESET                     PORTDbits.RD1
//#define TRIS_OLED_RESET                   PORTDbits.RD1

/**************************************************\
 *                     Outros                     *
\**************************************************/
#define POWER_APP                       LATDbits.LATD6

#endif

