#ifndef _UC_H_
#define _UC_H_

#include <p24FJ128GA306.h>
#include "var_c30.h"

#define SIM       1
#define NAO       0

#define TRUE        1
#define FALSE       0

//#define MODO_DEBUG        // comente esta linha para compilar e gravar
    #if(! defined( MODO_DEBUG ) )
    #define MODO_RELEASE
    #endif

//#define UART_DEBUG          UART_3

// Modo de execu��o do software: teste de firmware-base ou release
#define SW_TESTE                                0
#define SW_RELEASE                              1
#define TIPO_SW                                 SW_RELEASE

#define _ISR_NO_PSV                             __attribute__((interrupt, no_auto_psv))
#define inline                                  __inline__

#define FCY                                     4000000
#endif 
