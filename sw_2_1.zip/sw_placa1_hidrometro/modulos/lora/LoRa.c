/****************************************************************************************\
 * 	                            M�dulo LOra                                            *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#include "LoRa.h"

void reset_LoRa(void)
{
    TRIS_RESET_LORA = 0;
    RESET_LORA = 0;
    Nop();
    delay_ms(100);
    RESET_LORA = 1;
    delay_ms(250);
    Nop();
}

