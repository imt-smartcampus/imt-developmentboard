/****************************************************************************************\
 * 	                            M�dulo lora                                            *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#include "..\..\fw\fw.h"

extern void reset_LoRa(void);
