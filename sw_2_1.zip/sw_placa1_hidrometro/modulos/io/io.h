/****************************************************************************************\
 * 	                                    M�dulo I/O                                    *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _IO_H_
#define _IO_H_

#define MOD_IO
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_io;                // Flags do m�dulo I/O
extern union unsigned_char flags_io2;                // Flags do m�dulo I/O



/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_BEEP_CURTO                flags_io.bit0   // Beep curto

 /********************************************\
 *                Auxiliares:               *
\********************************************/

#define IO_ENTRADA_0                BT1

// I/Os:
#define TOTAL_IO_ENTRADAS           1
#define TOTAL_IO_SAIDAS             0

// Entradas digitais:
#define T_DEBOUNCE_HI               25              // Tempo de debounce para tecla pressionada, m�ltiplo de 1mS
#define T_DEBOUNCE_LO               15              // Tempo de debounce para tecla liberada, m�ltiplo de 1mS


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    struct
    {
        unsigned char entrada[TOTAL_IO_ENTRADAS];
    } entradas;
    
    struct
    {
        unsigned char saida[TOTAL_IO_SAIDAS];
    } saidas;
} Io;

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/




/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Io io;                                     // Dados do m�dulo I/O


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_io( void );
inline void atualiza_io( void );
inline void atualiza_saidas( void );
inline void le_entradas( void );
void estado_entrada( unsigned char indice, volatile unsigned char pino );

#endif // _IO_H_
