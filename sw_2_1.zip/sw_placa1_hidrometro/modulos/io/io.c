/****************************************************************************************\
 * 	                                    M�dulo I/O                                    *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#include "io.h"                                      // Arquivo de defini��o de vari�veis e fun��es do m�dulo I/O



/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_io;                       // Flags do m�dulo I/O
union unsigned_char flags_io2;                      // Flags do m�dulo I/O


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:
Io io;                                              // Dados do m�dulo I/O


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/


/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/


/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_io                                                                        *
 * Rotina de inicializa��o do m�dulo I/O                                                *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void inicializa_io( void )
{
    int i;

    for( i = 0 ; i < TOTAL_IO_ENTRADAS ; i++ )
        io.entradas.entrada[i] = 0;

    for( i = 0 ; i < TOTAL_IO_SAIDAS ; i++ )
        io.saidas.saida[i] = 0;

    flags_io.value = 0;
}


/****************************************************************************************\
 * atualiza_io                                                                             *
 * Rotina para ler teclado, verificar buzzer e testar timeout de recep��o de bits PS/2  *
 * Esta rotina deve ser chamada em uma base de tempo de 1ms                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void             			                                            *
\****************************************************************************************/
inline void atualiza_io( void )
{
    le_entradas();
    atualiza_saidas();
}

/****************************************************************************************\
 * le_entradas                                                                          *
 * Rotina para leitura e debounce das entradas digitais                                 *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void             			                                            *
\****************************************************************************************/

void estado_entrada( unsigned char indice, volatile unsigned char pino )
{
    unsigned char i;
    static unsigned char debounce_hi[TOTAL_IO_ENTRADAS];
    static unsigned char debounce_lo[TOTAL_IO_ENTRADAS];
    static unsigned char iniciado = 0;

    if ( iniciado == 0 )
    {
        for( i = 0 ; i < TOTAL_IO_ENTRADAS ; i++ )
        {
            io.entradas.entrada[ i ] = 0;
            debounce_lo[ i ] = T_DEBOUNCE_LO;           // Recarrega debounce lo (subida)
            debounce_hi[ i ] = T_DEBOUNCE_HI;           // Recarrega debounce lo (subida)
        }
        iniciado = 1;
    }

    if( !pino )                                         /*** ENTRADA ATIVADA ***/
    {
        debounce_lo[ indice ] = T_DEBOUNCE_LO;          // Recarrega debounce lo (subida)

        if( io.entradas.entrada[ indice ] == 0 )        // Entrada j� est� ativada?
        {                                               // N�o
            debounce_hi[ indice ]--;                    // Decremeta filtro
            if( !debounce_hi[ indice ] )                // Filtro acabou?
            {                                           // Sim
                io.entradas.entrada[ indice ] = 1;		// Ent�o sinaliza entrada ativada
            }
        }
    }
    else                                                /*** ENTRADA DESATIVADA ***/
    {
        debounce_hi[ indice ] = T_DEBOUNCE_HI;          // Recarrega debounce hi (descida)

        if( io.entradas.entrada[ indice ] == 1 )	    // Entrada j� est� desativada?
        {                                               // N�o
            debounce_lo[ indice ]--;                    // Decremeta filtro
            if( !debounce_lo[ indice ] )                // Filtro acabou?
            {                                           // Sim
                io.entradas.entrada[ indice ] = 0; 		// Ent�o sinaliza entrada desativada
            }
        }
    }
}

inline void le_entradas( void )
{
    estado_entrada( 0, IO_ENTRADA_0 ); // dip 1
}

/****************************************************************************************\
 * atualiza_saidas                                                                      *
 * Rotina para atualizar as sa�das digitais                                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void             			                                            *
\****************************************************************************************/
inline void atualiza_saidas( void )
{
    //OUT0 =   ( ( io.saidas.saida[0] ) ? 1 : 0 );
}
