/****************************************************************************************\
 * 	                               	  M�dulo Controle                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#ifndef _CONTROLE_H_
#define _CONTROLE_H_

#define MOD_CONTROLE

#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_controle;          // Defini��o de flags do m�dulo RF-Nordic
/*****
 * . bit0:  
 * . bit1:  
 * . bit2:  
 * . bit3:  
 * . bit4:  
 * . bit5:  
 * . bit6:  
 * . bit7:
 ****/
 

/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/



/********************************************\
 *                Auxiliares:               *
\********************************************/

// N�mero de controladores ONOFF
#define CONTROLE_TOTAL_ONOFF                0

// N�mero de controladores PID
#define CONTROLE_TOTAL_PID                  1

// A��o do controle ONOFF
#define ONOFF_ACAO_NORMAL                   0
#define ONOFF_ACAO_REVERSA                  1

#define QTD_MEDIA_ESTABILIDADE              8

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    struct
    {
        unsigned char on : 1;
        
        float N;
        float H;
        float TT;
        
        float bp;                            
        float ti;
        float td;
    } pid[ CONTROLE_TOTAL_PID ];
    
    struct
    {
        unsigned char on   : 1;
        unsigned char acao : 1;
        
        int histerese;                              // x 10
    } onoff[ CONTROLE_TOTAL_ONOFF ];
} Controle;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Controle controle;


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/




/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_controle( void );

void inicia_pid_controle( unsigned int n, float sp, float pv );
inline void finaliza_pid_controle( unsigned char n );
unsigned int algoritmo_pid_controle( unsigned char n, float sp, float y );

void inicia_onoff_controle( unsigned char n );
inline void finaliza_onoff_controle( unsigned char n );
unsigned int algoritmo_onoff_controle( unsigned char n, float sp, float pv );


#endif // _CONTROLE_H_
