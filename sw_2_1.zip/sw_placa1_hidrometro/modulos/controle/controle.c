/****************************************************************************************\
 * 	                               	  M�dulo Controle                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#include "controle.h"                           // Arquivo de defini��o vari�veis e fun��es do m�dulo Controle


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_controle;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
struct
{
    unsigned char estado : 1;                   // Estado: ON/OFF
    unsigned char inicio : 1;                   // In�cio do controle
    
    unsigned int saida;
} onoff[ CONTROLE_TOTAL_ONOFF ];

struct
{
    unsigned char estado : 1;                   // Estado: ON/OFF
    unsigned char inicio : 1;                   // In�cio do controle
    
    float ad;                                   // Termo ad
    float bd;                                   // Termo bd
    float bi;                                   // Termo bi
    float bt;                                   // Termo bt
    float d_ant;                                // d(n-1)
    float y_ant;                                // pv(n-1)
    float u;                                    // Esfor�o de controle com satura��o (0..100%)
    float v;                                    // Esfor�o de controle sem satura��o
    float p_n;                                  // Termo proporcional
    float i_n;                                  // Termo integral
    float d_n;                                  // Termo derivativo
} pid[ CONTROLE_TOTAL_PID ];

// - Globais ao sistema:
Controle controle;


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/




/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/




/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_controle			 	                                                    *
 * Rotina para iniciar o m�dulo Controle                                                *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
void inicializa_controle( void )
{
    unsigned char i;
    
    flags_controle.value = 0;                       // Zera flags do m�dulo Controle
    
    // Zera vari�veis
    for( i = 0 ; i < CONTROLE_TOTAL_ONOFF ; i++ )
    {
        onoff[ i ].estado = 0; //off
        onoff[ i ].inicio = 1;
        
        onoff[ i ].saida = 0;
        
        controle.onoff[ i ].on = 0;
        controle.onoff[ i ].acao = ONOFF_ACAO_NORMAL;
    }
    
    for( i = 0 ; i < CONTROLE_TOTAL_PID ; i++ )
    {
        pid[ i ].estado = 0; //off
        pid[ i ].inicio = 1;
        
        controle.pid[ i ].N  =  1.0;
        controle.pid[ i ].TT = 20.0;
        controle.pid[ i ].H  =  0.2;   
        
        controle.pid[ i ].on = 0;
    }
}


/********************************************************************************\
 * inicia_pid_controle                                                          *
 * Rotina de libera��o do algoritmo de PID                                      *
 *                                                                              *
 * Par�metros: �ndice do controlador PID                                        *
 * Retorno:    void                                                             *
\********************************************************************************/
void inicia_pid_controle( unsigned int n, float sp, float pv )
{
    controle.pid[ n ].on = 1;
    
    pid[ n ].estado = 1; //on
    pid[ n ].inicio = 1;

    pid[ n ].i_n   = sp / 10.0;
    pid[ n ].d_n   = 0.0;
    pid[ n ].d_ant = 0.0;
    pid[ n ].y_ant = pv / 10.0;
}


/********************************************************************************\
 * finaliza_pid_controle                                                        *
 * Rotina de finaliza��o do algoritmo de PID                                    *
 *                                                                              *
 * Par�metros: �ndice do controlador PID                                        *
 * Retorno:    void                                                             *
\********************************************************************************/
inline void finaliza_pid_controle( unsigned char n )
{
    controle.pid[ n ].on = 0;
    
    pid[ n ].estado = 0; //off
}



/********************************************************************************\
 * algoritmo_pid_controle                                                       *
 * Rotina de execu��o do algoritmo de controle PID                              *
 *                                                                              *
 * Par�metros: �ndice do controlador PID, set-point e vari�vel de controle (em  *
 *             ponto flutuante)                                                 *
 * Retorno:    esfor�o do controle, de 0 a 1000                                 *
\********************************************************************************/
unsigned int algoritmo_pid_controle( unsigned char n, float sp, float y )
{
    if( pid[ n ].estado == 1 ) //on
    {
        // C�lculo do termo ad
        pid[ n ].ad = controle.pid[ n ].td / ( controle.pid[ n ].td + ( controle.pid[ n ].N * controle.pid[ n ].H ) );

        // C�lculo do termo bd
        pid[ n ].bd = ( 100.0 / ( controle.pid[ n ].bp / 10.0 ) ) * controle.pid[ n ].N * pid[ n ].ad;

        // Se Ti = 0, garante a��o integral nula
        if( controle.pid[ n ].ti == 0 )
        {
            pid[ n ].bi  = 0.0;
            pid[ n ].i_n = 0.0;
            pid[ n ].bt  = 0.0;
        }
        else
        {
            pid[ n ].bi = ( ( 100.0 / ( controle.pid[ n ].bp / 10.0 ) ) * controle.pid[ n ].H ) / controle.pid[ n ].ti;
            pid[ n ].bt = controle.pid[ n ].H / controle.pid[ n ].TT;
        }

        // C�lculo do termo proporcional
        pid[ n ].p_n = ( 100.0 / ( controle.pid[ n ].bp / 10.0 ) ) * ( sp - y );

        // C�lculo do termo derivativo (apenas se ainda n�o foi calculado)
        if( !pid[ n ].inicio )
        {
            pid[ n ].d_n = ( pid[ n ].ad * pid[ n ].d_ant ) + ( pid[ n ].bd * ( pid[ n ].y_ant - y ) );

            // Atualiza regressor do termo derivativo
            pid[ n ].d_ant = pid[ n ].d_n;
        }
        else
        {
            pid[ n ].inicio = 0;
        }

        // Esfor�o de controle sem satura��o
        pid[ n ].v = pid[ n ].p_n + pid[ n ].i_n + pid[ n ].d_n;

        // Esfor�o de controle com satura��o
        if( pid[ n ].v < 0.0 )
        {
            pid[ n ].u = 0.0;
        }
        else if( pid[ n ].v > 1000.0 )
        {
            pid[ n ].u = 1000.0;
        }
        else
        {
            pid[ n ].u = pid[ n ].v;
        }

        // i(n+1) // esse cara da problema quando troca os ganhos com o controlador rodando
        pid[ n ].i_n = ( pid[ n ].bi * (float)( sp - y ) ) + ( pid[ n ].bt * ( pid[ n ].u - pid[ n ].v ) ) + pid[ n ].i_n;

        // Atualiza regressor da vari�vel de processo
        pid[ n ].y_ant = y;

        // Retorna esfor�o do controle (0 a 100.0%)
        return( (unsigned int)(pid[ n ].u) );
    }

    return( 0 );
}



/********************************************************************************\
 * inicia_onoff_controle                                                        *
 * Rotina de libera��o do algoritmo de ONOFF                                    *
 *                                                                              *
 * Par�metros: �ndice do controlador ONOFF                                      *
 * Retorno:    void                                                             *
\********************************************************************************/
void inicia_onoff_controle( unsigned char n )
{
    controle.onoff[ n ].on = 1;
    
    onoff[ n ].estado = 1; //on
    onoff[ n ].inicio = 1;
    
    onoff[ n ].saida  = 0;
}


/********************************************************************************\
 * finaliza_onoff_controle                                                      *
 * Rotina de finaliza��o do algoritmo de ONOFF                                  *
 *                                                                              *
 * Par�metros: �ndice do controlador ONOFF                                      *
 * Retorno:    void                                                             *
\********************************************************************************/
inline void finaliza_onoff_controle( unsigned char n )
{
    controle.onoff[ n ].on = 0;
    
    onoff[ n ].estado = 0; //off
}


/********************************************************************************\
 * algoritmo_onoff_controle                                                     *
 * Rotina de execu��o do algoritmo de controle ONOFF                            *
 *                                                                              *
 * Par�metros: �ndice do controlador ONOFF, set-point e vari�vel de controle (em*
 *             ponto flutuante)                                                 *
 * Retorno:    esfor�o do controle, de 0 a 1000                                 *
\********************************************************************************/
unsigned int algoritmo_onoff_controle( unsigned char n, float sp, float pv )
{
    int histerese;
    
    if( onoff[ n ].estado == 1 ) //on
    {
        if( onoff[ n ].inicio )
        {
            onoff[ n ].inicio = 0;
            onoff[ n ].saida = 0;
        }
        
        histerese = controle.onoff[ n ].histerese / 10;
        
        if( controle.onoff[ n ].acao == ONOFF_ACAO_REVERSA )
        {
            if( pv >= sp )
            {
                onoff[ n ].saida = 0;
            }
            else
            {
                if( pv <= ( sp - histerese ) )
                {
                    onoff[ n ].saida = 1000;
                }
            }
        }
        else
        {
            if( pv <= sp )
            {
                onoff[ n ].saida = 0;
            }
            else
            {
                if( pv >= ( sp + histerese ) )
                {
                    onoff[ n ].saida = 1000;
                }
            }
        }
        
        return( onoff[ n ].saida );
    }
    
    return( 0 );
}
