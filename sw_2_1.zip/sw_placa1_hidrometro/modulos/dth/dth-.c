/****************************************************************************************\
 * 	                                    M�dulo UART                                 *
 *                                                                                      *
 *	                Desenvolvido pelo IMT - Instituto Mau� de Tecnologia            *
 * 		                                 	                                *
 *                      App      : DHT11 Temp & Humidity Sensor Applicaiton             *
 * 		                                 	                                *
\****************************************************************************************/

#include "dth.h"                         // Arquivo de defini��o vari�veis e fun��es do m�dulo UART


/****************************************************************************************\
 * 	  	                 Flags do m�dulo                                        *
\****************************************************************************************/

union unsigned_char flags_dth;                     // Defini��o de flags do m�dulo UART


/****************************************************************************************\
 * 	          Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:
unsigned char dht_dat[5]; // Output data will be here

/****************************************************************************************\
 * 	  	         Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/


/****************************************************************************************\
 * 	  	                    Fun��es est�ticas                                  	*
\****************************************************************************************/


/****************************************************************************************\
 *                           Vetores de interrup��o                                     *
\****************************************************************************************/

void dht_init()
{
    DHT11_TRIS = 0;
    DHT11_PIN = 1;
}

unsigned char dht_poll( void )
{
    unsigned char i = 0;
    unsigned char result = 0;
    static unsigned int contador = 0;

    for (i = 0; i < 8; i++)
    {
        contador = 0;
        while ( !DHT11_PIN && contador < 80) //75us
        {
            contador++;
        }
        while (DHT11_PIN && contador < 150) // 50us
        {
            contador++;
        }
        if (contador > 70 )
        {
            result |= (1 << (7 - i));
        }
    }
    return result;
}

unsigned char read_dht( void )
{
    unsigned char i;
    unsigned char GlobalErr;
    static unsigned int count = 0;

    static unsigned int interrupt_var1 = 0;
    static unsigned int interrupt_var2 = 0;
    static unsigned int interrupt_var3 = 0;
    static unsigned int interrupt_var4 = 0;


    GlobalErr = 0;
    dht_init();
    DHT11_PIN = 0;
    delay_ms(18); // 18ms
    DHT11_TRIS = 1;
    count = 0;

    delay_us(30);
    while (DHT11_PIN == 0 && count < 100)
    {
        count++;        // 1us
    }
    if (!DHT11_PIN)
    {
        GlobalErr = 1;
        return(GlobalErr);
    }
    count = 0;
    while (DHT11_PIN == 1 && count < 100)
    {
        count++;        // 1us
    }
    if (DHT11_PIN)
    {
        GlobalErr = 2;
        return(GlobalErr);
    }

    for (i = 0; i < 5; i++)
    {
        dht_dat[i] = dht_poll();
    }

    DHT11_PIN = 1;
    DHT11_TRIS = 0;
    
    return (GlobalErr);
}
