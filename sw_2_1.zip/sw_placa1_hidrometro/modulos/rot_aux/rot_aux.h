/****************************************************************************************\
 * 	                               M�dulo Rotinas Auxiliares                          *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _ROT_AUX_H_
#define _ROT_AUX_H_

#define MOD_ROT_AUX
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware

/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/



/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Buffer ASCII:
#define TAM_BUFFER_ASC                      8

// Op��es de formata��o de string num�rica:
#define DESPREZA_ZEROS_ESQUERDA             0
#define MANTEM_ZEROS_ESQUERDA               1

#define ZERO_CASAS_DECIMAIS                 0
#define UMA_CASA_DECIMAL                    1

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/



/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern unsigned char buffer_ascii[ TAM_BUFFER_ASC ];


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

#define total_elementos_array( a )          ( sizeof( a ) / sizeof( a[ 0 ] ) )


/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

void copia_bytes( unsigned char *origem, unsigned char *destino, unsigned int tamanho );
void copia_bytes_flash( const unsigned char *origem, unsigned char *destino, unsigned int tamanho );

unsigned char lower_chr( unsigned char c );
unsigned char upper_chr( unsigned char c );

int pos_caracter_buffer( unsigned char caracter, unsigned char *buffer, unsigned int total_bytes );
int pos_str_buffer( unsigned char *str, unsigned char *buffer, unsigned int total_bytes );
int pos_str_flash_buffer( const unsigned char *str, unsigned char *buffer, unsigned int total_bytes );
unsigned char numero_str( unsigned char *str );
unsigned char numero_buffer( unsigned char *buffer, unsigned char total );
void preenche_buffer( unsigned char *buffer, unsigned char valor, unsigned int qtde );
unsigned char compara_buffer( unsigned char *buffer_a, unsigned char *buffer_b, unsigned int qtde );

unsigned int tamanho_str( unsigned char *str );
unsigned int tamanho_str_flash( const unsigned char *str );
unsigned char formata_str_valor( long numero, unsigned char casas_decimais, unsigned char max_caracteres, unsigned char opcao, unsigned char *saida );

inline unsigned char retorna_byte_high( unsigned int w );
inline unsigned char retorna_byte_low( unsigned int w );
inline unsigned int retorna_word( unsigned char h, unsigned char l );

unsigned int calcula_porcentagem( unsigned int v, unsigned int p );
long arredonda_valor( float v );

unsigned long long ascii_para_dec( unsigned char *ascii, unsigned char tamanho );
void dec_para_ascii( unsigned long dec, unsigned char *ascii );
unsigned char bcd_para_dec( unsigned char bcd );
unsigned char dec_para_bcd( unsigned char dec );

void dword_para_hex( long valor, unsigned char *hex );
unsigned long hex_para_dword( unsigned char *hex, unsigned char qtde_digitos );
void byte_para_hex( unsigned char valor, unsigned char *hex );
unsigned char hex_para_byte( unsigned char *hex );

unsigned long potencia_10( unsigned long expoente );
unsigned int numero_casas_decimais(int numero);

#endif // _ROT_AUX_H_
