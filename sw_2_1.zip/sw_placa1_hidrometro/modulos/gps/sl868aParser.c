/****************************************************************************************\
 * 	                            M�dulo gps parcer                                     *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

/* sl868aParser.cpp
*/

#include "sl868aParser.h"

sl868aPtrT  msgPtrT;


/*****************************************************************************/
/*                       Parsing commands from sl868a                        */
/*****************************************************************************/

sl868a_nmea_out_msg_id sl868aIdentifyNmeaRxMsg(unsigned char *talker_p, unsigned char *sentenceId_p)
{
     if ((*talker_p == 'G') && ((*(talker_p+1) == 'P')||
     (*(talker_p+1) == 'L') || (*(talker_p+1) == 'N')))
     {
         if ((*sentenceId_p == 'R') &&
         (*(sentenceId_p+1) == 'M') &&
         (*(sentenceId_p+2) == 'C'))
         {
             return NMEA_RMC;
         }
         if ((*(sentenceId_p) == 'G') &&
         (*(sentenceId_p+1) == 'G') &&
         (*(sentenceId_p+2) == 'A'))
         {
             return NMEA_GGA;
         }
     }
     return NMEA_UNMANAGED;
 }


int getTalkerType(unsigned char *in, sl868aMsgE *nmeaType)
{
     if (!in || !nmeaType) {
         return SME_EINVAL;
     }
     if ((((*in=='G') && ((*(in+1)=='P') || (*(in+1)=='L') || (*(in+1)=='N'))) ||
     ((*in=='B') && (*(in+1)=='D'))))
     {
         *nmeaType = STD_NMEA;
         return SME_OK;
         } else if ((*(in)=='P') && (*(in+1)=='M') && (*(in+2)=='T') && (*(in+3)=='K')) {
         *nmeaType = MTK_NMEA;
         return SME_OK;
     }

     return SME_EINVAL;
 }

 int  getSentenceId(unsigned char *in, unsigned char *out)
 {
     char found = FALSE;

     if (!in || !out) {
         return SME_EINVAL;
     }
     //print_dbg("sentence %c %c %c  \n", in[0], in[1], in[2]);

     if ((*in=='G') && (*(in+1)=='G') && (*(in+2)=='A')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='G') && (*(in+1)=='L') && (*(in+2)=='L')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='G') && (*(in+1)=='S') && (*(in+2)=='A')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='G') && (*(in+1)=='S') && (*(in+2)=='V')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='R') && (*(in+1)=='M') && (*(in+2)=='C')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='V') && (*(in+1)=='T') && (*(in+2)=='G')) {
         found = TRUE;
         goto end;
     }
     if ((*(in)=='Z') && (*(in+1)=='D') && (*(in+2)=='A')) {
         found = TRUE;
         goto end;
     }
end:
     if (found) {
         *(out) = *(in);
         *(out+1) = *(in+1);
         *(out+2) = *(in+2);
         return SME_OK;
     }
     return SME_EINVAL;
 }



unsigned char *sl868a_parse_param_offset(unsigned char *in, unsigned char in_len, unsigned char comma_num)
{
    char comma_found = FALSE;
    unsigned char i = 0, j = 0;

    do {
        if (i >= in_len) {
            return NULL;
        }
        if (*(in+i) == ',') {
            j++;
        }
        if (j == comma_num) {
            comma_found = TRUE;
        }
        i++;
    } while (!comma_found);

    if (comma_found) {
        return (in+i);
    }
    return NULL;
}

void sme_parse_coord(unsigned char *in, unsigned char in_len, sme_coord_t type)
{
    unsigned char comma = 0, i = 0;
    unsigned int *deg_p = NULL;
    unsigned long *decimals_p = NULL;
    unsigned char *direction_p = NULL;
    unsigned char *ptr = NULL;
    unsigned char first_minute_idx = 0;
    long long minutes_tmp = 0;
    long long decimals_tmp = 0;

     switch (type) {
        case SME_LAT:
            deg_p = &dados.gps.lat_deg;
            decimals_p = &dados.gps.lat_decimals;
            direction_p = &dados.gps.lat_direction;
            comma = 3;
            // lat has deg in 2 chars format: ddmm.mmmmm
            first_minute_idx = SME_CTRL_LAT_MINUTES_START;

        break;
        case SME_LONG:
            deg_p = &dados.gps.longit_deg;
            decimals_p = &dados.gps.longit_decimals;
            direction_p = &dados.gps.longit_direction;
            // lat has deg in 3 chars format: dddmm.mmmmm
            first_minute_idx = SME_CTRL_LONG_MINUTES_START;
            comma = 5;
        break;
        default:
        break;
            //print_err("No Lat/Long provided\n");
    }

    ptr = sl868a_parse_param_offset(in, in_len, comma);

    if (!ptr || (*ptr == ',')) {
        return; // data not valid
    }

    // degrees
    *deg_p = 0;
    for (i = 0; i < first_minute_idx; ++i) {
        *deg_p = ((*deg_p)*10) + (*ptr -'0'); // unsigned int
        ptr++;
    }

    minutes_tmp = 0;
    // minutes
    while (ptr && (*ptr != '.')) {
        minutes_tmp = ((minutes_tmp)*10) + (*ptr -'0'); // unsigned int
        ptr++;
    }
    // convert minutes in decimals *10000
    decimals_tmp = ((minutes_tmp * 10000)*10) /6;

    ptr++;

    // minutes decimals
    *decimals_p = 0;
    while (ptr && (*ptr != ',')) {
        *decimals_p = ((*decimals_p)*10) + (*ptr -'0'); // unsigned int
        ptr++;
    }
    // convert minute decimals from minutes in decimals
    *decimals_p = (*decimals_p)*10/6;

    // get the rest of the

    /* complete conversion
     * from:  DDmm.dddd (D = degree, m = minutes, d = decimals of minutes, all are in 1/60)
     * to  :  DDdddddd     [D are in 1/60, d are in decimals of Degree]
     */
     // calculate the whole 'dddddd'
     *decimals_p = *decimals_p + decimals_tmp;

     ptr++;
     // To be added and UT
     *direction_p = ((*ptr == 'N') || (*ptr == 'E')) ? 1 : 0;
}

void sl868a_parse_gga(unsigned char *in, unsigned char in_len)
{
    unsigned char comma_alt = 9; // n. ',' before alt data
    unsigned char comma_nsat = 7;
    unsigned char comma_quality = 6;
    unsigned char comma_utc = 1;
    unsigned char *ptr;

    ptr = sl868a_parse_param_offset(in, in_len, comma_quality);

    if (ptr && (*ptr != ',')) {
        dados.gps.quality = *ptr-'0';  // ascii
    }

    ptr = sl868a_parse_param_offset(in, in_len, comma_nsat);
    dados.gps.n_satellites = 0;
    while (ptr && (*ptr != ',')) {
        dados.gps.n_satellites = (dados.gps.n_satellites *10) + (*ptr -'0'); // unsigned int
        ptr++;
    }

    ptr = sl868a_parse_param_offset(in, in_len, comma_alt);
    dados.gps.altitude = 0;
    while (ptr && (*ptr != '.') && (*ptr != ',')) {
        dados.gps.altitude = (dados.gps.altitude *10) + (*ptr -'0'); // unsigned int
        ptr++;
    }
	// utc
    
    ptr = sl868a_parse_param_offset(in, in_len, comma_utc);
    unsigned char _cursor = 0;
    while (ptr &&  (*ptr != ',')) {
        if(_cursor<=1){
          dados.gps.utc_hour = (dados.gps.utc_hour *10) + (*ptr -'0');
        }
        if(_cursor>=2 &&_cursor <=3){
           dados.gps.utc_min = (dados.gps.utc_min *10) + (*ptr -'0');
        }
        if(_cursor >=4 && _cursor<=5){
            dados.gps.utc_sec = (dados.gps.utc_sec *10) + (*ptr -'0');
        }
        if(_cursor>=7 && _cursor<=8){
            dados.gps.utc_sec_decimals = (dados.gps.utc_sec_decimals *10) + (*ptr -'0');
 
        }
        _cursor++;
        ptr++;
    } 

//    if (!_ready && dados.gps.quality)
//    {
//        _ready = TRUE;
//    }
}

void sl868a_parse_rmc(unsigned char *in, unsigned char in_len)
{
    unsigned char comma_speed = 7; // n. ',' before alt data
    unsigned char comma_course = 8;
    unsigned char comma_date = 9;
    unsigned char comma_warning = 2;
    unsigned char comma_utc = 1;
    unsigned char _cursor = 0;

    unsigned char *ptr;

    //set utc
    dados.gps.utc_hour = 0;
    dados.gps.utc_min = 0;
    dados.gps.utc_sec = 0;
    dados.gps.utc_sec_decimals = 0;

    ptr = sl868a_parse_param_offset(in, in_len, comma_utc);
    _cursor = 0;
    while (ptr &&  (*ptr != ',')) {
        if(_cursor<=1){
          dados.gps.utc_hour = (dados.gps.utc_hour *10) + (*ptr -'0');
        }
        if(_cursor>=2 &&_cursor <=3){
           dados.gps.utc_min = (dados.gps.utc_min *10) + (*ptr -'0');
        }
        if(_cursor >=4 && _cursor<=5){
            dados.gps.utc_sec = (dados.gps.utc_sec *10) + (*ptr -'0');
        }
        if(_cursor>=7 && _cursor<=8){
            dados.gps.utc_sec_decimals = (dados.gps.utc_sec_decimals *10) + (*ptr -'0');

        }
        _cursor++;
        ptr++;
    }

    // utc date
    dados.gps.utc_year = 0;
    dados.gps.utc_month = 0;
    dados.gps.utc_dayOfMonth = 0;
    dados.gps.speed_knots = 0;
    dados.gps.course = 0;
    dados.gps.warning = 0;

    ptr = sl868a_parse_param_offset(in, in_len, comma_date);
    _cursor = 0;
    while (ptr &&  (*ptr != ',')) {
            if(_cursor<=1){
                    dados.gps.utc_dayOfMonth = (dados.gps.utc_dayOfMonth *10) + (*ptr -'0');
            }
            if(_cursor>=2 &&_cursor <=3){
                    dados.gps.utc_month = (dados.gps.utc_month *10) + (*ptr -'0');
            }
            if(_cursor >=4 && _cursor<=5){
                    dados.gps.utc_year = (dados.gps.utc_year *10) + (*ptr -'0');
            }

            _cursor++;
            ptr++;
    }
    dados.gps.utc_year+=2000;

    ptr = sl868a_parse_param_offset(in, in_len, comma_speed);
    _cursor = 0;
    char decimal = FALSE;
    int decimalPart=0;
    int precision = 0;
    while (ptr &&  (*ptr != ',')) {
            if(!decimal && *ptr=='.') decimal = TRUE;
            if (!decimal)
            dados.gps.speed_knots = (dados.gps.speed_knots *10) + (*ptr -'0');
            else{
                    decimalPart = (decimalPart * 10) + (*ptr -'0');
                    precision++;
            }
            ptr++;
    }
    dados.gps.speed_knots+= decimalPart/ pow(10,precision);

    ptr = sl868a_parse_param_offset(in, in_len, comma_course);
    decimal = FALSE;
    decimalPart=0;
    precision = 0;
    while (ptr &&  (*ptr != ',')) {
            if(!decimal && *ptr=='.') decimal = TRUE;
            if (!decimal)
            dados.gps.course = (dados.gps.course *10) + (*ptr -'0');
            else{
                    decimalPart = (decimalPart * 10) + (*ptr -'0');
                    precision++;
            }
            ptr++;
    }
    dados.gps.course+= decimalPart/ pow(10,precision);

    ptr = sl868a_parse_param_offset(in, in_len, comma_warning);
    if (ptr &&  (*ptr != ','))
    {
        if(*ptr=='V')
        {
            dados.gps.warning = TRUE;
        }
    }


}

char  crcCheck(unsigned char *data, unsigned char len)
{
    char checksum = 0;
    char checksum_str[3]={};
    unsigned char i = 1;

    while (*(data+i) != '*')
    {
         if (i >= len)
         {
             return FALSE;
         }
         checksum ^=*(data+i);
         i++;
    }
    i++;
    sprintf(checksum_str, "%0X", checksum);
    if (*(data+i) != ((checksum > 15) ? checksum_str[0]:'0'))
    {
         return FALSE;
    }
    else if (*(data+i) != ((checksum > 15) ? checksum_str[1] : checksum_str[0]))
    {
         return FALSE;
    };
 return TRUE;
 }

 void parseGpsRxMsg( void)
{
    unsigned char offset= 0;
    unsigned char i = 0;

    if (uart_1.tam_rx <= 1)
    {
      return;
    }
    offset++;   // skip $

    if (SME_OK != getTalkerType(&uart_1.rx[offset],  &msgPtrT.messageType))
    {
      return;
    }

    if (msgPtrT.messageType == STD_NMEA)
    {
        msgPtrT.nmea_p.std_p.talker_p =  &uart_1.rx[offset];
        offset+=2;

        // Filling Sentence Id
        msgPtrT.nmea_p.std_p.sentenceId_p = &uart_1.rx[offset];
        offset += NMEA_SENTENCE_ID_LEN;

        // Filling data
        msgPtrT.nmea_p.std_p.data_p = &uart_1.rx[offset];

        while( uart_1.rx[offset++] != '*')
        {
            if( uart_1.rx[offset] == 0)
            {
                return;
            }
            i++;
        }
        msgPtrT.nmea_p.std_p.dataLenght = i;
    }
    else
    {
        msgPtrT.nmea_p.mtk_p.talker_p = &uart_1.rx[offset];
        offset+=4;
        msgPtrT.nmea_p.mtk_p.msgId_p = &uart_1.rx[offset];
        offset+=3;
        msgPtrT.nmea_p.mtk_p.data_p  = &uart_1.rx[offset];
        // Filling data
        while( uart_1.rx[offset++] != '*')
        {
          i++;
        }
        msgPtrT.nmea_p.mtk_p.dataLength = i;
    }
}

