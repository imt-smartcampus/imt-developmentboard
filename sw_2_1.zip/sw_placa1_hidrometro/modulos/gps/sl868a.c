/****************************************************************************************\
 * 	                            M�dulo gps                                            *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************//*
 * sl868a.c
 *
 */

#include "sl868a.h"

void setStandby(void)
{     // set GPS in standby
     print_gps(SL868A_SET_STDBY_CMD);
}

 void setWarmRestart(void)
 {      // Power On the GPS module
     print_gps(SL868A_WARM_RST_CMD);
 }

void setHotRestart(void)
{     // Hot Power On the GPS module
     print_gps(SL868A_HOT_RST_CMD);
}

 void setColdRestart(void)
{    // Cold Power On the GPS module
     print_gps(SL868A_COLD_RST_CMD);
}
 
 void processGpsRxMsg(void)
 {
     sl868a_nmea_out_msg_id nmea_msg_id;

     if (msgPtrT.messageType == STD_NMEA)
     {
         nmea_msg_id = sl868aIdentifyNmeaRxMsg(&uart_1.rx[1], msgPtrT.nmea_p.std_p.sentenceId_p);
         switch(nmea_msg_id)
         {
             case NMEA_RMC:
                 sme_parse_coord(msgPtrT.nmea_p.std_p.data_p, msgPtrT.nmea_p.std_p.dataLenght, SME_LAT);
                 sme_parse_coord(msgPtrT.nmea_p.std_p.data_p, msgPtrT.nmea_p.std_p.dataLenght, SME_LONG);
                 sl868a_parse_rmc(msgPtrT.nmea_p.std_p.data_p, msgPtrT.nmea_p.std_p.dataLenght);
                 break;

             case NMEA_GGA:
                 sl868a_parse_gga(msgPtrT.nmea_p.std_p.data_p, msgPtrT.nmea_p.std_p.dataLenght);
                 break;

             case NMEA_UNMANAGED:
             default:
                break;
         }
     }
 }


 /****************************************************************************/
 /*                               Public APIs                                */
 /****************************************************************************/

int getLatitudeDegrees( void )
{
    return (isNorthLatitude() ? dados.gps.lat_deg : -dados.gps.lat_deg);
}

unsigned longngetLatitudeDecimals( void )
{
    return (unsigned long) dados.gps.lat_decimals;
}

double getLatitude( void )
{
    double lat = dados.gps.lat_decimals;

    lat = (lat/LAT_LONG_DEC_UNIT);
    lat += dados.gps.lat_deg;
    if (!isNorthLatitude()) {
       lat = -lat;
    }
    return lat;
}

char isNorthLatitude( void )
{
    return (char) dados.gps.lat_direction;
}

int getLongitudeDegrees( void )
{
    return (isEastLongitude() ? dados.gps.longit_deg : -dados.gps.longit_deg);
}

unsigned long getLongitudeDecimals( void )
{
    return (unsigned long) dados.gps.longit_decimals;
}

char isEastLongitude( void )
{
    return (char) dados.gps.longit_direction;
}

double getLongitude( void )
{
    double longit = dados.gps.longit_decimals;

    longit = (longit/LAT_LONG_DEC_UNIT);
    longit += dados.gps.longit_deg;

    if (!isEastLongitude())
    {
        longit = -longit;
    }
    return longit;
}

unsigned int getAltitude( void )
{
    return dados.gps.altitude;
}

unsigned char getLockedSatellites( void )
{
    return dados.gps.n_satellites;
}

// additional getters UTC speed here
unsigned int getUtcHour( void )
{
    return dados.gps.utc_hour;
}
unsigned int getUtcMinute( void )
{
    return dados.gps.utc_min;
}
unsigned int getUtcSecond( void )
{
    return dados.gps.utc_sec;
}

unsigned int getUtcSecondDecimals( void )
{
    return dados.gps.utc_sec_decimals;
}

unsigned int getUtcYear( void )
{
    return dados.gps.utc_year;
}
unsigned char getUtcMonth( void )
{
    return dados.gps.utc_month;
}
unsigned char getUtcDayOfMonth( void )
{
    return dados.gps.utc_dayOfMonth;
}
double getSpeedKnots( void )
{
    return dados.gps.speed_knots >0 ? dados.gps.speed_knots :0;
}
double getCourse( void )
{
    return dados.gps.course >0 ? dados.gps.course:0;
}

char sme_gps_position_fixed( void )
{
    return (dados.gps.quality && (dados.gps.n_satellites >= 3));
}
