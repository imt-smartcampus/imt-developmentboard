/****************************************************************************************\
 * 	                            M�dulo GPS PARSER                                     *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
/*
 * sl868aParser.h
 */

#ifndef SL868APARSER_H_
#define SL868APARSER_H_

#include "..\..\fw\fw.h"

#define SME_CTRL_COORD_LEN             9
#define SME_CTRL_LAT_MINUTES_START     2
#define SME_CTRL_LONG_MINUTES_START    3

#define SL868A_MAX_MSG_LEN   100

typedef struct {
    unsigned char idx;
    unsigned char data[100];
} sl868aRxMsgT;

typedef struct {
    unsigned char    *talker_p;
    unsigned char    *sentenceId_p;
    unsigned char    *data_p;
    unsigned char    dataLenght;
} sl868aStdMsgPtrT;

typedef struct {
    void    *talker_p;
    void    *msgId_p;
    void    *data_p;
    unsigned char dataLength;
} sl868aMTKMsgPtrT;

typedef union {
    sl868aStdMsgPtrT std_p;
    sl868aMTKMsgPtrT mtk_p;
} sl868aMsgPtrT;

typedef struct {
    sl868aMsgE    messageType;
    sl868aMsgPtrT nmea_p;
} sl868aPtrT;

extern sl868aPtrT  msgPtrT;
//extern sl868aRxMsgT rxMsg;


 void parseGpsRxMsg( void);

#endif /* SL868APARSER_H_ */
