/****************************************************************************************\
 * 	                            M�dulo GPS                                            *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
/*
 * sl868a.h
 *
 */


#ifndef SL868A_H_
#define SL868A_H_

#include "..\..\fw\fw.h"

#define LAT_LONG_DEC_UNIT 1000000

/*********************************/
// prototipagem
/************************************/

void processGpsRxMsg(void);

sl868a_nmea_out_msg_id sl868aIdentifyNmeaRxMsg(unsigned char *talker_p, unsigned char *sentenceId_p);
int getTalkerType(unsigned char *in, sl868aMsgE *nmeaType);
int getSentenceId(unsigned char *in, unsigned char *out);
unsigned char * sl868a_parse_param_offset(unsigned char *in, unsigned char in_len, unsigned char comma_num);
void sme_parse_coord(unsigned char *in, unsigned char in_len, sme_coord_t type);
void sl868a_parse_gga(unsigned char *in, unsigned char in_len);
void sl868a_parse_rmc(unsigned char *in, unsigned char in_len);
int print(const char *msg);
int getLatitudeDegrees();
unsigned long getLatitudeDecimals();
char isNorthLatitude();
int getLongitudeDegrees();
unsigned long getLongitudeDecimals();
char isEastLongitude();

void setStandby();
void setWarmRestart();
void setHotRestart();
void setColdRestart();
unsigned int getAltitude();
double getLatitude();
double getLongitude();
unsigned char getLockedSatellites();
// getters added by gabriel
unsigned int getUtcHour();
unsigned int getUtcMinute();
unsigned int getUtcSecond();
unsigned int getUtcSecondDecimals();
unsigned int getUtcYear();
unsigned char getUtcMonth();
unsigned char getUtcDayOfMonth();
double getSpeedKnots();
double getCourse();

void readData(void);



#endif /* SL868A_H_ */
