/****************************************************************************************\
 * 	                                  M�dulo Capture                                  *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "capture.h"                        // Arquivo de defini��o de vari�veis e fun��es do m�dulo 


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_capture;          // Flags do m�dulo Capture


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/


/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/

void _ISR_NO_PSV  _IC1Interrupt( void )
{    
    IFS0bits.IC1IF = 0;                             		// Limpa flag de interrup��o Input Capture 1
    atualiza_encoder();                        // Verifica sentido de giro do disco
}

void _ISR_NO_PSV  _IC2Interrupt( void )
{
    IFS0bits.IC2IF = 0;                             		// Limpa flag de interrup��o Input Capture 1
}

void _ISR_NO_PSV  _IC3Interrupt( void )
{    
    IFS2bits.IC3IF = 0;                             		// Limpa flag de interrup��o Input Capture 1
}

void _ISR_NO_PSV  _IC4Interrupt( void )
{
    IFS2bits.IC4IF = 0;                             		// Limpa flag de interrup��o Input Capture 1
}


/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_captures                                                                  *
 * Rotina de inicializa��o do m�dulo Input Capture                                      *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno:    void               			                                            *
\****************************************************************************************/
void inicializa_captures( void )
{
    ENC1_TRIS = 1;
    ENC2_TRIS = 1;

    RPINR7bits.IC1R = 29;                     // 1C1 no pino RB15 rp29
    //RPINR7bits.IC2R = 14;                     // 1C1 no pino RB15 rp14

    // Input Captures:
    IC1CON1 = 0x2001;                                // Interrup��o a cada novo evento de captura,
    IC2CON1 = 0x1000;                                // Interrup��o a cada novo evento de captura,
    IC3CON1 = 0x0000;                                // Interrup��o a cada novo evento de captura,
    IC4CON1 = 0x0000;                                // Interrup��o a cada novo evento de captura,

    IC1CON2 = 0x0000;                                // Interrup��o a cada novo evento de captura,
    IC2CON2 = 0x0000;                                // Interrup��o a cada novo evento de captura,
    IC3CON2 = 0x0000;                                // Interrup��o a cada novo evento de captura,
    IC4CON2 = 0x0000;                                // Interrup��o a cada novo evento de captura,

    IPC0bits.IC1IP = 6;                             // Setup IC1 interrupt priority level
    IFS0bits.IC1IF = 0;                             // Limpa flag de interrup��o Input Capture 1
    IEC0bits.IC1IE = 1;                             // Habilita interrup��o Input Capture 1

//    IPC1bits.IC2IP = 6;                             // Setup IC2 interrupt priority level;
//    IFS0bits.IC2IF = 0;                             // Limpa flag de interrup��o Input Capture 2
//    IEC0bits.IC2IE = 1;                             // Habilita interrup��o Input Capture 2

//    IPC9bits.IC3IP = 6;                             // Setup IC3 interrupt priority level
//    IFS2bits.IC3IF = 0;                             // Limpa flag de interrup��o Input Capture 3
//    IEC2bits.IC3IE = 1;                             // Habilita interrup��o Input Capture 3
//
//    IPC9bits.IC4IP = 6;                             // Setup IC4 interrupt priority level
//    IFS2bits.IC4IF = 0;                             // Limpa flag de interrup��o Input Capture 4
//    IEC2bits.IC4IE = 1;                             // Habilita interrup��o Input Capture 4
}
