/****************************************************************************************\
 * 	                              M�dulo PWM (por hardware)                             *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#ifndef _PWM_HW_H_
#define _PWM_HW_H_

#define MOD_PWM_HW

#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/




/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/



/********************************************\
 *                Auxiliares:               *
\********************************************/

// PWM:
#define PWM_HW_TOTAL                1

#define PWM_HW_0                    0
#define PWM_HW_1                    1
#define PWM_HW_2                    2
#define PWM_HW_3                    3
#define PWM_HW_4                    4
#define PWM_HW_5                    5

// Per�odo:
#define PWM_HW_PERIODO              VALOR_TMR4           // Valor do PWM_HW_PR para gerar per�odo do PWM (15KHz)

// Tipo de l�gica:
#define PWM_HW_LOGICA_POSITIVA      0
#define PWM_HW_LOGICA_NEGATIVA      1

// L�gica para as sa�das:
#define PWM_HW_LOGICA_SAIDA_0       PWM_HW_LOGICA_POSITIVA
#define PWM_HW_LOGICA_SAIDA_1       PWM_HW_LOGICA_POSITIVA

// OCxRS, OCxRS e OCxCON:
#if( PWM_HW_TOTAL >= 1 )
    #define OC_SAIDA_0_RS           OC1RS
    #define OC_SAIDA_0_R            OC1R
#endif

#define OC_SAIDA_0_CON1            OC1CON1
#define OC_SAIDA_0_CON2            OC1CON2
#if( PWM_HW_TOTAL >= 2 )
    #define OC_SAIDA_1_RS           ?
    #define OC_SAIDA_1_R            ?
    #define OC_SAIDA_1_CON          ?
#endif
#if( PWM_HW_TOTAL >= 3 )
    #define OC_SAIDA_2_RS           ?
    #define OC_SAIDA_2_R            ?
    #define OC_SAIDA_2_CON          ?
#endif
#if( PWM_HW_TOTAL >= 4 )
    #define OC_SAIDA_3_RS           ?
    #define OC_SAIDA_3_R            ?
    #define OC_SAIDA_3_CON          ?
#endif
#if( PWM_HW_TOTAL >= 5 )
    #define OC_SAIDA_4_RS           ?
    #define OC_SAIDA_4_R            ?
    #define OC_SAIDA_4_CON          ?
#endif
#if( PWM_HW_TOTAL >= 6 )
    #define OC_SAIDA_5_RS           ?
    #define OC_SAIDA_5_R            ?
    #define OC_SAIDA_5_CON          ?
#endif

// Mapeamento dos ports para PWM:
#if( PWM_HW_TOTAL >= 1 )
    #define PWM_HW_SAIDA_0          PWM_PIN
#endif
#if( PWM_HW_TOTAL >= 2 )
    #define PWM_HW_SAIDA_1          ?
#endif
#if( PWM_HW_TOTAL >= 3 )
    #define PWM_HW_SAIDA_2          ?
#endif
#if( PWM_HW_TOTAL >= 4 )
    #define PWM_HW_SAIDA_3          ?
#endif
#if( PWM_HW_TOTAL >= 5 )
    #define PWM_HW_SAIDA_4          ?
#endif
#if( PWM_HW_TOTAL >= 6 )
    #define PWM_HW_SAIDA_5          ?
#endif

// Mapeamento de registradores auxiliares para PWM:
#define PWM_HW_TXCON                T4CON
#define PWM_HW_PR                   PR4


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/




/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/




/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

void inicializa_pwm_hw( void );

void configura_pwm_hw( unsigned char saida, unsigned int dc );


#endif // _PWM_HW_H_
