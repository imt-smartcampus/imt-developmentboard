/****************************************************************************************\
 * 	                              M�dulo PWM (por hardware)                             *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#include "pwm_hw.h"                         // Arquivo de defini��o de vari�veis e fun��es do m�dulo PWM por hardware


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/




/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char pwm_hw_iniciado = 0;

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/




/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/




/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_pwm_hw						 	                                        *
 * Rotina para iniciar o m�dulo de PWM                                                  *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
void inicializa_pwm_hw( void )
{
    if( !pwm_hw_iniciado )                          // M�dulo j� iniciado?
    {                                               // N�o. Ent�o inicia
        // Frequ�ncia
        PWM_HW_PR = PWM_HW_PERIODO;
        
        // Duty Cycle inicial
        #if( PWM_HW_TOTAL >= 1 )
            OC_SAIDA_0_RS = PWM_HW_PERIODO;
            OC_SAIDA_0_R  = PWM_HW_PERIODO/2;
            PWM_TRIS = 0;
            PWM_PIN = 1;
        #endif
        #if( PWM_HW_TOTAL >= 2 )
            OC_SAIDA_1_RS = 0;
            OC_SAIDA_1_R  = 0;
        #endif
        #if( PWM_HW_TOTAL >= 3 )
            OC_SAIDA_2_RS = 0;
            OC_SAIDA_2_R  = 0;
        #endif
        #if( PWM_HW_TOTAL >= 4 )
            OC_SAIDA_3_RS = 0;
            OC_SAIDA_3_R  = 0;
        #endif
        #if( PWM_HW_TOTAL >= 5 )
            OC_SAIDA_4_RS = 0;
            OC_SAIDA_4_R  = 0;
        #endif
        #if( PWM_HW_TOTAL >= 6 )
            OC_SAIDA_5_RS = 0;
            OC_SAIDA_5_R  = 0;
        #endif
        
        // Output Compare - PWM
        #if( PWM_HW_TOTAL >= 1 )
            OC1CON1bits.OCM = 0b110; //  110 = Edge-Aligned PWM mode on OCx
            OC1CON2bits.SYNCSEL = 0b11111; //This OC module
            OC1CON2bits.OCTRIG = 0; //Timer2 is the clock source for Output Compare x
            OC1CON1bits.OCTSEL = 0b010; //000 = Timer4 clock 400Hz
        #endif
        #if( PWM_HW_TOTAL >= 2 )
            OC_SAIDA_1_CON = 0x2006;
        #endif
        #if( PWM_HW_TOTAL >= 3 )
            OC_SAIDA_2_CON = 0x2006;
        #endif
        #if( PWM_HW_TOTAL >= 4 )
            OC_SAIDA_3_CON = 0x2006;
        #endif
        #if( PWM_HW_TOTAL >= 5 )
            OC_SAIDA_4_CON = 0x2006;
        #endif
        #if( PWM_HW_TOTAL >= 6 )
            OC_SAIDA_5_CON = 0x2006;
        #endif
        
        // Liga timer - frequ�ncia
        //PWM_HW_TXCON = 0xA000;
        
        pwm_hw_iniciado = 1;                        // Informa que PWM foi inicializado
    }
}


/****************************************************************************************\
 * configura_pwm_hw							 	                                        *
 * Rotina para configurar o duty cycle e o per�odo do PWM                               *
 *                                                                                      *
 * Par�metros: sa�da de PWM a ser configurada e duty cycle (0 a 1000)                   *
 * Retorno   : void							                                            *
\****************************************************************************************/
void configura_pwm_hw( unsigned char saida, unsigned int dc )
{
    float aux;
    
    if( saida >= PWM_HW_TOTAL )
        return;
    
    aux  = PWM_HW_PERIODO;
    aux /= 1000;
    
    // "traduz" PWM
    // PWM_HW_PERIODO -> 100.0%
    // dc             -> X
    
    //dc = PWM_HW_PERIODO - ( dc * aux );
    aux *= dc;
    dc = aux;
    
    switch( saida )
    {
#if( PWM_HW_TOTAL >= 1 )
    case PWM_HW_0:
        #if( PWM_HW_LOGICA_SAIDA_0 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_0_R = dc;
        OC_SAIDA_0_RS = PWM_HW_PERIODO-1;
        break;
#endif
        
#if( PWM_HW_TOTAL >= 2 )
    case PWM_HW_1:
        #if( PWM_HW_LOGICA_SAIDA_1 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_1_RS = dc;
        break;
#endif
        
#if( PWM_HW_TOTAL >= 3 )
    case PWM_HW_2:
        #if( PWM_HW_LOGICA_SAIDA_2 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_2_RS = dc;
        break;
#endif
        
#if( PWM_HW_TOTAL >= 4 )
    case PWM_HW_3:
        #if( PWM_HW_LOGICA_SAIDA_3 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_3_RS = dc;
        break;
#endif
#if( PWM_HW_TOTAL >= 5 )
    case PWM_HW_4:
        #if( PWM_HW_LOGICA_SAIDA_4 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_4_RS = dc;
        break;
#endif
#if( PWM_HW_TOTAL >= 6 )
    case PWM_HW_5:
        #if( PWM_HW_LOGICA_SAIDA_5 == PWM_HW_LOGICA_NEGATIVA )
            dc = PWM_HW_PERIODO - dc;
        #endif
        OC_SAIDA_5_RS = dc;
        break;
#endif
    }
}
