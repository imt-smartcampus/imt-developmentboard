/****************************************************************************************\
 * 	                               M�dulo I2C master (HW)                             *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _I2C_MASTER_HW_H_
#define _I2C_MASTER_HW_H_

#define MOD_I2C_MASTER_HW

#include "..\..\fw\fw.h"                           // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware

/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Mapeamento dos TRIS para a I2C master por HW:
#define I2C1_MASTER_HW_SCL              SCL1
#define I2C1_MASTER_HW_SDA              SDA1

// Mapeamento dos TRIS para a I2C master por HW:
#define I2C2_MASTER_HW_SCL              SCL2
#define I2C2_MASTER_HW_SDA              SDA2

#define FSCL1                           10000  	    // 100kbps
#define FSCL2                           10000  	    // 100kbps

#define BRG_I2C1	                ( ( ( FCY / FSCL1 ) - ( FCY / 10000000 ) ) - 1 )
#define BRG_I2C2	                ( ( ( FCY / FSCL2 ) - ( FCY / 10000000 ) ) - 1 )

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:

/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:

/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

#define start_i2c1()             start_i2c1_master_hw()
#define restart_i2c1()           restart_i2c1_master_hw()
#define stop_i2c1()              stop_i2c1_master_hw()
#define ack_i2c1()               ack_i2c1_master_hw()
#define nack_i2c1()              nack_i2c1_master_hw()
#define idle_i2c1()              idle_i2c1_master_hw()
#define le_byte_i2c1()           le_byte_i2c1_master_hw()
#define escreve_byte_i2c1( b )   escreve_byte_i2c1_master_hw( b )

#define start_i2c2()             start_i2c2_master_hw()
#define restart_i2c2()           restart_i2c2_master_hw()
#define stop_i2c2()              stop_i2c2_master_hw()
#define ack_i2c2()               ack_i2c2_master_hw()
#define nack_i2c2()              nack_i2c2_master_hw()
#define idle_i2c2()              idle_i2c2_master_hw()
#define le_byte_i2c2()           le_byte_i2c2_master_hw()
#define escreve_byte_i2c2( b )   escreve_byte_i2c2_master_hw( b )

/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_i2c1_master_hw( void );
inline void inicializa_i2c2_master_hw( void );

void start_i2c1_master_hw( void );
void start_i2c2_master_hw( void );
void restart_i2c1_master_hw( void );
void restart_i2c2_master_hw( void );
void stop_i2c1_master_hw( void );
void stop_i2c2_master_hw( void );
unsigned char status_ack_i2c1_master_hw( void );
unsigned char status_ack_i2c2_master_hw( void );
void ack_i2c1_master_hw( void );
void ack_i2c2_master_hw( void );
void nack_i2c1_master_hw( void );
void nack_i2c2_master_hw( void );
void idle_i2c1_master_hw( void );
void idle_i2c2_master_hw( void );

unsigned char le_bytes_i2c1_master_hw( unsigned char *bytes, unsigned char qtd );
unsigned char le_bytes_i2c2_master_hw( unsigned char *bytes, unsigned char qtd );
unsigned char le_byte_i2c1_master_hw( void );
unsigned char le_byte_i2c2_master_hw( void );
void escreve_byte_i2c1_master_hw( unsigned char dado );
void escreve_byte_i2c2_master_hw( unsigned char dado );

#endif // _I2C_MASTER_HW_H_
