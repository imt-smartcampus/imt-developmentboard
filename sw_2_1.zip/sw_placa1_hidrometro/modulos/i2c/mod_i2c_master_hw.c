/****************************************************************************************\
 * 	                               M�dulo I2C master (HW)                             *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/
#include "mod_i2c_master_hw.h"                          // Arquivo de defini��o de vari�veis e fun��es do m�dulo I2C master por HW

/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:

// - Globais ao sistema:

/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char i2c1_hw_iniciada = 0;
unsigned char i2c2_hw_iniciada = 0;

// - Globais ao sistema:

/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/

/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_i2c1_master_hw                                                            *
 * Rotina para inicializar m�dulo I2C                                                   *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
inline void inicializa_i2c1_master_hw( void )
{
    if( !i2c1_hw_iniciada )                         // M�dulo j� iniciado?
    {                                               // N�o. Ent�o inicializa
        I2C1_MASTER_HW_SCL = 1;                     // TRIS inicialmente configurado como sa�da, agora passa para entrada
        I2C1_MASTER_HW_SDA = 1;                     // ...

        I2C1BRG = BRG_I2C1;                         // Baud-rate: 100KHz

    	I2C1CON = 0xB000;                           // Inicializa I2C no modo Master, com m�dulo desabilitado

    	I2C1RCV = 0x0000;
    	I2C1TRN = 0x0000;
    	I2C1STAT = 0x0000;

    	I2C1CONbits.SCLREL = 1;                     // Clock sempre habilitado
    	I2C1CONbits.A10M   = 0;                     // Endere�amento de 7bits
    	I2C1CONbits.DISSLW = 1;                     // Slew rate desabilitado
    	I2C1CONbits.I2CEN  = 1;                     // Habilita m�dulo I2C

    	i2c1_hw_iniciada = 1;                       // Informa que I2C foi inicializada
    }
}

/****************************************************************************************\
 * inicializa_i2c2_master_hw                                                            *
 * Rotina para inicializar m�dulo I2C                                                   *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
inline void inicializa_i2c2_master_hw( void )
{
    if( !i2c2_hw_iniciada )                         // M�dulo j� iniciado?
    {                                               // N�o. Ent�o inicializa
        #if( defined( I2C2_MASTER_HW_SCL ) )
            I2C2_MASTER_HW_SCL = 1;                 // TRIS inicialmente configurado como sa�da, agora passa para entrada
        #endif
        #if( defined( I2C2_MASTER_HW_SDA ) )
            I2C2_MASTER_HW_SDA = 1;
        #endif

        I2C2BRG = BRG_I2C2;                          // Baud-rate: 400KHz

    	I2C2CON = 0xB000;                           // Inicializa I2C no modo Master, com m�dulo desabilitado

    	I2C2RCV = 0x0000;
    	I2C2TRN = 0x0000;
    	I2C2STAT = 0x0000;

    	I2C2CONbits.SCLREL = 1;                     // Clock sempre habilitado
    	I2C2CONbits.A10M   = 0;                     // Endere�amento de 7bits
    	I2C2CONbits.DISSLW = 1;                     // Slew rate desabilitado
    	I2C2CONbits.I2CEN  = 1;                     // Habilita m�dulo I2C

    	i2c2_hw_iniciada = 1;                       // Informa que I2C foi inicializada
    }
}

/****************************************************************************************\
 * start_i2c1_master_hw                                                                 *
 * Rotina para gerar uma condi��o de Start em modo master                               *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void start_i2c1_master_hw( void )
{
    I2C1CONbits.SEN = 1;
    while( I2C1CONbits.SEN );
}

/****************************************************************************************\
 * start_i2c2_master_hw                                                                 *
 * Rotina para gerar uma condi��o de Start em modo master                               *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void start_i2c2_master_hw( void )
{
    I2C2CONbits.SEN = 1;
    while( I2C2CONbits.SEN );
}

/****************************************************************************************\
 * restart_i2c1_master_hw                                                               *
 * Rotina para gerar uma condi��o de Restart em modo master                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void restart_i2c1_master_hw( void )
{
    I2C1CONbits.RSEN = 1;
    while( I2C1CONbits.RSEN );
}

/****************************************************************************************\
 * restart_i2c2_master_hw                                                               *
 * Rotina para gerar uma condi��o de Restart em modo master                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void restart_i2c2_master_hw( void )
{
    I2C2CONbits.RSEN = 1;
    while( I2C2CONbits.RSEN );
}

/****************************************************************************************\
 * stop_i2c1_master_hw                                                                  *
 * Rotina para gerar uma condi��o de Stop em modo master                                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void stop_i2c1_master_hw( void )
{
    I2C1CONbits.PEN = 1;
    while( I2C1CONbits.PEN );
}

/****************************************************************************************\
 * stop_i2c2_master_hw                                                                  *
 * Rotina para gerar uma condi��o de Stop em modo master                                *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void stop_i2c2_master_hw( void )
{
    I2C2CONbits.PEN = 1;
    while( I2C2CONbits.PEN );
}


/****************************************************************************************\
 * status_ack_i2c_master_hw                                                             *
 * Rotina para retornar o status da condi??o de ACKnowledment em modo master I2C        *
 *                                                                                      *
 * Par?metros: void                                                                     *
 * Retorno   : status do ACKnowledment                                                  *
\****************************************************************************************/
unsigned char status_ack_i2c1_master_hw( void )
{
    return( I2C1STATbits.ACKSTAT );
}

/****************************************************************************************\
 * status_ack_i2c_master_hw                                                             *
 * Rotina para retornar o status da condi??o de ACKnowledment em modo master I2C        *
 *                                                                                      *
 * Par?metros: void                                                                     *
 * Retorno   : status do ACKnowledment                                                  *
\****************************************************************************************/
unsigned char status_ack_i2c2_master_hw( void )
{
    return( I2C2STATbits.ACKSTAT );
}


/****************************************************************************************\
 * ack_i2c1_master_hw                                                                   *
 * Rotina para gerar condi��o de ACKnowledment em modo master I2C                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void ack_i2c1_master_hw( void )
{
    I2C1CONbits.ACKDT = 0;
    I2C1CONbits.ACKEN = 1;
    while( I2C1CONbits.ACKEN );
}

/****************************************************************************************\
 * ack_i2c2_master_hw                                                                   *
 * Rotina para gerar condi��o de ACKnowledment em modo master I2C                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void ack_i2c2_master_hw( void )
{
    I2C2CONbits.ACKDT = 0;
    I2C2CONbits.ACKEN = 1;
    while( I2C2CONbits.ACKEN );
}

/****************************************************************************************\
 * nack_i2c1_master_hw                                                                  *
 * Rotina para gerar condi��o de Not ACKnowledment em modo de recep��o master I2C       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void nack_i2c1_master_hw( void )
{
    I2C1CONbits.ACKDT = 1;
    I2C1CONbits.ACKEN = 1;
    while( I2C1CONbits.ACKEN );

    I2C1CONbits.ACKDT = 0;
}

/****************************************************************************************\
 * nack_i2c2_master_hw                                                                  *
 * Rotina para gerar condi��o de Not ACKnowledment em modo de recep��o master I2C       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void nack_i2c2_master_hw( void )
{
    I2C2CONbits.ACKDT = 1;
    I2C2CONbits.ACKEN = 1;
    while( I2C2CONbits.ACKEN );

    I2C2CONbits.ACKDT = 0;
}

/****************************************************************************************\
 * idle_i2c1_master_hw                                                                  *
 * Rotina para gerar uma condi��o de espera enquanto o barramento I2C estiver ocupado   *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void idle_i2c1_master_hw( void )
{
    while( ( I2C1CONbits.SEN     ) ||
           ( I2C1CONbits.PEN     ) ||
           ( I2C1CONbits.RCEN    ) ||
           ( I2C1CONbits.ACKEN   ) ||
		   ( I2C1CONbits.RSEN    ) ||
           ( I2C1STATbits.TRSTAT ) );
}

/****************************************************************************************\
 * idle_i2c2_master_hw                                                                  *
 * Rotina para gerar uma condi��o de espera enquanto o barramento I2C estiver ocupado   *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void idle_i2c2_master_hw( void )
{
    while( ( I2C2CONbits.SEN     ) ||
           ( I2C2CONbits.PEN     ) ||
           ( I2C2CONbits.RCEN    ) ||
           ( I2C2CONbits.ACKEN   ) ||
           ( I2C2CONbits.RSEN    ) ||
           ( I2C2STATbits.TRSTAT ) );
}
/****************************************************************************************\
 * le_bytes_i2c1_master_hw                                                               *
 * Rotina para ler mais de byte da I2C                                                  *
 *                                                                                      *
 * Par?metros: ponteiro para o buffer e quantidade de bytes a serem lidos               *
 * Retorno   : 1 se os bytes foram lidos, 0 caso contr?rio                              *
\****************************************************************************************/
unsigned char le_bytes_i2c1_master_hw( unsigned char *bytes, unsigned char qtd )
{
    while( qtd-- )
    {
        *bytes++ = le_byte_i2c1_master_hw();
        if( I2C1STATbits.BCL )
        {
            return( 0 );
        }

        if( qtd )
        {
            ack_i2c1_master_hw();
        }
    }

    return( 1 );
}
/****************************************************************************************\
 * le_bytes_i2c2_master_hw                                                               *
 * Rotina para ler mais de byte da I2C                                                  *
 *                                                                                      *
 * Par?metros: ponteiro para o buffer e quantidade de bytes a serem lidos               *
 * Retorno   : 1 se os bytes foram lidos, 0 caso contr?rio                              *
\****************************************************************************************/
unsigned char le_bytes_i2c2_master_hw( unsigned char *bytes, unsigned char qtd )
{
    while( qtd-- )
    {
        *bytes++ = le_byte_i2c2_master_hw();
        if( I2C2STATbits.BCL )
        {
            return( 0 );
        }

        if( qtd )
        {
            ack_i2c2_master_hw();
        }
    }

    return( 1 );
}
/****************************************************************************************\
 * le_byte_i2c1_master_hw                                                               *
 * Rotina para ler um byte da I2C                                                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : byte lido                                                                *
\****************************************************************************************/
unsigned char le_byte_i2c1_master_hw( void )
{
    I2C1CONbits.RCEN = 1;
    Nop();
    Nop();
    while( I2C1CONbits.RCEN )
        ;

    I2C1STATbits.I2COV = 0;

    return( I2C1RCV );
}

/****************************************************************************************\
 * le_byte_i2c2_master_hw                                                               *
 * Rotina para ler um byte da I2C                                                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : byte lido                                                                *
\****************************************************************************************/
unsigned char le_byte_i2c2_master_hw( void )
{
    I2C2CONbits.RCEN = 1;
    Nop();
    Nop();
    while( I2C2CONbits.RCEN )
        ;

    I2C2STATbits.I2COV = 0;

    return( I2C2RCV );
}

/****************************************************************************************\
 * escreve_byte_i2c1_master_hw                                                          *
 * Rotina para escrever um byte via I2C                                                 *
 *                                                                                      *
 * Par�metros: dado a escrever no barramento                                            *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_byte_i2c1_master_hw( unsigned char dado )
{
    I2C1TRN = dado;

    if( I2C1STATbits.IWCOL )                        // Errata: durante a transmiss�o do Start bit, ocorre uma colis�o (registro IWCOL=1)
    {                                               // Este deve ser resetado para que outras transmiss�es n�o sejam bloqueadas. Al�m disso, o dado deve ser retransmitido
        I2C1STATbits.IWCOL = 0;
        I2C1TRN = dado;
    }
}

/****************************************************************************************\
 * escreve_byte_i2c2_master_hw                                                          *
 * Rotina para escrever um byte via I2C                                                 *
 *                                                                                      *
 * Par�metros: dado a escrever no barramento                                            *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_byte_i2c2_master_hw( unsigned char dado )
{
    I2C2TRN = dado;

    if( I2C2STATbits.IWCOL )                        // Errata: durante a transmiss�o do Start bit, ocorre uma colis�o (registro IWCOL=1)
    {                                               // Este deve ser resetado para que outras transmiss�es n�o sejam bloqueadas. Al�m disso, o dado deve ser retransmitido
        I2C2STATbits.IWCOL = 0;
        I2C2TRN = dado;
    }
}
