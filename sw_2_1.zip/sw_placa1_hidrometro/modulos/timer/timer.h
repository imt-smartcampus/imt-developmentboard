/****************************************************************************************\
 * 	                                      M�dulo Timer                                *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _TIMER_H_
#define _TIMER_H_

#define MOD_TIMER
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware

/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_timer;             // Defini��o de flags do m�dulo Timer
/*****
 * . bit0:  F_1MS
 * . bit1:  F_10MS
 * . bit2:  F_50MS
 * . bit3:  F_100MS
 * . bit4:  F_500MS
 * . bit5:  F_1000MS
 * . bit6:  
 * . bit7:
 ****/


/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_1MS                       flags_timer.bit0// Base de 1ms
#define F_10MS                      flags_timer.bit1// Base de 10ms
#define F_50MS                      flags_timer.bit2// Base de 50ms
#define F_100MS                     flags_timer.bit3// Base de 100ms
#define F_500MS                     flags_timer.bit4// Base de 500ms
#define F_1000MS                    flags_timer.bit5// Base de 1000ms
#define F_60000MS                   flags_timer.bit6// Base de 1000ms

/********************************************\
 *                Auxiliares:               *
\********************************************/

#define VALOR_TMR2                  500            // Valor carregado em PR2
#define VALOR_TMR3                  65000           // Valor carregado em PR3 USADO DO PWM
#ifdef PWM_ON_RB15
    #define VALOR_TMR4                  50           // Valor carregado em PR3 USADO DO PWM 40kHz
#else
    #define VALOR_TMR4                  2000           // Valor para pwm no buzzer de 2kHz
#endif

#define T_10MS                      10              // Tempo m�ltiplo de 1mS para gerar 10mS
#define T_50MS                      5               // Tempo m�ltiplo de 1mS para gerar 50mS
#define T_100MS                     2               // Tempo m�ltiplo de 50mS para gerar 100mS
#define T_500MS                     5               // Tempo m�ltiplo de 100mS para gerar 500mS
#define T_1000MS                    2               // Tempo m�ltiplo de 500mS para gerar 1000mS
#define T_60000MS                   60              // Tempo m�ltiplo de 500mS para gerar 60000mS


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/




/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/




/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_timer( void );

void sincroniza_base_tempo( unsigned int ms );

void delay_ms( unsigned int tempo );
void delay_us( unsigned int tempo );


#endif // _TIMER_H_
