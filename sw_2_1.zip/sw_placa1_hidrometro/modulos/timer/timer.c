/****************************************************************************************\
 * 	                                      M�dulo Timer                                *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "timer.h"                                  // Arquivo de defini��o de vari�veis e fun��es do m�dulo Timer


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_timer;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char tempo_10ms;                           // Contador para base de tempo de 10mS
unsigned char tempo_50ms;                           // Contador para base de tempo de 50mS
unsigned char tempo_100ms;                          // Contador para base de tempo de 100mS
unsigned char tempo_500ms;                          // Contador para base de tempo de 500mS
unsigned char tempo_1000ms;                         // Contador para base de tempo de 1000mS
unsigned char tempo_60000ms;                        // Contador para base de tempo de 60000mS

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

inline void calcula_base_tempo( void );


/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/

/****************************************************************************************\
 *                        Timer2 Interrupt Service Routine - 1mS                        *
 *                                                                                      *
 * Descri��o: Base de tempo de 1mS                                                      *
 * Prioridade: 6 (quase m�xima)                                                         *
\****************************************************************************************/
void _ISR_NO_PSV _T2Interrupt( void )
{
    calcula_base_tempo();                           // Gera as bases de tempo
    IFS0bits.T2IF = 0;                              // Limpa flag de interrup��o Timer2
}

/****************************************************************************************\
 *                        Timer2 Interrupt Service Routine - 1mS                        *
 *                                                                                      *
 * Descri��o: Base de tempo de 1mS                                                      *
 * Prioridade: 6 (quase m�xima)                                                         *
\****************************************************************************************/
void _ISR_NO_PSV _T4Interrupt( void )
{
    IFS1bits.T4IF = 0;                              // Limpa flag de interrup��o Timer2
}

/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_timer                                                                     *
 * Rotina de inicializa��o dos Timers 2, 4-5 e 6                                        *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void               			                                            *
\****************************************************************************************/
inline void inicializa_timer( void )
{
    flags_timer.value = 0;                          // Zera flags do m�dulo Timer
    
    tempo_10ms   = T_10MS;                          // Inicializa base de tempo de 10mS
    tempo_50ms   = T_50MS;                          // Inicializa base de tempo de 50mS
    tempo_100ms  = T_100MS;                         // Inicializa base de tempo de 100mS
    tempo_500ms  = T_500MS;                         // Inicializa base de tempo de 500mS
    tempo_1000ms = T_1000MS;                        // Inicializa base de tempo de 1000mS
    tempo_60000ms = T_60000MS;                      // Inicializa base de tempo de 60000mS
    
    /*** Timer2 - 1mS: tarefas gerais do firmware ***/
    
    T2CON = 0x2010;                                 // Timer parado, prescale 1:8, 16bits, fonte de clock interno
    TMR2  = 0x0000;                                 // Zera contador
    PR2   = VALOR_TMR2;                             // Carrega per�odo do Timer2
    
    IPC1bits.T2IP = 6;                              // N�vel de prioridade: 6 (quase-m�xima)
    IFS0bits.T2IF = 0;                              // Limpa flag de interrup��o do Timer2
    IEC0bits.T2IE = 1;		                        // Habilita interrup��o Timer2
    
    T2CONbits.TON = 1;                              // Liga Timer2
       
    /*** Timer4 - 1mS: PWM  ***/
    
    T4CON = 0x00;                                   // Timer parado, prescale 1:1, 16bits, fonte de clock interno
    TMR4  = 0x0000;                                 // Zera contador
    PR4   = VALOR_TMR4;                             // Carrega per�odo do Timer2
    
    IPC6bits.T4IP = 4;                              // N�vel de prioridade: 4 (m�dia)
    IFS1bits.T4IF = 0;                              // Limpa flag de interrup��o do Timer4
    IEC1bits.T4IE = 0;		                    // Habilita interrup��o Timer4
    
    T4CONbits.TON = 1;                              // Liga Timer3
}


/****************************************************************************************\
 * calcula_base_tempo    				                                                *
 * Rotina para c�lculo das bases de tempo do sistema                                    *
 *                                                                                      *
 * Par�metros: void             					                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void calcula_base_tempo( void )
{
    F_1MS = 1;                                      // Informa que passou-se 1mS
    
    #if( defined( MOD_UART ) )
        trata_uart();                               // Envio de pacotes de dados pela serial e teste de timeouts de transmiss�o e recep��o
    #endif
    
    #if( defined( MOD_EEPROM_SPI ) )
        testa_escrita_pct_eeprom_spi();             // Testa fim de escrita em EEPROM
    #endif
    
    #if( defined( MOD_IO ) )
        atualiza_io();                                 // Entradas e sa�das digitais
    #endif
	
    #if( defined( MOD_LCD_NUM ) )
        atualiza_lcd();                        // atualiza um caracter por vez
    #endif

    tempo_10ms--;                                   // Decrementa tempo da base de 10mS
    if( !tempo_10ms )                               // Fim do tempo? Sim
    {
        F_10MS = 1;                                 // Informa que passou-se 10mS
        tempo_10ms = T_10MS;                        // Recarrega tempo
        
        tempo_50ms--;                               // Decrementa tempo da base de 50mS
        if( !tempo_50ms )                           // Fim do tempo? Sim
        {
            F_50MS = 1;                             // Informa que passou-se 50mS
            tempo_50ms = T_50MS;                    // Recarrega tempo
            
            tempo_100ms--;                          // Decrementa tempo da base de 100mS
            if( !tempo_100ms )                      // Fim do tempo? Sim
            {
                F_100MS = 1;                        // Informa que passou-se 100mS
                tempo_100ms = T_100MS;              // Recarrega tempo
                
                tempo_500ms--;                      // Decrementa tempo da base de 500mS
                if( !tempo_500ms )                  // Fim do tempo? Sim
                {
                    F_500MS = 1;                    // Informa que passou-se 500mS
                    tempo_500ms = T_500MS;          // Recarrega tempo
                    
                    tempo_1000ms--;                 // Decrementa tempo da base de 1000mS
                    if( !tempo_1000ms )             // Fim do tempo? Sim
                    {
                        F_1000MS = 1;               // Informa que passou-se 1000mS
                        tempo_1000ms = T_1000MS;    // Recarrega tempo

                        tempo_60000ms--;                 // Decrementa tempo da base de 1000mS
                        if( !tempo_60000ms )             // Fim do tempo? Sim
                        {
                            F_60000MS = 1;               // Informa que passou-se 1000mS
                            tempo_60000ms = T_60000MS;    // Recarrega tempo
                        }
                    }
                }
            }
        }
    }
}


/****************************************************************************************\
 * sincroniza_base_tempo    				                                            *
 * Rotina de resincroniza��o das bases de tempo, caso o sistema precise parar o timer   *
 * por um tempo (exemplo: durante sleep, as bases n�o s�o atualizadas)                  *
 *                                                                                      *
 * Par�metros: Tempo a contar						                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void sincroniza_base_tempo( unsigned int ms )
{
    unsigned int wdt;
    
    wdt = RCONbits.SWDTEN;
    RCONbits.SWDTEN = 0;
    
    while( ms-- )
    {
        F_1MS = 1;                                      // Informa que passou-se 1mS
        
        tempo_10ms--;                                   // Decrementa tempo da base de 10mS
        if( !tempo_10ms )                               // Fim do tempo? Sim
        {
            F_10MS = 1;                                 // Informa que passou-se 10mS
            tempo_10ms = T_10MS;                        // Recarrega tempo
            
            tempo_50ms--;                               // Decrementa tempo da base de 50mS
            if( !tempo_50ms )                           // Fim do tempo? Sim
            {
                F_50MS = 1;                             // Informa que passou-se 50mS
                tempo_50ms = T_50MS;                    // Recarrega tempo
                
                tempo_100ms--;                          // Decrementa tempo da base de 100mS
                if( !tempo_100ms )                      // Fim do tempo? Sim
                {
                    F_100MS = 1;                        // Informa que passou-se 100mS
                    tempo_100ms = T_100MS;              // Recarrega tempo
                    
                    tempo_500ms--;                      // Decrementa tempo da base de 500mS
                    if( !tempo_500ms )                  // Fim do tempo? Sim
                    {
                        F_500MS = 1;                    // Informa que passou-se 500mS
                        tempo_500ms = T_500MS;          // Recarrega tempo
                        
                        tempo_1000ms--;                 // Decrementa tempo da base de 1000mS
                        if( !tempo_1000ms )             // Fim do tempo? Sim
                        {
                            F_1000MS = 1;               // Informa que passou-se 1000mS
                            tempo_1000ms = T_1000MS;    // Recarrega tempo
                        }
                    }
                }
            }
        }
    }
    
    RCONbits.SWDTEN = wdt;
}


/****************************************************************************************\
 * delay_ms        							                                            *
 * Rotina de delay em milisegundos - para FOSC = 4MHz                                  *
 *                                                                                      *
 * Par�metros: Tempo a contar						                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void delay_ms( volatile unsigned int tempo )
{
    while( tempo-- )
    {
        delay_us( 1000 );
    }
}


/****************************************************************************************\
 * delay_us        							                                            *
 * Rotina de delay em microsegundos - para FOSC = 4MHz                                 *
 *                                                                                      *
 * Par�metros: Tempo a contar						                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void delay_us( unsigned int tempo )
{
    unsigned int i = 0;

    for (i = 0; i < tempo/2; i++)
    {
        ClrWdt();
        Nop();
    }
}
