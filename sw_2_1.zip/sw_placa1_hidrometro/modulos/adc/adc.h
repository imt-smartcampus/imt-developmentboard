/****************************************************************************************\
 * 	                                     M�dulo ADC                                   *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _ADC_H_
#define _ADC_H_

#define MOD_ADC
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware

/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/



/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

/********************************************\
 *                Auxiliares:               *
\********************************************/

//#define ADC_DMA                     1   // COMENTAR ESTA LINHA PARA N�O USAR O MODO DMA NO AD

// Inicializa��o do ADC:
#define ADC_OFF                     0
#define ADC_ON                      1

// Buffer de leituras:
#define ADC_TOTAL_LEITURAS          64

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    union
    {
        unsigned int canal[ADC_NUM_CANAIS ];
        
        struct 
        {
            unsigned int v_an10;                //V_ANALOGICO an10
            unsigned int v_an11;                //V_ANALOGICO an11
            unsigned int v_an12;                //V_ANALOGICO an12
            unsigned int v_an13;                //V_ANALOGICO an13
            unsigned int v_an14;                //V_ANALOGICO an14
            unsigned int v_an15;                //V_ANALOGICO an15
         }canais;
    }dados;

    int sensor_capacitivo_max ;
    int sensor_capacitivo_min ;
} Adc;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Adc adc;                                     // Dados do m�dulo ADC


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/




/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_adc( unsigned char on_off );

inline void liga_adc( void );
inline void desliga_adc( void );

void initDma0(void);

#endif // _ADC_H_
