/****************************************************************************************\
 * 	                            M�dulo ADC                                            *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "adc.h"                                    // Arquivo de defini��o vari�veis e fun��es do m�dulo ADC

/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/




/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

#ifdef ADC_DMA
    unsigned int BufferA[ADC_NUM_CANAIS] __attribute__((space(dma), aligned(64)));
#endif
// DMA0 configuration
// Direction: Read from peripheral address 0-x300 (ADC1BUF0) and write to DMA RAM
// AMODE: Peripheral Indirect Addressing Mode
// MODE: Continuous, Ping-Pong Mode
// IRQ: ADC Interrupt

// - Globais ao m�dulo:


// - Globais ao sistema:
Adc adc;                                            // Dados do m�dulo ADC


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/




/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/
#ifdef ADC_DMA
/*========================================================================================
_DMA0Interrupt(): ISR name is chosen from the device linker script.
========================================================================================*/
void _ISR_NO_PSV _DMA0Interrupt(void)
{
    unsigned char i = 0;
    static unsigned char contador = 0;
    static unsigned int acumulador[ADC_NUM_CANAIS]; 
    
    for ( i = 0 ; i < ADC_NUM_CANAIS ; i++)
    {
        acumulador[i] += BufferA[i] ;
    }
       
    contador++;
    if (contador == (ADC_TOTAL_LEITURAS - 1))
    { 
        contador = 0;

       for ( i = 0 ; i < ADC_NUM_CANAIS ; i++)
        {
            adc.dados.canal[i] = acumulador[i] / ADC_TOTAL_LEITURAS;
            acumulador[i] = 0;
        }
    } 
	IFS0bits.DMA0IF = 0; //Clear the DMA0 Interrupt Flag
}
#endif

/****************************************************************************************\
 *                           ADC1 Interrupt Service Routine                             *
 *                                                                                      *
 * Descri��o: Interrup��o de convers�o dos canais A/D                                   *
 * Prioridade: 4 (intermedi�ria)                                                        *
\****************************************************************************************/

#ifndef ADC_DMA 
void _ISR_NO_PSV _ADC1Interrupt( void )
{
    unsigned char i;
    volatile unsigned int *p;
	
    static unsigned long buffer_ad[ADC_NUM_CANAIS ];
    static unsigned char contador = 0;
       
    p = (volatile unsigned int *)&ADC1BUF0;     
    
    for ( i = 0 ; i < ADC_NUM_CANAIS ; i++)
    {
        buffer_ad[i] += *p++;
    }

    p = (volatile unsigned int *)&ADC1BUF0;

    // maximos e minimos do sensor capacitivo
    if ( adc.sensor_capacitivo_max < *p)
    {
        adc.sensor_capacitivo_max = *p;
    }
    if ( adc.sensor_capacitivo_min > *p)
    {
        adc.sensor_capacitivo_min = *p;
    }

    contador++;
    if (contador >= ADC_TOTAL_LEITURAS)
    {
        contador = 0;
    
        for( i = 0 ; i < ADC_NUM_CANAIS ; i++ )
        {
            adc.dados.canal[i] = buffer_ad[i] / ADC_TOTAL_LEITURAS;
            buffer_ad[i] = 0;
        }
    }
    
    IFS0bits.AD1IF = 0;
}
#endif

/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

#ifdef ADC_DMA
void initDma0(void)
{
    DMA0CONbits.AMODE = 2;                      // Configure DMA for Peripheral indirect mode,
    DMA0CONbits.MODE = 2;                       // Configure DMA for Continuous Ping-Pong mode
    DMA0PAD = (volatile unsigned int)&ADC1BUF0; // Point DMA to ADC1BUF0 0x300
    DMA0REQ = 13;                               // Select ADC1 as DMA Request source

    DMA0CNT = ADC_NUM_CANAIS-1;                 // 18 DMA request (9 buffers, each with 2 words)

    DMA0STA = __builtin_dmaoffset(&BufferA);
    //DMA0STB = __builtin_dmaoffset(&BufferB);

    IFS0bits.DMA0IF = 0;                        //Clear the DMA interrupt flag bit
    IEC0bits.DMA0IE = 1;                        //Set the DMA interrupt enable bit

    DMA0CONbits.CHEN=1;                         // Enable DMA
}
#endif

/****************************************************************************************\
 * inicializa_adc                                                                       *
 * Rotina de inicializa��o do conversor A/D                                             *
 *                                                                                      *
 * Par�metros: informa se ir� iniciar ou n�o as convers�es assim que o m�dulo for ini-  *
 *             ciado (ON ou OFF)                                                        *
 * Retorno   : void               			                                            *
\****************************************************************************************/
void inicializa_adc( unsigned char on_off )
{
	AD1CON1bits.ADON = 0;		            // Turn off

//DEBUG	AD1PCFGL = 0xFFFD;
	// AN1 Como entrada anal�gica (demais canais como I/Os digitais)
	
	AD1CON1 = 0x0000;
	AD1CON1bits.FORM = 0;		    // AD12B = 0(10 bits) ent�o: form= 00 => Integer (DOUT = 0000 00dd dddd dddd)
	AD1CON1bits.SSRC = 7;		    // Internal counter ends sampling and starts conversion (auto-convert)
	AD1CON1bits.ASAM = 1;		    // Sampling begins immediately after last conversion. SAMP bit is auto-set
        AD1CON1bits.MODE12 = 1;             // 10-bit ADC operation
//DEBUG    AD1CON1bits.SIMSAM = 0;          // Samples multiple channels individually in sequence
	
	AD1CON2 = 0x0000;
	AD1CON2bits.BUFM = 0;		    // Always starts filling the buffer from the start address
	AD1CON2bits.CSCNA = 1 ;		    // Scan inputs for CH0+ during Sample A bit
//DEBUG	AD1CON2bits.CHPS = 0;           // Converts CH0
	AD1CON2bits.SMPI = ADC_NUM_CANAIS-1;		    // ADC_NUM_CANAIS-1 adc buffer
	AD1CON2bits.PVCFG = 0;		    // VREFH = AVDD / VREFL = Avss
	AD1CON2bits.NVCFG0 = 0;		    // VREFH = AVDD / VREFL = Avss
	AD1CON2bits.ALTS = 0;		    // Always uses channel input selects for Sample A

    
	AD1CON3 = 0x0000;
	AD1CON3bits.ADRC = 0;		    // Clock Derived From System Clock
	AD1CON3bits.ADCS = 63;	        // ADC Conversion Clock Select bits [TCY x (ADCS<7:0> + 1)]
	AD1CON3bits.SAMC = 31;		    // 31 TAD
	// Clock derived from system clock
	// Auto Sample Time (31 TAD)
	// A/D Conversion Clock (64 � TCY = TAD)
    
	AD1CON4=0;					    // Allocate 1 words of buffer to each analog input
									// This register is not used in conversion order mode
									// This is required only in the scatter/gather mode
        AD1CON5 = 0;
//DEBUG	AD1CHS123 = 0x0000;
    
    //AD1CHS0: A/D Input Select Register
    AD1CHS0bits.CH0SA = 12;          // MUXA +ve input selection (AN12) for CH0
    AD1CHS0bits.CH0SB = 13;          // MUXA +ve input selection (AN13) for CH0
    AD1CHS0bits.CH0NA = 0;          // MUXA -ve input selection (Vref-) for CH0
    
    AD1CSSH = 0x0000;

    #ifdef ENVIA_AN10
        AD1CSSL = AD1CSSL | 0x0400;	// Scan  AN10
    #endif
    #ifdef ENVIA_AN11
        AD1CSSL = AD1CSSL | 0x0800;	// Scan  AN11
    #endif
    #ifdef ENVIA_AN12
        AD1CSSL = AD1CSSL | 0x1000;	// Scan  AN12
    #endif
    #ifdef ENVIA_AN13
        AD1CSSL = AD1CSSL | 0x2000;	// Scan  AN13
    #endif
    #ifdef ENVIA_AN14
        AD1CSSL = AD1CSSL | 0x4000;	// Scan  AN14
    #endif
    #ifdef ENVIA_AN15
        AD1CSSL = AD1CSSL | 0x8000;	// Scan  AN15
    #endif

    #ifdef ADC_DMA 
    	AD1CON1bits.ADDMABM = 1;		// 0- em blocos / 1- dados armazenados na sequencia de scan, n�o em blocos 
    	
    	// se ADDMABM=1 IGNORA DMABL
    	AD1CON4bits.DMABL = 0;          // Allocates 16 words of buffer to each analog input

        initDma0();
    #endif
    
    if( on_off == ADC_ON )
    {
        liga_adc();                                 // Liga m�dulo ADC
    }
    else
    {
        desliga_adc();                             // Liga m�dulo ADC
    }
}


/****************************************************************************************\
 * liga_adc                                                                             *
 * Rotina de in�cio de convers�es A/D                                                   *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void               			                                            *
\****************************************************************************************/
inline void liga_adc( void )
{
    IPC3bits.AD1IP = 4;                             // N�vel de prioridade: 4 (intermedi�ria)
    IFS0bits.AD1IF = 0;                             // Limpa flag de interrup��o
    #ifdef ADC_DMA
        IEC0bits.AD1IE = 0;                         // Habilita interrup��o
    #else
        IEC0bits.AD1IE = 1;                         // Habilita interrup��o
    #endif
    AD1CON1bits.ADON = 1;                           // Liga m�dulo
}


/****************************************************************************************\
 * desliga_adc                                                                          *
 * Rotina de paraliza��o da m�quina de convers�o das entradas A/D                       *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void               			                                            *
\****************************************************************************************/
inline void desliga_adc( void )
{
    AD1CON1bits.ADON = 0;                           // Desliga A/D
    
    __asm__ volatile ("REPEAT #50");                // Errata: Wait 50 Tcy
    __asm__ volatile ("NOP");                       // Repeat NOP 51 times
    
    IEC0bits.AD1IE = 0;                             // Desabilita interrup��o
    IFS0bits.AD1IF = 0;                             // Limpa flag de interrup��o
}
