/****************************************************************************************\
 * 	                             M�dulo RTC - Real Time Clock                         *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "rtc.h"                                 // Arquivo de defini��o vari�veis e fun��es do m�dulo RTC

/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_rtc;

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:

// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
void ( *salva_ano )( void );                        // Ponteiro de fun��o para salvar ano

// - Globais ao sistema:
Rtc rtc;                                            // Armazena informa��es do RTC

/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

unsigned char le_endereco( unsigned int endereco );
#if( TIPO_RTC == RTC_INTERNO )
void atualiza_registro_interno( unsigned char tipo, unsigned char valor );
void seleciona_registro_rtc( unsigned int registro );
void habilita_escrita_rtc( void );
#endif

/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/



/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_rtc                                                                       *
 * Rotina de inicializa��o do RTC                                                       *
 *                                                                                      *
 * Par�metros: ano e ponteiro para fun��o a fim de salvar o ano quando este � alterado  *
 *             (apenas para RTC_PCF8583)                                                *
 * Retorno   : void                                                                     *
\****************************************************************************************/
#if( TIPO_RTC == RTC_PCF8583 )
inline void inicializa_rtc( unsigned char ano, void ( *ptr )( void ) )
#else
inline void inicializa_rtc( void )
#endif
{
    flags_rtc.value = 0;                            // Zera flags do m�dulo RTC
    
    #if( TIPO_RTC == RTC_PCF8583 )
        inicializa_i2c_master_hw();
        
        le_rtc();                                   // Realiza a leitura de todos os registros
        
        salva_ano = ptr;
        if( ano == 0xFF )                           // Mem�ria iniciada?
        {                                           // N�o. Ent�o carrega rtc
            atualiza_ano_rtc( 0 );                  // Inicia ano
            atualiza_mes_rtc( 1 );                  // Inicia m�s
            atualiza_dia_rtc( 1 );                  // Inicia dia
            atualiza_hora_rtc( 0 );                 // Inicia hora
            atualiza_minuto_rtc( 0 );               // Inicia minuto
            atualiza_segundo_rtc( 0 );              // Inicia segundo
        }
        else                                        // Mem�ria iniciada
        {                                           // Ent�o s� carrega o ano
            atualiza_ano_rtc( ano );                // Carrega o ano lido da mem�ria
        }
    #elif( TIPO_RTC == RTC_DS1337S )
        inicializa_i2c_master_hw();
        
        le_rtc();                                   // Realiza a leitura de todos os registros
    #elif( TIPO_RTC == RTC_INTERNO )
       // __builtin_write_OSCCONL( 2 );               // Habilita secondary oscillator
        
        if( !RCFGCALbits.RTCEN )                    // S� � poss�vel ativar o RTC se a escrita estiver habilitada
        {                                           // Ent�o verifica se a escrita est� habilitada antes de ativar o RTC
            if( !RCFGCALbits.RTCWREN )              // A escrita est� habilitada?
            {                                       // N�o
                habilita_escrita_rtc();             // Ent�o habilita a escrita
            }

            RTCPWCbits.RTCLK = 0b01;        //LPRC
            RTCPWCbits.RTCOUT = 0b00;
            RTCPWCbits.PWSPRE = 0b00;       //div 1
            RTCPWCbits.PWCPRE = 0b00;       //div 1
            RTCPWCbits.PWCPOL = 0b01;       //Power Control Enable bit

            RCFGCALbits.RTCEN = 1;                  // Ativa o RTC
            RCFGCALbits.RTCWREN = 0;                // Desabilita a escrita
        }
        
        rtc.campo.dia = 0;                          // Realiza a inicializa��o de todos os registros
    #elif( TIPO_RTC == RTC_SW )
        rtc.campo.dia = 0;                          // Realiza a inicializa��o de todos os registros
    #endif
    
    if( rtc.campo.dia == 0 )                        // Se o dia for igual a zero, ent�o n�o h� bateria
    {                                               // Neste caso, inicia rel�gio
        atualiza_ano_rtc( 0 );                      // Inicia ano
        atualiza_mes_rtc( 1 );                      // Inicia m�s
        atualiza_dia_rtc( 1 );                      // Inicia dia
        atualiza_hora_rtc( 0 );                     // Inicia hora
        atualiza_minuto_rtc( 0 );                   // Inicia minuto
        atualiza_segundo_rtc( 0 );                  // Inicia segundo
    }
    
    F_ATUALIZA_RTC = 1;                             // Libera RTC para atualiza��o
}

/****************************************************************************************\
 * salva_ano_rtc                                                                        *
 * Rotina para salvar ano presente na RAM do RTC (esta fun��o � executada via ponteiro  *
 * pelo m�dulo RTC)                                                                     *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
#if( TIPO_RTC == RTC_PCF8583 )
void salva_ano_ram_rtc( void )
{
    start_i2c1();                                // Inicia comunica��o I2C
    escreve_byte_i2c1( 0xA0 );                   // Solicita escrita
    idle_i2c1();                                 // Espera fim do evento I2C
    escreve_byte_i2c1( END_RAM_ANO_RTC_PCF8583 ); // Endere�a RAM do RTC
    idle_i2c1();                                 // Espera fim do evento I2C

    escreve_byte_i2c1( rtc.campo.ano );          // Atualiza o ano em RAM
    idle_i2c1();                                 // Espera fim do evento I2C

    stop_i2c1();                                 // Fim da comunica��o
}
#endif

/****************************************************************************************\
 * le_ano_rtc                                                                           *
 * Rotina para ler o ano presente na RAM do RTC                                         *
 *                                                                                      *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : ano                                                                      *
\****************************************************************************************/
#if( TIPO_RTC == RTC_PCF8583 )
unsigned char le_ano_ram_rtc( void )
{
    unsigned char ano = 0;

    start_i2c1();                               // Inicia comunica��o I2C
    escreve_byte_i2c1( 0xA0 );                  // Solicita escrita
    idle_i2c1();                                // Espera fim do evento I2C
    escreve_byte_i2c1( END_RAM_ANO_RTC_PCF8583 ); // Endere�a registro especificado
    idle_i2c1();                                // Espera fim do evento I2C

    restart_i2c1();
    escreve_byte_i2c1( 0xA1 );                  // Solicita leitura
    idle_i2c1();                                // Espera fim do evento I2C

    ano = le_byte_i2c1();                       // L� ano

    nack_i2c1();
    stop_i2c1();				                // Fim da comunica��o

    return( ano );
}
#endif

/****************************************************************************************\
 * le_rtc           						   	                                        *
 * Rotina para ler o rel�gio do sistema                                                 *
 * Esta rotina deve ser chamada em uma base de tempo de 1000ms (se RTC_SW) ou em uma ba-*
 * se de tempo de 500ms (para os outros tipos)                                          *
 * CUIDADO: a chamada desta rotina em interrup��es pode causar problemas de comunica��o *
 * caso o barramento seja usado para mais perif�ricos (por exemplo, escrita e leitura de*
 * EEPROM via I2C)                                                                      *
 *                                                                                      *
 * Par�metros: void				 			                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
void le_rtc( void )
{
    #if( TIPO_RTC == RTC_PCF8583 )
        unsigned char aux;
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x02 );                   // Endere�a primeiro registro de data-hora
        idle_i2c();                                 // Espera fim do evento I2C
        
        restart_i2c();
    	escreve_byte_i2c( 0xA1 );                   // Solicita leitura
        idle_i2c();                                 // Espera fim do evento I2C
        
        // Obt�m os segundos
        rtc.campo.segundo = bcd_para_dec( le_byte_i2c() );
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
    	idle_i2c();						            // Espera fim do evento I2C
        
        // Obt�m os minutos
    	rtc.campo.minuto = bcd_para_dec( le_byte_i2c() );
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
    	idle_i2c();						            // Espera fim do evento I2C
        
        // Obt�m a hora
        rtc.campo.hora = bcd_para_dec( le_byte_i2c() & 0x3F );
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
    	idle_i2c();						            // Espera fim do evento I2C
        
        aux = le_byte_i2c();                        // Obt�m o dia e o ano
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
    	idle_i2c();						            // Espera fim do evento I2C
        
        // Obt�m apenas o dia
    	rtc.campo.dia = bcd_para_dec( aux & 0x3F );
        
        // Obt�m apenas o ano
        aux >>= 6;
        aux  &= 0x03;
        
        if( ( dec_para_bcd( rtc.campo.ano ) & 0x03 ) != aux ) // Se o ano mudou no PCF, incrementa o ano da estrutura
        {
            rtc.campo.ano++;                        // Incrementa ano
            if( rtc.campo.ano > 99 )                // Ano acima do �ltimo?
            {                                       // Sim
                rtc.campo.ano = 0;                  // Zera ano
            }

            F_ATUALIZA_RTC = 1;                     // Libera RTC para atualiza��o
        }
        
        aux = le_byte_i2c();                        // Obt�m o dia da semana e o m�s
    	nack_i2c();                                 // Fim da comunica��o
	    stop_i2c();						            // ...
        
        // Obt�m apenas o m�s
        rtc.campo.mes = bcd_para_dec( aux & 0x1F );
        
        // Obt�m apenas o dia da semana
        aux >>= 5;
        aux  &= 0x07;
        rtc.campo.dia_semana = aux + 1;
        
        if( F_ATUALIZA_RTC )                        // Atualiza��o dos resgistros j� est� liberada?
        {                                           // Sim
            F_ATUALIZA_RTC = 0;                     // RTC para atualiza��o
            
            atualiza_ano_rtc( rtc.campo.ano );      // Atualiza novo ano
        }
    #elif( TIPO_RTC == RTC_DS1337S )
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x00 );                   // Endere�a primeiro registro de data-hora
        idle_i2c();                                 // Espera fim do evento I2C
        
        restart_i2c();
        escreve_byte_i2c( 0xD1 );                   // Solicita leitura
        idle_i2c();						            // Espera fim do evento I2C
        
        // Obt�m os segundos
        rtc.campo.segundo = bcd_para_dec( le_byte_i2c() );
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m os minutos
        rtc.campo.minuto = bcd_para_dec( le_byte_i2c() );
        ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m a hora
        rtc.campo.hora = bcd_para_dec( le_byte_i2c() & 0x3F );
        ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m o dia da semana
    	rtc.campo.dia_semana = bcd_para_dec( le_byte_i2c() & 0x07 );
    	ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m o dia
        rtc.campo.dia = bcd_para_dec( le_byte_i2c() & 0x3F );
        ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m o m�s
    	rtc.campo.mes = bcd_para_dec( le_byte_i2c() & 0x1F );
        ack_i2c();                                  // Responde ACK para ler pr�ximo registro
        
        // Obt�m o ano
    	rtc.campo.ano = bcd_para_dec( le_byte_i2c() );
        
    	nack_i2c();
    	stop_i2c();					                // Fim da comunica��o
    #elif( TIPO_RTC == RTC_INTERNO )
        unsigned char i;
        Rtc nova_leitura;
        
        do                                          // Varre registro de dados do RTC
        {
            seleciona_registro_rtc( PTR_RESERVADO_ANO ); // Aponta para o ano
            rtc.w[ 0 ] = RTCVAL;                    // Guarda valor do ano e dado reservado
            rtc.w[ 1 ] = RTCVAL;                    // Guarda valor do dia e do m�s
            rtc.w[ 2 ] = RTCVAL;                    // Guarda valor da hora e do dia da semana
            rtc.w[ 3 ] = RTCVAL;                    // Guarda valor dos segundos e dos minutos
            
            seleciona_registro_rtc( PTR_RESERVADO_ANO ); // Aponta novamente para o ano, a fim de obter novamente os dados e depois compar�-los para verificar se ocorreu roll-over ou n�o
            nova_leitura.w[ 0 ] = RTCVAL;           // Guarda valor do ano e dado reservado
            nova_leitura.w[ 1 ] = RTCVAL;           // Guarda valor do dia e do m�s
            nova_leitura.w[ 2 ] = RTCVAL;           // Guarda valor da hora e do dia da semana
            nova_leitura.w[ 3 ] = RTCVAL;           // Guarda valor dos segundos e dos minutos
        }
        while( rtc.campo.segundo != nova_leitura.campo.segundo );
        
        // Converte bytes lidos dos registros para decimal
        for( i = 0 ; i < 8 ; i++ )
        {
            rtc.b[ i ] = bcd_para_dec( rtc.b[ i ] );
        }
    #elif( TIPO_RTC == RTC_SW )
        rtc.campo.segundo++;                        // Incrementa segundos
        if( rtc.campo.segundo > 59 )                // Fim dos segundos?
        {                                           // Sim
        	rtc.campo.segundo = 0;                  // Zera segundos
            
        	rtc.campo.minuto++;                     // Incrementa minutos
        	if( rtc.campo.minuto > 59 )             // Fim dos minutos?
        	{                                       // Sim
        		rtc.campo.minuto = 0;               // Zera minutos
                
        		rtc.campo.hora++;                   // Incrementa horas
        		if( rtc.campo.hora > 23 )           // Fim das horas?
        		{                                   // Sim
        			rtc.campo.hora = 0;             // Zera horas
                    
        			rtc.campo.dia++;                // Incrementa dia
    				if( rtc.campo.dia > ultimo_dia_mes( rtc.campo.mes, rtc.campo.ano ) )  // �ltimo dia do m�s?
    				{                               // Sim
    					rtc.campo.dia = 1;          // Inicia dia
    					
    					rtc.campo.mes++;            // Incrementa m�s
    					if( rtc.campo.mes > 12 )    // �ltimo m�s?
            			{                           // Sim
            				rtc.campo.mes = 1;      // Inicia m�s
            				rtc.campo.ano++;        // Incrementa ano
            				
            				if( rtc.campo.ano > 99 )// �ltimo ano?
            				    rtc.campo.ano = 0;  // Inicia ano
            			}
    				}
    				
    				rtc.campo.dia_semana++;         // Incrementa dia da semana
    				if( rtc.campo.dia_semana > 7 )  // �ltimo dia da semana?
    				    rtc.campo.dia_semana = 1;   // Sim. Inicia dia da semana
        		}
        	}
        }
    #endif
}

/****************************************************************************************\
 * le_dado_rtc                                                                          *
 * Rotina que realiza a leitura de determinado dado do RTC (dia, m�s, ano, hora, minuto *
 * ou segundo)                                                                          *
 *                                                                                      *
 * Par�metros: dado a ler                                                               *
 * Retorno   : dado lido        			                                            *
\****************************************************************************************/
unsigned char le_dado_rtc( unsigned char dado )
{
    switch( dado )                                  // Verifica qual � o campo que deve ser lido
    {
    case RTC_ANO:                                   // Se for para ler o ano
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( ( le_endereco( 0x05 ) >> 6 ) & 0x03 );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x06 ) );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_RESERVADO_ANO ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.ano );
    	#else
    	    return( 0 );
        #endif
        break;
        
    case RTC_DIA:                                   // Se for para ler o dia
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( le_endereco( 0x05 ) & 0x3F );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x04 ) & 0x3F );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_MES_DIA ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.dia );
    	#else
    	    return( 0 );
        #endif
        break;
        
    case RTC_MES:                                   // Se for para ler o m�s
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( le_endereco( 0x06 ) & 0x1F );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x05 ) & 0x1F );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_MES_DIA ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.mes );
    	#else
    	    return( 0 );
        #endif
        break;
        
    case RTC_HORA:                                  // Se for para ler as horas
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( le_endereco( 0x04 ) & 0x3F );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x02 ) & 0x3F );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_DIA_SEMANA_HORA ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.hora );
    	#else
    	    return( 0 );
        #endif
        break;
        
    case RTC_SEGUNDO:                               // Se for para ler os segundos
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( le_endereco( 0x02 ) );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x00 ) );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_MINUTO_SEGUNDO ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.segundo );
    	#else
    	    return( 0 );
        #endif
        break;
        
    case RTC_MINUTO:                                // Se for para ler os minutos
        #if( TIPO_RTC == RTC_PCF8583 )
    	    return( le_endereco( 0x03 ) );
        #elif( TIPO_RTC == RTC_DS1337S )
            return( le_endereco( 0x01 ) );
    	#elif( TIPO_RTC == RTC_INTERNO )
    	    return( le_endereco( PTR_MINUTO_SEGUNDO ) );
    	#elif( TIPO_RTC == RTC_SW )
    	    return( rtc.campo.minuto );
    	#else
    	    return( 0 );
        #endif
        break;
    }
    
    return( 0 );
}

/****************************************************************************************\
 * atualiza_dia_rtc    						   	                                		*
 * Rotina para atualizar o dia do rel�gio do sistema			                        *
 *                                                                                      *
 * Par�metros: dia em decimal			                                                *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_dia_rtc( unsigned char dia )
{
    unsigned char aux;
	    
    if( ( dia == 0 ) || ( dia > ultimo_dia_mes( rtc.campo.mes, rtc.campo.ano ) ) )
        return( 0 );
    
	#if( TIPO_RTC == RTC_PCF8583 )
	    // Converte registro de dia e ano para BCD a fim de atualiz�-lo
	    aux  = ( ( dec_para_bcd( rtc.campo.ano ) << 6 ) & 0xC0 );
        aux |= ( ( dec_para_bcd( dia ) ) & 0x3F );
	    
     	start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x05 );                   // Endere�a registro de dia e ano
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o dia
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
        rtc.campo.dia = dia;                        // Atualiza estrutura de dados do rel�gio
        
        return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        aux = dec_para_bcd( dia );              // Converte registro de dia para BCD a fim de atualiz�-lo
        
	    start_i2c();                                // Inicia comunica��o I2C
	    escreve_byte_i2c( 0xD0 );                   // Solicita escrita
	    idle_i2c();                                 // Espera fim do evento I2C
	    escreve_byte_i2c( 0x04 );                   // Endere�a registro de dia
	    idle_i2c();                                 // Espera fim do evento I2C
	    
	    escreve_byte_i2c( aux );                    // Envia segundo
	    idle_i2c();                                 // Aguarda resposta-escrita
	    
	    stop_i2c();						            // Fim da comunica��o
		
	    rtc.campo.dia = dia;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = dia;
	    
    	atualiza_registro_interno( RTC_DIA, aux );  // Atualiza registro interno do dia
    	
    	rtc.campo.dia = aux;                        // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = dia;
	    
	    rtc.campo.dia = aux;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * atualiza_mes_rtc    						   	                                		*
 * Rotina para atualizar o m�s do rel�gio do sistema			                        *
 *                                                                                      *
 * Par�metros: mes em decimal   	 			                                        *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_mes_rtc( unsigned char mes )
{
    unsigned char aux;
        
    if( ( mes == 0 ) || ( mes > 12 ) )
        return( 0 );
    
    #if( TIPO_RTC == RTC_PCF8583 )
        aux = dec_para_bcd( mes );              // Converte registro de m�s para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x06 );                   // Endere�a registro de m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
	    rtc.campo.mes = mes;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        aux = dec_para_bcd( mes );              // Converte registro de m�s para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x05 );                   // Endere�a registro de m�s
        idle_i2c();                                 // Espera fim do evento I2C
    
        escreve_byte_i2c( aux );                    // Envia segundo
        idle_i2c();                                 // Aguarda resposta-escrita
        
        stop_i2c();						            // Fim da comunica��o
	    
	    rtc.campo.mes = mes;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = mes;
	    
    	atualiza_registro_interno( RTC_MES, aux );  // Atualiza registro interno do m�s
    	
    	rtc.campo.mes = aux;                        // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = mes;
	    
	    rtc.campo.mes = aux;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * atualiza_ano_rtc  						   	                                		*
 * Rotina para atualizar o ano do rel�gio do sistema			                        *
 *                                                                                      *
 * Par�metros: ano       			 			                                        *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_ano_rtc( unsigned char ano )
{
    unsigned char aux;
    
    if( ano > 99 )
	    return( 0 );
    
    #if( TIPO_RTC == RTC_PCF8583 )
        // Converte registro de dia e ano para BCD a fim de atualiz�-lo
        aux  = ( ( dec_para_bcd( ano ) << 6 ) & 0xC0 );
        aux |= ( ( dec_para_bcd( rtc.campo.dia ) ) & 0x3F );
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x05 );                   // Endere�a registro de dia e ano
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
	    rtc.campo.ano = ano;                        // Atualiza estrutura de dados do rel�gio
	    
	    if( salva_ano != 0 )                        // H� ponteiro de fun��o para salvar ano?
        {                                           // Sim
            ( *salva_ano )();                       // Ent�o executa a fun��o atrav�s do ponteiro salva_ano
        }
        
	    return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        aux = dec_para_bcd( ano );              // Converte registro de ano para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x06 );                   // Endere�a registro de ano
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );                    // Envia segundo
        idle_i2c();                                 // Aguarda resposta-escrita
        
        stop_i2c();						            // Fim da comunica��o
	    
	    rtc.campo.ano = ano;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = ano;
	    
    	atualiza_registro_interno( RTC_ANO, aux );  // Atualiza registro interno do ano
    	
    	rtc.campo.ano = aux;                        // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = ano;
	    
	    rtc.campo.ano = aux;                        // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * atualiza_hora_rtc						   	                                    	*
 * Rotina para atualizar a hora do rel�gio do sistema			                        *
 *                                                                                      *
 * Par�metros: hora em decimal                                                          *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_hora_rtc( unsigned char hora )
{
    unsigned char aux;
    
    if( hora > 23 )
	    return( 0 );
    
    #if( TIPO_RTC == RTC_PCF8583 )
        aux = dec_para_bcd( hora );             // Converte registro de hora para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x04 );                   // Endere�a registro de hora
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
	    rtc.campo.hora = hora;                      // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        aux = dec_para_bcd( hora );             // Converte registro de hora para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x02 );                   // Endere�a registro de hora
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );                    // Envia segundo
        idle_i2c();                                 // Aguarda resposta-escrita
        
        stop_i2c();						            // Fim da comunica��o
	    
	    rtc.campo.hora = hora;                      // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = hora;
	    
    	atualiza_registro_interno( RTC_HORA, aux );// Atualiza registro interno da hora
    	
    	rtc.campo.hora = aux;                      // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = hora;
	    
	    rtc.campo.hora = aux;                      // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * atualiza_minuto_rtc  					   	                                    	*
 * Rotina para atualizar o minuto do rel�gio do sistema			                        *
 *                                                                                      *
 * Par�metros: minuto em decimal        			                                    *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_minuto_rtc( unsigned char minuto )
{
    unsigned char aux;
    
    if( minuto > 59 )
        return( 0 );
    
    #if( TIPO_RTC == RTC_PCF8583 )
        aux = dec_para_bcd( minuto );           // Converte registro de minuto para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x03 );                   // Endere�a registro de minuto
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
	    rtc.campo.minuto = minuto;                  // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        aux = dec_para_bcd( minuto );           // Converte registro de minuto para BCD a fim de atualiz�-lo
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x01 );                   // Endere�a registro de minuto
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );                    // Envia segundo
        idle_i2c();                                 // Aguarda resposta-escrita
        
        stop_i2c();						            // Fim da comunica��o
	    
	    rtc.campo.minuto = minuto;                  // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = minuto;
	    
    	atualiza_registro_interno( RTC_MINUTO, aux );// Atualiza registro interno dos minutos
    	
    	rtc.campo.minuto = aux;                     // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = minuto;
	    
	    rtc.campo.minuto = aux;                     // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * atualiza_segundo_rtc						   	                               		 	*
 * Rotina para atualizar o segundo do rel�gio do sistema		                        *
 *                                                                                      *
 * Par�metros: segundo em decimal       			                                    *
 * Retorno   : 1 se OK, 0 se erro                                                       *
\****************************************************************************************/
unsigned char atualiza_segundo_rtc( unsigned char segundo )
{
    unsigned char aux;
        
    if( segundo > 59 )
        return( 0 );
	        
	#if( TIPO_RTC == RTC_PCF8583 )
        // Converte registro de segundo para BCD a fim de atualiz�-lo
        aux = dec_para_bcd( segundo );
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x02 );                   // Endere�a registro de segundo
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );					// Atualiza o m�s
        idle_i2c();                                 // Espera fim do evento I2C
        
        stop_i2c();						            // Fim da comunica��o
        
	    rtc.campo.segundo = segundo;                // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
    #elif( TIPO_RTC == RTC_DS1337S )
        // Converte registro de segundo para BCD a fim de atualiz�-lo
        aux = dec_para_bcd( segundo );
        
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( 0x00 );                   // Endere�a registro de segundo
        idle_i2c();                                 // Espera fim do evento I2C
        
        escreve_byte_i2c( aux );                    // Envia segundo
        idle_i2c();                                 // Aguarda resposta-escrita
        
        stop_i2c();						            // Fim da comunica��o
	    
	    rtc.campo.segundo = segundo;                // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#elif( TIPO_RTC == RTC_INTERNO )
	    aux = segundo;
	    
    	atualiza_registro_interno( RTC_SEGUNDO, aux );// Atualiza registro interno dos segundos
    	
    	rtc.campo.segundo = aux;                    // Atualiza estrutura de dados do rel�gio
    	
    	return( 1 );
	#elif( TIPO_RTC == RTC_SW )
	    aux = segundo;
	    
	    rtc.campo.segundo = aux;                    // Atualiza estrutura de dados do rel�gio
	    
	    return( 1 );
	#else
	    return( 0 );
    #endif
}

/****************************************************************************************\
 * le_endereco                                                                          *
 * Rotina que realiza a leitura de determinado endere�o do rel�gio                      *
 *                                                                                      *
 * Par�metros: endere�o a ler                                                           *
 * Retorno   : dado lido        			                                            *
\****************************************************************************************/
unsigned char le_endereco( unsigned int endereco )
{
    unsigned char dado = 0;
    
    #if( TIPO_RTC == RTC_PCF8583 )
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xA0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( endereco );               // Endere�a registro especificado
        idle_i2c();                                 // Espera fim do evento I2C
        
        restart_i2c();
        escreve_byte_i2c( 0xA1 );                   // Solicita leitura
        idle_i2c();                                 // Espera fim do evento I2C
        
        dado = bcd_para_dec( le_byte_i2c() );       // L� endere�o
        
        nack_i2c();
    	stop_i2c();					                // Fim da comunica��o
    #elif( TIPO_RTC == RTC_DS1337S )
        start_i2c();                                // Inicia comunica��o I2C
        escreve_byte_i2c( 0xD0 );                   // Solicita escrita
        idle_i2c();                                 // Espera fim do evento I2C
        escreve_byte_i2c( endereco );               // Endere�a registro especificado
        idle_i2c();                                 // Espera fim do evento I2C
        
        restart_i2c();
        escreve_byte_i2c( 0xD1 );                   // Solicita leitura
        idle_i2c();                                 // Espera fim do evento I2C
        
        dado = bcd_para_dec( le_byte_i2c() );       // L� endere�o
        
        nack_i2c();
    	stop_i2c();					                // Fim da comunica��o
	#elif( TIPO_RTC == RTC_INTERNO )
        seleciona_registro_rtc( endereco );         // Aponta para o ano
        dado = RTCVAL;                              // Guarda valor
    #endif
    
    return( dado );
}

/****************************************************************************************\
 * atualiza_registro_interno                                                            *
 * Rotina para atualizar um registro espec�fico do rel�gio interno                      *
 *                                                                                      *
 * Par�metros: registro (dia, m�s, ano, hora, minuto, segundo) e seu valor em decimal   *
 * Retorno   : void                                                                     *
\****************************************************************************************/
#if( TIPO_RTC == RTC_INTERNO )
void atualiza_registro_interno( unsigned char tipo, unsigned char valor )
{
    unsigned char CPU_IPL;
    volatile unsigned int registro;
    union unsigned_int aux;
    
    SET_AND_SAVE_CPU_IPL( CPU_IPL, 7 );             // Salva as configura��es atuais da CPU e desabilita as interrup��es
    
    if( !RCFGCALbits.RTCWREN )                      // A escrita no RTC est� habilitada?
       habilita_escrita_rtc();                      // N�o. Ent�o habilita
    
    RCFGCALbits.RTCEN = 0;                          // Desliga antes de atualizar o dado
    
    valor = dec_para_bcd( valor );                  // Converte valor para BCD
    
    switch( tipo )                                  // Verifica qual � o registro que deve ser atualizado
    {
    case RTC_ANO:                                   // Se for para atualizar o ano
        registro = PTR_RESERVADO_ANO;               // Atualiza ponteiro de RTCVAL
        
        // Mant�m o byte desprezado (reservado) com o valor atual
        aux.byte_high = dec_para_bcd( rtc.campo.reservado );
        
        // Atualiza o byte especificado (ano) com o novo valor
        aux.byte_low = valor;
        break;
        
    case RTC_RESERVADO:                             // Se for para atualizar o byte reservado (n�o usado)
        registro = PTR_RESERVADO_ANO;               // Atualiza ponteiro de RTCVAL
        
        // Atualiza o byte especificado (reservado) com o novo valor
        aux.byte_high = valor;
        
        // Mant�m o byte desprezado (ano) com o valor atual
        aux.byte_low  = dec_para_bcd( rtc.campo.ano );
        break;
        
    case RTC_DIA:                                   // Se for para atualizar o dia
        registro = PTR_MES_DIA;                     // Atualiza ponteiro de RTCVAL
        
        // Mant�m o byte desprezado (m�s) com o valor atual
        aux.byte_high = dec_para_bcd( rtc.campo.mes );
        
        // Atualiza o byte especificado (dia) com o novo valor
        aux.byte_low = valor;
        break;
        
    case RTC_MES:                                   // Se for para atualizar o m�s
        registro = PTR_MES_DIA;                     // Atualiza ponteiro de RTCVAL
        
        // Atualiza o byte especificado (m�s) com o novo valor
        aux.byte_high = valor;
        
        // Mant�m o byte desprezado (dia) com o valor atual
        aux.byte_low = dec_para_bcd( rtc.campo.dia );
        break;
        
    case RTC_HORA:                                  // Se for para atualizar as horas
        registro = PTR_DIA_SEMANA_HORA;             // Atualiza ponteiro de RTCVAL
        
        // Mant�m o byte desprezado (dia-da-semana) com o valor atual
        aux.byte_high = dec_para_bcd( rtc.campo.dia_semana );
        
        // Atualiza o byte especificado (hora) com o novo valor
        aux.byte_low = valor;
        break;
        
    case RTC_DIA_SEMANA:                            // Se for para atualizar o dia da semana
        registro = PTR_DIA_SEMANA_HORA;             // Atualiza ponteiro de RTCVAL
        
        // Atualiza o byte especificado (dia-da-semana) com o novo valor
        aux.byte_high = valor;
        
        // Mant�m o byte desprezado (hora) com o valor atual
        aux.byte_low = dec_para_bcd( rtc.campo.hora );
        break;
        
    case RTC_SEGUNDO:                               // Se for para atualizar os segundos
        registro = PTR_MINUTO_SEGUNDO;              // Atualiza ponteiro de RTCVAL
        
        // Mant�m o byte desprezado (minuto) com o valor atual
        aux.byte_high = dec_para_bcd( rtc.campo.minuto );
        
        // Atualiza o byte especificado (segundo) com o novo valor
        aux.byte_low = valor;
        break;
        
    case RTC_MINUTO:                                // Se for para atualizar os minutos
        registro = PTR_MINUTO_SEGUNDO;              // Atualiza ponteiro de RTCVAL
        
        // Atualiza o byte especificado (minuto) com o novo valor
        aux.byte_high = valor;
        
        // Mant�m o byte desprezado (segundo) com o valor atual
        aux.byte_low = dec_para_bcd( rtc.campo.segundo );
        break;
    }
    
    seleciona_registro_rtc( registro );             // Aponta para o registro que deve ser atualizado
    RTCVAL = aux.value;                             // Atualiza o registro com o novo valor
    
    RCFGCALbits.RTCEN   = 1;                        // Religa RTC
    RCFGCALbits.RTCWREN = 0;                        // Desabilita escrita, evitando problemas de atualiza��o
    
    RESTORE_CPU_IPL( CPU_IPL );                     // Restaura as configura��es de interrup��o da CPU
}

/****************************************************************************************\
 * seleciona_registro_rtc                                                               *
 * Rotina para selecionar o ponteiro de determinado registro do RTC                     *
 *                                                                                      *
 * Par�metros: registro do RTC (dia, m�s, ano, hora, minuto, segundo)                   *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void seleciona_registro_rtc( unsigned int registro )
{
    RCFGCAL = ( ( RCFGCAL & 0xFCFF ) | registro );  // Zera bit9..8 do registrador RCFCAL (RTCPTR) e adiciona o valor atual do registro
}

/****************************************************************************************\
 * habilita_escrita_rtc                                                                 *
 * Rotina que utiliza seq��ncia obrigat�ria para habilitar escrita do RTC               *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void habilita_escrita_rtc( void )
{
    unsigned char CPU_IPL;
    
    SET_AND_SAVE_CPU_IPL( CPU_IPL, 7 );             // Salva as configura��es atuais da CPU e desabilita as interrup��es
    
    asm volatile("disi #5");                        // Seq��ncia obrigat�ria
    asm volatile("mov #0x55, w7");                  // ...
    asm volatile("mov w7, _NVMKEY");                // ...
    asm volatile("mov #0xAA, w8");                  // ...
    asm volatile("mov w8, _NVMKEY");                // ...
    asm volatile("bset _RCFGCAL, #13");             // Habilita a escrita
    
    RESTORE_CPU_IPL( CPU_IPL );                     // Restaura as configura��es de interrup��o da CPU
}
#endif

/****************************************************************************************\
 * ultimo_dia_mes                                                                       *
 * Rotina que retorna o �ltimo dia do m�s                                               *
 *                                                                                      *
 * Par�metros: m�s e ano dos quais deseja-se saber o �ltimo dia                         *
 * Retorno   : void             			                                            *
\****************************************************************************************/
unsigned char ultimo_dia_mes( unsigned char mes, unsigned char ano )
{
    static const unsigned char ultimo_dia[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    
    if( ( mes == 2 ) && ( ano_bissexto( ano ) ) )   // Se for o m�s de fevereiro e o ano for
        return( ultimo_dia[ mes - 1 ] + 1 );
    
    return( ultimo_dia[ mes - 1 ] );                // Retorna o �ltimo dia do m�s
}

/****************************************************************************************\
 * ano_bissexto                                                                         *
 * Rotina que verifica se o ano em quest�o � bissexto                                   *
 *                                                                                      *
 * Par�metros: ano a verificar                                                          *
 * Retorno   : void             			                                            *
\****************************************************************************************/
unsigned char ano_bissexto( unsigned char ano )
{
    return( ( ano & 0x03 ) == 0 );                  // Se os dois bits menos significativos forem 00, ent�o � ano bissexto
}

/****************************************************************************************\
 * data_valida_rtc                                                                      *
 * Rotina que valida data                                                               *
 *                                                                                      *
 * Par�metros: dia, m�s e ano a verificar                                               *
 * Retorno:    retorna 1 se data estiver correta e 0, em caso contr�rio                 *
\****************************************************************************************/
unsigned char data_valida_rtc( unsigned char dia, unsigned char mes, unsigned char ano )
{
    if( ( mes >=  1 ) &&
        ( mes <= 12 ) )
    {
        if( ano <= 99 )
        {
            if( ( dia >= 1 ) &&
                ( dia <= ultimo_dia_mes( mes, ano ) ) )
            {
                return( 1 );
            }
        }
    }

    return( 0 );
}

/****************************************************************************************\
 * hora_valida_rtc                                                                      *
 * Rotina que valida hora                                                               *
 *                                                                                      *
 * Par�metros: hora, minuto e segundo a verificar                                       *
 * Retorno:    retorna 1 se hora estiver correta e 0, em caso contr�rio                 *
\****************************************************************************************/
unsigned char hora_valida_rtc( unsigned char hora, unsigned char minuto, unsigned char segundo )
{
    if( hora <= 23 )
    {
        if( minuto <= 59 )
        {
            if( segundo <= 59 )
            {
                return( 1 );
            }
        }
    }

    return( 0 );
}
