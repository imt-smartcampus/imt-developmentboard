/****************************************************************************************\
 * 	                             M�dulo RTC - Real Time Clock                         *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _RTC_H_
#define _RTC_H_

#define MOD_RTC
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware

/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_rtc;               // Defini��o de flags do m�dulo RTC
/*****
 * . bit0:  F_ATUALIZA_RTC
 * . bit1:  
 * . bit2:  
 * . bit3:  
 * . bit4:  
 * . bit5:  
 * . bit6:  
 * . bit7:
 ****/
 
/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_ATUALIZA_RTC              flags_rtc.bit0  // Indica se a leitura do RTC est� liberada ou n�o

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Tipo de RTC:
#define RTC_PCF8583                 0
#define RTC_DS1337S                 1
#define RTC_INTERNO                 2
#define RTC_SW                      3
#define TIPO_RTC                    RTC_INTERNO

// Ponteiro dos registros internos:
#define PTR_MINUTO_SEGUNDO          0x0000          /* RTCVAL<15:8>_RTCVAL<7:0> */
#define PTR_DIA_SEMANA_HORA         0x0100          /* RTCVAL<15:8>_RTCVAL<7:0> */
#define PTR_MES_DIA                 0x0200          /* RTCVAL<15:8>_RTCVAL<7:0> */
#define PTR_RESERVADO_ANO           0x0300          /* RTCVAL<15:8>_RTCVAL<7:0> */

// Inicializa��o do RTC:
#define RTC_NAO_ZERAR               0
#define RTC_ZERAR                   1

// Registros internos:
#define RTC_ANO                     0
#define RTC_RESERVADO               1
#define RTC_DIA                     2
#define RTC_MES                     3
#define RTC_HORA                    4
#define RTC_DIA_SEMANA              5
#define RTC_SEGUNDO                 6
#define RTC_MINUTO                  7
#if( TIPO_RTC == RTC_PCF8583 )
    #define END_RAM_ANO_RTC         0x10
#endif

/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef union
{ 
    struct
    {
        unsigned char ano;
        unsigned char reservado;
        unsigned char dia;
        unsigned char mes;
        unsigned char hora;
        unsigned char dia_semana;
        unsigned char segundo;
        unsigned char minuto;
    } campo;
    
    unsigned char b[ 8 ];
    unsigned int  w[ 4 ];
    unsigned long l[ 2 ];
} Rtc;

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:


/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Rtc rtc;                                     // Armazena informa��es do RTC

/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

#if( ( TIPO_RTC == RTC_PCF8583 ) || ( TIPO_RTC == RTC_DS1337S ) )   
    #include "..\i2c\i2c_master_hw.h"               // Arquivo de defini��o vari�veis e fun��es do m�dulo I2C master por HW
    
    #define start_i2c()             start_i2c_master_hw()
    #define restart_i2c()           restart_i2c_master_hw()
    #define stop_i2c()              stop_i2c_master_hw()
    #define status_ack_i2c()        status_ack_i2c_master_hw()
    #define ack_i2c()               ack_i2c_master_hw()
    #define nack_i2c()              nack_i2c_master_hw()
    #define idle_i2c()              idle_i2c_master_hw()
    #define le_bytes_i2c( q, b )    le_bytes_i2c_master_hw( q, b )
    #define le_byte_i2c()           le_byte_i2c_master_hw()
    #define escreve_byte_i2c( b )   escreve_byte_i2c_master_hw( b )
#endif
#define le_dia_rtc()                le_dado_rtc( RTC_DIA )
#define le_mes_rtc()                le_dado_rtc( RTC_MES )
#define le_ano_rtc()                le_dado_rtc( RTC_ANO )
#define le_hora_rtc()               le_dado_rtc( RTC_HORA )
#define le_minuto_rtc()             le_dado_rtc( RTC_MINUTO )
#define le_segundo_rtc()            le_dado_rtc( RTC_SEGUNDO )

/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

#if( TIPO_RTC == RTC_PCF8583 )
inline void inicializa_rtc( unsigned char ano, void ( *ptr )( void ) );
void salva_ano_ram_rtc( void );
unsigned char le_ano_ram_rtc( void );
#else
inline void inicializa_rtc( void );
#endif

void le_rtc( void );
unsigned char le_dado_rtc( unsigned char dado );

unsigned char atualiza_dia_rtc( unsigned char dia );
unsigned char atualiza_mes_rtc( unsigned char mes );
unsigned char atualiza_ano_rtc( unsigned char ano );
unsigned char atualiza_hora_rtc( unsigned char hora );
unsigned char atualiza_minuto_rtc( unsigned char minuto );
unsigned char atualiza_segundo_rtc( unsigned char segundo );

unsigned char ultimo_dia_mes( unsigned char mes, unsigned char ano );
unsigned char ano_bissexto( unsigned char ano );

unsigned char data_valida_rtc( unsigned char dia, unsigned char mes, unsigned char ano );
unsigned char hora_valida_rtc( unsigned char hora, unsigned char minuto, unsigned char segundo );

#endif // _RTC_H_
