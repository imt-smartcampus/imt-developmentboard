
#include "encoder.h"


// The array holds the values �1 for the entries where a position was decremented,
// a 1 for the entries where the position was incremented
// and 0 in all the other (no change or not valid) cases.

const char  KNOBDIR[] = {
    0, -1,  1,  0,
    1,  0,  0, -1,
   -1,  0,  0,  1,
    0,  1, -1,  0  };


// positions: [3] 1 0 2 [3] 1 0 2 [3]
// [3] is the positions where my rotary switch detends
// ==> right, count up
// <== left,  count down


// ----- Initialization and Default Values -----



void atualiza_encoder(void)
{

    static char real_position = 0;     // Internal position (4 times _positionExt)
    static char position = 0;     // Internal position (4 times _positionExt)

    int sig1;
    int sig2;

    sig1 = ENC1_IO;
    sig2 = ENC2_IO;
    //thisState = sig1 | (sig2 << 1);
    //position = KNOBDIR[thisState | (oldState <<2)];
    if (sig1 == sig2 )
    {
        real_position = -1;
    }
    else
    {
        real_position = 1;
    }
    position += real_position;

    if (position < 2)
    {
        position = 2;
    }
    else if (position > 30)
    {
        position = 30;
    } 
    dados.pos_encoder = position;
   
} 

