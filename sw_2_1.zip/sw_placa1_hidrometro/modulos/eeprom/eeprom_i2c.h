/****************************************************************************************\
 * 	                                M�dulo EEPROM I2C                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#ifndef _EEPROM_I2C_H_
#define _EEPROM_I2C_H_

#define MOD_EEPROM_I2C

#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware
#include "..\i2c\mod_i2c_master_hw.h"                   // Arquivo de defini��o vari�veis e fun��es do m�dulo I2C master por HW


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_eeprom_i2c;        // Defini��o de flags do m�dulo EEPROM I2C
/*****
 * . bit0:  F_EEPROM_I2C_ESCREVE_PCT
 * . bit1:  
 * . bit2:  
 * . bit3:  
 * . bit4:  
 * . bit5:  
 * . bit6:  
 * . bit7:
 ****/
 

/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_EEPROM_I2C_ESCREVE_PCT    flags_eeprom_i2c.bit0 // Sinaliza que est� escrevendo na EEPROM, e por isso, uma nova escrita deve aguardar a atual

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Modos de grava��o:
#define TIPO_WR_LIBERA_SW           1               // Carrega contador de tempo T_ESCRITA_EEPROM_I2C milissegundos e s� libera uma pr�xima grava��o ap�s o estouro do temporizador (software � liberado)
#define TIPO_WR_NAO_LIBERA_SW       2               // Aguarda milissegundos e s� libera uma pr�xima grava��o ap�s o estouro do temporizador (software N�O � liberado)
#define EEPROM_I2C_TIPO_WR          TIPO_WR_LIBERA_SW

#define EEPROM_24LC512              0
#define EEPROM_24LC1024             1
#define EEPROM_TAMANHO              EEPROM_24LC512

// Temporizadores:
#define T_ESCRITA_EEPROM_I2C        10              // x 1ms

// Pagina��o:
#define EEPROM_I2C_TAM_PAGINA       128

// Mapeamento dos ports para a mem�ria EEPROM:
#define A2A1A0_EEPROM_I2C_1         0x01


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    unsigned char buffer[ EEPROM_I2C_TAM_PAGINA ];
} Eeprom_I2c;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Eeprom_I2c eeprom_i2c;


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

#define start_i2c()             start_i2c1_master_hw()
#define restart_i2c()           restart_i2c1_master_hw()
#define stop_i2c()              stop_i2c1_master_hw()
#define status_ack_i2c()        status_ack_i2c1_master_hw()
#define ack_i2c()               ack_i2c1_master_hw()
#define nack_i2c()              nack_i2c1_master_hw()
#define idle_i2c()              idle_i2c1_master_hw()
#define le_bytes_i2c( q, b )    le_bytes_i2c1_master_hw( q, b )
#define le_byte_i2c()           le_byte_i2c1_master_hw()
#define escreve_byte_i2c( b )   escreve_byte_i2c1_master_hw( b )
#define wr_eeprom_i2c()         F_EEPROM_I2C_ESCREVE_PCT


/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_eeprom_i2c( void );

void apaga_eeprom_i2c( unsigned char chip );

void escreve_pct_eeprom_i2c( unsigned long end_inicial_eeprom, unsigned char qtd_dados );
void le_pct_eeprom_i2c( unsigned long end_inicial_eeprom, unsigned char qtd_dados );
inline void testa_escrita_pct_eeprom_i2c( void );

void escreve_byte_eeprom_i2c( unsigned long end_eeprom, unsigned char dado );
void escreve_word_eeprom_i2c( unsigned long end_eeprom, unsigned int dado );

unsigned char le_byte_eeprom_i2c( unsigned long end_eeprom );
unsigned int le_word_eeprom_i2c( unsigned long end_eeprom );


#endif // _EEPROM_I2C_H_
