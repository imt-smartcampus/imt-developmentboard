/****************************************************************************************\
 * 	                                M�dulo EEPROM SPI                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#include "eeprom_spi.h"                      // Arquivo de defini��o de vari�veis e fun��es do m�dulo EEPROM SPI


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_eeprom_spi;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char t_escrita_eeprom_spi;


// - Globais ao sistema:
Eeprom_Spi eeprom_spi;


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

void ativa_desativa_cs_eeprom_spi( unsigned char chip, unsigned char estado );
void cs_eeprom_spi( unsigned long endereco, unsigned char estado );


/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/




/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_eeprom_spi  							 	                                *
 * Rotina para iniciar o hardware do m�dulo SPI a fim de conseguir acessar a mem�ria    *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void inicializa_eeprom_spi( void )
{
    flags_eeprom_spi.value = 0;                     // Zera flags do m�dulo EEPROM SPI
    
    ee_inicializa_spi();
}


/****************************************************************************************\
 * ativa_desativa_cs_eeprom_spi                                                         *
 * Rotina para ativar ou desativar o CS da mem�ria EEPROM de acordo com o CS passado    *
 *                                                                                      *
 * Par�metros: endere�o da mem�ria e estado do CS                                       *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void ativa_desativa_cs_eeprom_spi( unsigned char chip, unsigned char estado )
{
    switch( chip )
    {
    case 0:
        #if( defined( CS_EEPROM_SPI_1 ) )
            CS_EEPROM_SPI_1 = estado;
        #endif
        break;
        
    case 1:
        #if( defined( CS_EEPROM_SPI_2 ) )
            CS_EEPROM_SPI_2 = estado;
        #endif
        break;
        
    case 2:
        #if( defined( CS_EEPROM_SPI_3 ) )
            CS_EEPROM_SPI_3 = estado;
        #endif
        break;
        
    case 3:
        #if( defined( CS_EEPROM_SPI_4 ) )
            CS_EEPROM_SPI_4 = estado;
        #endif
        break;
    }
}


/****************************************************************************************\
 * cs_eeprom_spi	                                                                    *
 * Rotina para ativar ou desativar o CS da mem�ria EEPROM de acordo com o endere�o pas- *
 * sado                                                                                 *
 *                                                                                      *
 * Par�metros: endere�o da mem�ria e estado do CS                                       *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void cs_eeprom_spi( unsigned long endereco, unsigned char estado )
{
    unsigned long endereco_aux;
    
    #if( EEPROM_SPI_TAMANHO == EEPROM_25LC512 )
        endereco_aux = endereco >> 16;
    #elif( EEPROM_SPI_TAMANHO == EEPROM_25LC1024 )
        endereco_aux = endereco >> 17;
    #elif( EEPROM_SPI_TAMANHO == EEPROM_25LC010 )
        endereco_aux = endereco >> 7;
    #endif
    
    ativa_desativa_cs_eeprom_spi( endereco_aux, estado );
}


/****************************************************************************************\
 * apaga_eeprom_spi 							 	                                    *
 * Rotina para realizar o chip-erase (preenchimento de mem�ria com 0xFF) de determinado *
 * chip de EEPROM                                                                       *
 *                                                                                      *
 * Par�metros: chip a apagar  						                                    *
 * Retorno   : void        		                                                        *
\****************************************************************************************/
#if ( EEPROM_SPI_TAMANHO != EEPROM_25LC010 )
void apaga_eeprom_spi( unsigned char chip )
{
    ativa_desativa_cs_eeprom_spi( chip, 0 );        // Abaixa pino de sele��o de chip para habilitar o processo de escrita
    ee_escreve_byte_spi( 0x06 );                    // Comando de escrita
    ativa_desativa_cs_eeprom_spi( chip, 1 );        // Sobe pino de sele��o de chip para completar o processo de habilita��o da escrita
    
    /*** PROCESSO DE CHIP ERASE: ***/
    ativa_desativa_cs_eeprom_spi( chip, 0 );        // Abaixa pino de sele��o de chip para iniciar o processo de chip-erase
    ee_escreve_byte_spi( 0xC7 );                    // Comando de chip-erase
    ativa_desativa_cs_eeprom_spi( chip, 1 );        // Sobe pino de sele��o de chip para completar o processo de chip-erase
    
    delay_ms( T_ESCRITA_EEPROM_SPI );			    // Aguarda fim do chip-erase
}
#endif


/****************************************************************************************\
 * escreve_pct_eeprom_spi   	 	                                                    *
 * Rotina para escrever um pacote completo na mem�ria EEPROM, a partir de um endere�o e *
 * para uma determinada quantidade de bytes                                             *
 *                                                                                      *
 * Par�metros: endere�o inicial e quantidade de bytes que ser�o escritos                *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_pct_eeprom_spi( unsigned long end_inicial_eeprom, unsigned char qtd_dados )
{
    unsigned char i;
    unsigned char nova_pag;
#if( EEPROM_SPI_TIPO_WR == TIPO_WR_LE_STATUS )
    unsigned char n_le_status;
#endif
    union unsigned_long endereco;
    
    if( qtd_dados > EEPROM_SPI_TAM_PAGINA )
       return;
    
    endereco.value = end_inicial_eeprom;                        // Armazena o endere�o inicial
    
    i = 0;
    do
    {
        #if( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )          // Deve aguardar escrita antes de liberar software?
            while( F_EEPROM_SPI_ESCREVE_PCT )                   // N�o. Aguarda fim da escrita anterior
                ;                                               // ...
        #endif
        
        /*** PROCESSO DE HABILITA��O DA ESCRITA NA EEPROM: ***/
        cs_eeprom_spi( end_inicial_eeprom, 0 );                 // Abaixa pino de sele��o de chip para habilitar o processo de escrita   
        ee_escreve_byte_spi( 0x06 );                            // Comando de escrita
        cs_eeprom_spi( end_inicial_eeprom, 1 );                 // Sobe pino de sele��o de chip para completar o processo de habilita��o da escrita
        
        /*** PROCESSO DE ESCRITA: ***/
        cs_eeprom_spi( end_inicial_eeprom, 0 );                 // Abaixa pino de sele��o de chip para iniciar o processo de escrita
        ee_escreve_byte_spi( 0x02 );                            // Comando de escrita
        
        #if ( EEPROM_SPI_TAMANHO == EEPROM_25LC1024 )
            ee_escreve_byte_spi( endereco.byte_medium );        // Envia MedByte do endere�o
            ee_escreve_byte_spi( endereco.byte_high   );        // Envia MSByte do endere�o
            ee_escreve_byte_spi( endereco.byte_low    );        // Envia LSByte do endere�o
        #elif ( EEPROM_SPI_TAMANHO == EEPROM_25LC512 )
            ee_escreve_byte_spi( endereco.byte_high );          // Envia MSByte do endere�o
            ee_escreve_byte_spi( endereco.byte_low  );          // Envia LSByte do endere�o
        #else
            ee_escreve_byte_spi( endereco.byte_low );           // Envia LSByte do endere�o
        #endif

        // Grava��o de pacote, podendo inclusive passar de uma p�gina
        nova_pag = 0;
        while( !nova_pag )
        {
            ee_escreve_byte_spi( eeprom_spi.buffer[ i++ ] );    // Envia o dado a ser escrito
            
            endereco.value++;                                   // Aponta para o pr�ximo endere�o
            
            if( i < qtd_dados )
            {
                if( ( endereco.byte_low & ( EEPROM_SPI_TAM_PAGINA - 1 ) ) == 0 )
                {
                    nova_pag = 1;
                }
            }
            else
            {
                break;
            }
        }
        
        cs_eeprom_spi( end_inicial_eeprom, 1 );                 // Sobe pino de sele��o de chip para completar o processo de escrita
        
        end_inicial_eeprom = endereco.value;                    // Atualiza o endere�o inicial da p�gina
        
        #if( EEPROM_SPI_TIPO_WR == TIPO_WR_NAO_LIBERA_SW )      // Deve aguardar escrita antes de liberar software? Sim
            delay_ms( T_ESCRITA_EEPROM_SPI );		            // Ent�o trava software at� o fim da escrita
        #elif( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )        // Deve aguardar escrita antes de liberar software? N�o
            F_EEPROM_SPI_ESCREVE_PCT = 1;                       // Informa que est� enviando o pacote para a EEPROM
            t_escrita_eeprom_spi = T_ESCRITA_EEPROM_SPI;        // Carrega tempo m�ximo de escrita de bytes na EEPROM
        #elif( EEPROM_SPI_TIPO_WR == TIPO_WR_LE_STATUS )        // Deve ler o status do processo de escrita antes de prosseguir? Sim
            n_le_status = 0;
            while( le_status_eeprom_spi( endereco.value - 1 ) & 0x01 )  // Aguarda enquanto WIP estiver em '1'
            {
                if( n_le_status++ < T_ESCRITA_EEPROM_SPI )              // Chegou no tempo m�ximo de espera?
                {                                                       // N�o
                    delay_ms( 1 );                                      // Ent�o aguarda tempo para pr�xima leitura do status
                }
                else                                                    // Tempo m�ximo de espera e status ainda n�o zerou?
                {                                                       // Sim
                    break;                                              // Ent�o sai por tempo
                }
            }
        #endif
    }
    while( i < qtd_dados );
}


/****************************************************************************************\
 * le_pct_eeprom_spi   	 	                                                            *
 * Rotina para ler um pacote completo na mem�ria EEPROM, a partir de um endere�o e com  *
 * uma determinada quantidade de bytes                                                  *
 *                                                                                      *
 * Par�metros: endere�o inicial e quantidade de bytes que ser�o lidos                   *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void le_pct_eeprom_spi( unsigned long end_inicial_eeprom, unsigned char qtd_dados )
{
    unsigned char i;
    
    if( qtd_dados > EEPROM_SPI_TAM_PAGINA )
       return;
    
    #if( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )  // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_SPI_ESCREVE_PCT )           // N�o. Aguarda fim da escrita anterior
            ;                                       // ...
    #endif
    
    i = 0;
    while( qtd_dados-- )
    {
        eeprom_spi.buffer[ i++ ] = le_byte_eeprom_spi( end_inicial_eeprom++ );
    }
}


/****************************************************************************************\
 * testa_escrita_pct_eeprom_spi					 	                                    *
 * Rotina para verificar se foi conclu�da a escrita de um bloco de mem�ria EEPROM SPI   *
 * Esta rotina deve ser chamada em uma base de tempo de 1ms                             *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno   : dado lido					                                            *
\****************************************************************************************/
inline void testa_escrita_pct_eeprom_spi( void )
{
    if( F_EEPROM_SPI_ESCREVE_PCT )                  // Est� enviando pacote para EEPROM?
    {                                               // Sim
        t_escrita_eeprom_spi--;                     // Decrementa tempo de fim de escrita
        if( !t_escrita_eeprom_spi )                 // Fim do tempo?
        {                                           // Sim
            F_EEPROM_SPI_ESCREVE_PCT = 0;           // Sinaliza fim da grava��o
        }
    }
}


/****************************************************************************************\
 * escreve_byte_eeprom_spi 							 	                                *
 * Rotina para escrever um byte na mem�ria EEPROM SPI					                *
 *                                                                                      *
 * Par�metros: endere�o e dado						                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void escreve_byte_eeprom_spi( unsigned long end_eeprom, unsigned char dado )
{
#if( EEPROM_SPI_TIPO_WR == TIPO_WR_LE_STATUS )
    unsigned char n_le_status;
#endif
    union unsigned_long endereco;
    
    #if( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )      // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_SPI_ESCREVE_PCT )               // N�o. Aguarda fim da escrita anterior
            ;                                           // ...
    #endif
    
    endereco.value = end_eeprom;
    
    /*** PROCESSO DE HABILITA��O DA ESCRITA NA EEPROM: ***/
    cs_eeprom_spi( endereco.value, 0 );                 // Abaixa pino de sele��o de chip para habilitar o processo de escrita
    ee_escreve_byte_spi( 0x06 );                        // Comando de escrita
    cs_eeprom_spi( endereco.value, 1 );                 // Sobe pino de sele��o de chip para completar o processo de habilita��o da escrita
    
    /*** PROCESSO DE ESCRITA: ***/
    cs_eeprom_spi( endereco.value, 0 );                 // Abaixa pino de sele��o de chip para iniciar o processo de escrita
    ee_escreve_byte_spi( 0x02 );                        // Comando de escrita
    
    #if ( EEPROM_SPI_TAMANHO == EEPROM_25LC1024 )
        ee_escreve_byte_spi( endereco.byte_medium ) ;   // Envia MedByte do endere�o
        ee_escreve_byte_spi( endereco.byte_high   ) ;   // Envia MSByte do endere�o
        ee_escreve_byte_spi( endereco.byte_low    ) ;   // Envia LSByte do endere�o
    #elif ( EEPROM_SPI_TAMANHO == EEPROM_25LC512 )
        ee_escreve_byte_spi( endereco.byte_high ) ;     // Envia MSByte do endere�o
        ee_escreve_byte_spi( endereco.byte_low  ) ;     // Envia LSByte do endere�o
    #else
        ee_escreve_byte_spi( endereco.byte_low ) ;      // Envia LSByte do endere�o
    #endif
    
    ee_escreve_byte_spi( dado );                        // Envia o dado a ser escrito
    
    cs_eeprom_spi( endereco.value, 1 );                 // Sobe pino de sele��o de chip para completar o processo de escrita
    
    #if( EEPROM_SPI_TIPO_WR == TIPO_WR_NAO_LIBERA_SW )              // Deve aguardar escrita antes de liberar software? Sim
        delay_ms( T_ESCRITA_EEPROM_SPI );		                    // Ent�o trava software at� o fim da escrita
    #elif( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )                // Deve aguardar escrita antes de liberar software? N�o
        F_EEPROM_SPI_ESCREVE_PCT = 1;                               // Informa que est� enviando o pacote para a EEPROM
        t_escrita_eeprom_spi = T_ESCRITA_EEPROM_SPI;                // Carrega tempo m�ximo de escrita de bytes na EEPROM
    #elif( EEPROM_SPI_TIPO_WR == TIPO_WR_LE_STATUS )                // Deve ler o status do processo de escrita antes de prosseguir? Sim
        n_le_status = 0;
        while( le_status_eeprom_spi( endereco.value - 1 ) & 0x01 )  // Aguarda enquanto WIP estiver em '1'
        {
            if( n_le_status++ < T_ESCRITA_EEPROM_SPI )              // Chegou no tempo m�ximo de espera?
            {                                                       // N�o
                delay_ms( 1 );                                      // Ent�o aguarda tempo para pr�xima leitura do status
            }
            else                                                    // Tempo m�ximo de espera e status ainda n�o zerou?
            {                                                       // Sim
                break;                                              // Ent�o sai por tempo
            }
        }
    #endif
}


/****************************************************************************************\
 * escreve_word_eeprom_spi 							 	                                *
 * Rotina para escrever uma word na mem�ria EEPROM SPI					                *
 *                                                                                      *
 * Par�metros: endere�o e dado						                                    *
 * Retorno   : void							                                            *
\****************************************************************************************/
void escreve_word_eeprom_spi( unsigned long end_eeprom, unsigned int dado )
{
    union unsigned_int word;
    
    word.value = dado;
    
    escreve_byte_eeprom_spi( end_eeprom++, word.byte_high );
    escreve_byte_eeprom_spi( end_eeprom  , word.byte_low  );
}


/****************************************************************************************\
 * le_byte_eeprom_spi 							 	                                    *
 * Rotina para ler um byte da mem�ria EEPROM SPI					                    *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno   : dado lido					                                            *
\****************************************************************************************/
unsigned char le_byte_eeprom_spi( unsigned long end_eeprom )
{
    union unsigned_long endereco;
    unsigned char dado;
    
    #if( EEPROM_SPI_TIPO_WR == TIPO_WR_LIBERA_SW )  // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_SPI_ESCREVE_PCT )           // N�o. Aguarda fim da escrita anterior
            ;                                       // ...
    #endif
    
    endereco.value = end_eeprom;
    
    /*** PROCESSO DE LEITURA: ***/
    cs_eeprom_spi( endereco.value, 0 );             // Abaixa pino de sele��o de chip para habilitar o processo de leitura
    ee_escreve_byte_spi( 0x03 );                    // Comando de leitura
    
    #if ( EEPROM_SPI_TAMANHO == EEPROM_25LC1024 )
        ee_escreve_byte_spi( endereco.byte_medium ) ; // Envia MedByte do endere�o
        ee_escreve_byte_spi( endereco.byte_high   ) ; // Envia MSByte do endere�o
        ee_escreve_byte_spi( endereco.byte_low    ) ; // Envia LSByte do endere�o
    #elif ( EEPROM_SPI_TAMANHO == EEPROM_25LC512 )
        ee_escreve_byte_spi( endereco.byte_high ) ;   // Envia MSByte do endere�o
        ee_escreve_byte_spi( endereco.byte_low  ) ;   // Envia LSByte do endere�o
    #else
        ee_escreve_byte_spi( endereco.byte_low ) ;    // Envia LSByte do endere�o
    #endif

    ee_escreve_byte_spi( 0x00 );                    // Disponibiliza dado no buffer para depois ler
    dado = ee_le_byte_spi();                        // L� dado
    
    cs_eeprom_spi( endereco.value, 1 );             // Sobe pino de sele��o de chip para finalizar a comunica��o
    
	return( dado );
}


/****************************************************************************************\
 * le_word_eeprom_spi 							 	                                    *
 * Rotina para ler uma word da mem�ria EEPROM SPI					                    *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno   : dado lido					                                            *
\****************************************************************************************/
unsigned int le_word_eeprom_spi( unsigned long end_eeprom )
{
    union unsigned_int word;
    
    word.byte_high = le_byte_eeprom_spi( end_eeprom++ );
    word.byte_low  = le_byte_eeprom_spi( end_eeprom   );
    
    return( word.value );
}



/****************************************************************************************\
 * le_status_eeprom_spi 							 	                                *
 * Rotina para ler uma word da mem�ria EEPROM SPI					                    *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno   : status lido					                                            *
\****************************************************************************************/
unsigned char le_status_eeprom_spi( unsigned long endereco )
{
    unsigned char status;
    
    cs_eeprom_spi( endereco, 0 );                   // Abaixa pino de sele��o de chip para habilitar o processo de leitura
    
    ee_escreve_byte_spi( 0x05 );                    // Comando de leitura de status
    ee_escreve_byte_spi( 0x00 );                    // Disponibiliza dado no buffer para depois ler
    status = ee_le_byte_spi();                      // L� status
    
    cs_eeprom_spi( endereco, 1 );                   // Sobe pino de sele��o de chip para finalizar a comunica��o
    
    return( status );
}
