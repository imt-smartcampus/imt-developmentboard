/****************************************************************************************\
 * 	                                M�dulo EEPROM SPI                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#ifndef _EEPROM_SPI_H_
#define _EEPROM_SPI_H_

#define MOD_EEPROM_SPI

#include "..\..\fw\fw.h"                                 // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware
#include "..\spi\spi_master_hw.h"                      // Arquivo de defini��o vari�veis e fun��es do m�dulo SPI master por HW


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_char flags_eeprom_spi;        // Defini��o de flags do m�dulo EEPROM SPI
/*****
 * . bit0:  F_EEPROM_SPI_ESCREVE_PCT
 * . bit1:  
 * . bit2:  
 * . bit3:  
 * . bit4:  
 * . bit5:  
 * . bit6:  
 * . bit7:
 ****/
 

/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_EEPROM_SPI_ESCREVE_PCT    flags_eeprom_spi.bit0 // Sinaliza que est� escrevendo na EEPROM, e por isso, uma nova escrita deve aguardar a atual

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Modos de grava��o:
#define TIPO_WR_LE_STATUS           0                     // Mant�m-se em rotina de escrita at� que status de escrita seja OK (bit Write-In-Process estiver em 1)
#define TIPO_WR_LIBERA_SW           1                     // Carrega contador de tempo T_ESCRITA_EEPROM_SPI milissegundos e s� libera uma pr�xima grava��o ap�s o estouro do temporizador (software � liberado)
#define TIPO_WR_NAO_LIBERA_SW       2                     // Aguarda milissegundos e s� libera uma pr�xima grava��o ap�s o estouro do temporizador (software N�O � liberado)
#define EEPROM_SPI_TIPO_WR          TIPO_WR_NAO_LIBERA_SW

#define EEPROM_25LC512              0
#define EEPROM_25LC1024             1
#define EEPROM_25LC010              2
#define EEPROM_SPI_TAMANHO          EEPROM_25LC512

// Temporizadores:
#if ( EEPROM_SPI_TAMANHO == EEPROM_25LC010 )
    #define T_ESCRITA_EEPROM_SPI    6              // x 1ms
#else
    #define T_ESCRITA_EEPROM_SPI    10              // x 1ms
#endif

// Pagina��o:
#if ( EEPROM_SPI_TAMANHO == EEPROM_25LC010 )
    #define EEPROM_SPI_TAM_PAGINA       16
#else
    #define EEPROM_SPI_TAM_PAGINA       128
#endif

// Mapeamento dos ports para a mem�ria EEPROM:
#define CS_EEPROM_SPI_1             CS_M


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    unsigned char buffer[ EEPROM_SPI_TAM_PAGINA ];
} Eeprom_Spi;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
extern Eeprom_Spi eeprom_spi;


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/

#define ee_inicializa_spi()         inicializa_spi2_master_hw()
#define ee_le_byte_spi()            le_byte_spi2_master_hw()
#define ee_escreve_byte_spi( b )    escreve_byte_spi2_master_hw( b )
#define wr_eeprom_spi()             F_EEPROM_SPI_ESCREVE_PCT


/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

inline void inicializa_eeprom_spi( void );

#if ( EEPROM_SPI_TAMANHO != EEPROM_25LC010 )
    void apaga_eeprom_spi( unsigned char chip );
#endif

void escreve_pct_eeprom_spi( unsigned long end_inicial_eeprom, unsigned char qtd_dados );
void le_pct_eeprom_spi( unsigned long end_inicial_eeprom, unsigned char qtd_dados );
inline void testa_escrita_pct_eeprom_spi( void );

void escreve_byte_eeprom_spi( unsigned long end_eeprom, unsigned char dado );
void escreve_word_eeprom_spi( unsigned long end_eeprom, unsigned int dado );

unsigned char le_byte_eeprom_spi( unsigned long end_eeprom );
unsigned int le_word_eeprom_spi( unsigned long end_eeprom );

unsigned char le_status_eeprom_spi( unsigned long endereco );


#endif // _EEPROM_SPI_H_
