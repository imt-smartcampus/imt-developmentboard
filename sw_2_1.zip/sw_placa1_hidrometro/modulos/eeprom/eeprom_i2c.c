/****************************************************************************************\
 * 	                                M�dulo EEPROM I2C                                   *
 *									                                                    *
 *	                Desenvolvido pela Hiware - Mosaico Technology Division              *
 *									                                                    *
 * Web: www.hiware.com.br		                           E-mail: hiware@hiware.com.br *
 *									                                                    *
 * 				                                	                                    *
\****************************************************************************************/

#include "eeprom_i2c.h"                             // Arquivo de defini��o de vari�veis e fun��es do m�dulo EEPROM I2C


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_char flags_eeprom_i2c;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char t_escrita_eeprom_i2c;

// - Globais ao sistema:
Eeprom_I2c eeprom_i2c;


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

unsigned char seleciona_a2a1a0_eeprom_i2c( unsigned char chip );
void comando_wr_eeprom_i2c( unsigned long end_eeprom );
void comando_rd_eeprom_i2c( unsigned long end_eeprom );


/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/



/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_eeprom_i2c  							 	                                *
 * Rotina para iniciar o hardware do m�dulo I2C a fim de conseguir acessar a mem�ria    *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno:    void							                                            *
\****************************************************************************************/
inline void inicializa_eeprom_i2c( void )
{
    flags_eeprom_i2c.value = 0;                     // Zera flags do m�dulo EEPROM I2C
    
    inicializa_i2c1_master_hw();
}


/****************************************************************************************\
 * seleciona_a2a1a0_eeprom_i2c                                                          *
 * Rotina para selecionar o endere�o do chip da mem�ria EEPROM de acordo com o n�mero do*
 * chip passado                                                                         *
 *                                                                                      *
 * Par�metros: chip da mem�ria                                                          *
 * Retorno   : endere�o A2A1A0                                                          *
\****************************************************************************************/
unsigned char seleciona_a2a1a0_eeprom_i2c( unsigned char chip )
{
    switch( chip )
    {
    case 0:
        chip = A2A1A0_EEPROM_I2C_1;
        break;
        
    case 1:
        #if( defined( A2A1A0_EEPROM_I2C_2 ) )
            chip = A2A1A0_EEPROM_I2C_2;
        #endif
        break;
        
    case 2:
        #if( defined( A2A1A0_EEPROM_I2C_3 ) )
            chip = A2A1A0_EEPROM_I2C_3;
        #endif
        break;
        
    case 3:
        #if( defined( A2A1A0_EEPROM_I2C_4 ) )
            chip = A2A1A0_EEPROM_I2C_4;
        #endif
        break;
    }
    
    return( chip << 1 );
}


/****************************************************************************************\
 * comando_wr_eeprom_i2c                                                                *
 * Rotina para ativar o chip da mem�ria EEPROM de acordo com o endere�o passado e enviar*
 * o comando de escrita                                                                 *
 *                                                                                      *
 * Par�metros: endere�o da mem�ria                                                      *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void comando_wr_eeprom_i2c( unsigned long end_eeprom )
{
    unsigned char pastilha;
    union unsigned_long endereco;
    
    #if( EEPROM_TAMANHO == EEPROM_24LC512 )
        pastilha = seleciona_a2a1a0_eeprom_i2c( end_eeprom >> 16 );
    #else
        pastilha = seleciona_a2a1a0_eeprom_i2c( end_eeprom >> 15 );
    #endif
    
    endereco.value = end_eeprom;
    
    idle_i2c(); 				                    // Espera fim do evento I2C
    start_i2c();
    escreve_byte_i2c( 0xA0 | pastilha );            // Controle de escrita: [1][0][1][0][A2][A1][A0][R/W] com R/W = 0
    idle_i2c(); 				                    // Espera fim do evento I2C
    escreve_byte_i2c( endereco.byte_high );
    idle_i2c();				                        // Espera fim do evento I2C
    escreve_byte_i2c( endereco.byte_low );
    idle_i2c();				                        // Espera fim do evento I2C
}


/****************************************************************************************\
 * comando_rd_eeprom_i2c                                                                *
 * Rotina para enviar o commando de leitura                                             *
 *                                                                                      *
 * Par�metros: endere�o da mem�ria                                                      *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void comando_rd_eeprom_i2c( unsigned long end_eeprom )
{
    unsigned char pastilha;
    
    #if( EEPROM_TAMANHO == EEPROM_24LC512 )
        pastilha = seleciona_a2a1a0_eeprom_i2c( end_eeprom >> 16 );
    #else
        pastilha = seleciona_a2a1a0_eeprom_i2c( end_eeprom >> 15 );
    #endif
    
	escreve_byte_i2c( 0xA1 | pastilha );			// Controle de leitura: [1][0][1][0][A2][A1][A0][R/W] com R/W = 0
	idle_i2c();						                // Espera fim do evento I2C
}



/****************************************************************************************\
 * apaga_eeprom_i2c 							 	                                    *
 * Rotina para realizar o chip-erase (preenchimento de mem�ria com 0xFF) de determinado *
 * chip de EEPROM                                                                       *
 *                                                                                      *
 * Par�metros: chip a apagar  						                                    *
 * Retorno   : void        		                                                        *
\****************************************************************************************/
void apaga_eeprom_i2c( unsigned char chip )
{
    unsigned int  i;
    unsigned long paginas;
    unsigned long endereco;
    
    #if( EEPROM_TAMANHO == EEPROM_24LC512 )
        paginas = 65536;
    #else
        paginas = 32768;
    #endif
    
    // Como n�o h� comando de chip-erase, ser�o preenchidos com 0xFF todos os btes de cada p�gina
    preenche_buffer( eeprom_i2c.buffer, 0xFF, EEPROM_I2C_TAM_PAGINA );
    
    // Calcula o endere�o, a partir do chip desejado
    endereco = 0;
    for( i = 0 ; i < chip ; i++ )
    {
        endereco += paginas;
    }
    
    // Calcula o total de p�ginas para o chip
    paginas /= EEPROM_I2C_TAM_PAGINA;
    for( i = 0 ; i < paginas ; i++ )
    {
        ClrWdt();
        escreve_pct_eeprom_i2c( endereco, EEPROM_I2C_TAM_PAGINA );
        endereco += EEPROM_I2C_TAM_PAGINA;
    }
}


/****************************************************************************************\
 * escreve_pct_eeprom_i2c   	 	                                                    *
 * Rotina para escrever um pacote completo na mem�ria EEPROM, a partir de um endere�o e *
 * para uma determinada quantidade de bytes                                             *
 *                                                                                      *
 * Par�metros: endere�o inicial e quantidade de bytes que ser�o escritos                *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_pct_eeprom_i2c( unsigned long end_inicial_eeprom, unsigned char qtd_dados )
{
    unsigned char i;
    unsigned char nova_pag;
    union unsigned_long endereco;
    
    if( qtd_dados > EEPROM_I2C_TAM_PAGINA )
       return;
    
    endereco.value = end_inicial_eeprom;                        // Armazena o endere�o inicial
    
    i = 0;
    do
    {
        #if( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )          // Deve aguardar escrita antes de liberar software?
            while( F_EEPROM_I2C_ESCREVE_PCT )                   // N�o. Aguarda fim da escrita anterior
                ;                                               // ...
        #endif
        
        /*** PROCESSO DE ESCRITA: ***/
        comando_wr_eeprom_i2c( end_inicial_eeprom );            // Seleciona a pastilha e envia comando de escrita
        
        // Grava��o de pacote, podendo inclusive passar de uma p�gina
        nova_pag = 0;
        while( !nova_pag )
        {
            escreve_byte_i2c( eeprom_i2c.buffer[ i++ ] );       // Envia o dado a ser escrito
            idle_i2c();				                            // Espera fim do evento I2C
            status_ack_i2c();
            
            endereco.value++;                                   // Aponta para o pr�ximo endere�o
            
            if( i < qtd_dados )
            {
                if( ( endereco.byte_low & ( EEPROM_I2C_TAM_PAGINA - 1 ) ) == 0 )
                {
                    nova_pag = 1;
                }
            }
            else
            {
                break;
            }
        }
        
        idle_i2c();				                                // Espera fim do evento I2C
        stop_i2c();				                                // Fim da comunica��o
        
        end_inicial_eeprom = endereco.value;                    // Atualiza o endere�o inicial da p�gina
        
        #if( EEPROM_I2C_TIPO_WR == TIPO_WR_NAO_LIBERA_SW )      // Deve aguardar escrita antes de liberar software? Sim
            delay_ms( T_ESCRITA_EEPROM_I2C );		            // Ent�o trava software at� o fim da escrita
        #elif( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )        // Deve aguardar escrita antes de liberar software? N�o
            F_EEPROM_I2C_ESCREVE_PCT = 1;                       // Informa que est� enviando o pacote para a EEPROM
            t_escrita_eeprom_i2c = T_ESCRITA_EEPROM_I2C;        // Carrega tempo m�ximo de escrita de bytes na EEPROM
        #endif
    }
    while( i < qtd_dados );
}


/****************************************************************************************\
 * le_pct_eeprom_i2c   	 	                                                            *
 * Rotina para ler um pacote completo na mem�ria EEPROM, a partir de um endere�o e com  *
 * uma determinada quantidade de bytes                                                  *
 *                                                                                      *
 * Par�metros: endere�o inicial e quantidade de bytes que ser�o lidos                   *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void le_pct_eeprom_i2c( unsigned long end_inicial_eeprom, unsigned char qtd_dados )
{
    if( qtd_dados > EEPROM_I2C_TAM_PAGINA )
       return;
    
    #if( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )  // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_I2C_ESCREVE_PCT )           // N�o. Aguarda fim da escrita anterior
            ;                                       // ...
    #endif
    
    comando_wr_eeprom_i2c( end_inicial_eeprom );    // Seleciona a pastilha e envia comando de escrita
	restart_i2c();
    comando_rd_eeprom_i2c( end_inicial_eeprom );    // Comando de leitura
	
    le_bytes_i2c( eeprom_i2c.buffer, qtd_dados );
	
    nack_i2c();
    stop_i2c();						                // Fim da comunica��o
}


/****************************************************************************************\
 * testa_escrita_pct_eeprom_i2c					 	                                    *
 * Rotina para verificar se foi conclu�da a escrita de um bloco de mem�ria EEPROM I2C   *
 * Esta rotina deve ser chamada em uma base de tempo de 1ms                             *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno   : dado lido					                                            *
\****************************************************************************************/
inline void testa_escrita_pct_eeprom_i2c( void )
{
    if( F_EEPROM_I2C_ESCREVE_PCT )                  // Est� enviando pacote para EEPROM?
    {                                               // Sim
        t_escrita_eeprom_i2c--;                     // Decrementa tempo de fim de escrita
        if( !t_escrita_eeprom_i2c )                 // Fim do tempo?
        {                                           // Sim
            F_EEPROM_I2C_ESCREVE_PCT = 0;           // Sinaliza fim da grava��o
        }
    }
}


/****************************************************************************************\
 * escreve_byte_eeprom_i2c 							 	                                *
 * Rotina para escrever um byte na mem�ria EEPROM I2C					                *
 *                                                                                      *
 * Par�metros: endere�o e dado						                                    *
 * Retorno:    void							                                            *
\****************************************************************************************/
void escreve_byte_eeprom_i2c( unsigned long end_eeprom, unsigned char dado )
{
    #if( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )  // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_I2C_ESCREVE_PCT )           // N�o. Aguarda fim da escrita anterior
            ;                                       // ...
    #endif
    
    comando_wr_eeprom_i2c( end_eeprom );            // Seleciona a pastilha e envia comando de escrita
	escreve_byte_i2c( dado );				        // Controle de leitura
	idle_i2c();				                        // Espera fim do evento I2C
    stop_i2c();				                        // Fim da comunica��o
    
	#if( EEPROM_I2C_TIPO_WR == TIPO_WR_NAO_LIBERA_SW ) // Deve aguardar escrita antes de liberar software? Sim
        delay_ms( T_ESCRITA_EEPROM_I2C );		    // Ent�o trava software at� o fim da escrita
    #elif( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )// Deve aguardar escrita antes de liberar software? N�o
        F_EEPROM_I2C_ESCREVE_PCT = 1;               // Informa que est� enviando o pacote para a EEPROM
        t_escrita_eeprom_i2c = T_ESCRITA_EEPROM_I2C;// Carrega tempo m�ximo de escrita de bytes na EEPROM
    #endif
}


/****************************************************************************************\
 * escreve_word_eeprom_i2c 							 	                                *
 * Rotina para escrever uma word na mem�ria EEPROM I2C					                *
 *                                                                                      *
 * Par�metros: endere�o e dado						                                    *
 * Retorno:    void							                                            *
\****************************************************************************************/
void escreve_word_eeprom_i2c( unsigned long end_eeprom, unsigned int dado )
{
    union unsigned_int word;
    
    word.value = dado;
    
    escreve_byte_eeprom_i2c( end_eeprom++, word.byte_high );
    escreve_byte_eeprom_i2c( end_eeprom  , word.byte_low  );
}


/****************************************************************************************\
 * le_byte_eeprom_i2c 							 	                                    *
 * Rotina para ler um byte da mem�ria EEPROM I2C					                    *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno:    dado lido					                                            *
\****************************************************************************************/
unsigned char le_byte_eeprom_i2c( unsigned long end_eeprom )
{
    unsigned char dado;
    
    #if( EEPROM_I2C_TIPO_WR == TIPO_WR_LIBERA_SW )  // Deve aguardar escrita antes de liberar software?
        while( F_EEPROM_I2C_ESCREVE_PCT )           // N�o. Aguarda fim da escrita anterior
            ;                                       // ...
    #endif
    
    comando_wr_eeprom_i2c( end_eeprom );            // Seleciona a pastilha e envia comando de escrita
	restart_i2c();
    comando_rd_eeprom_i2c( end_eeprom );            // Comando de leitura
	dado = le_byte_i2c();                           // Realiza a leitura
	nack_i2c();
	stop_i2c();						                // Fim da comunica��o
	
	return( dado );
}


/****************************************************************************************\
 * le_word_eeprom_i2c 							 	                                    *
 * Rotina para ler uma word da mem�ria EEPROM I2C					                    *
 *                                                                                      *
 * Par�metros: endere�o       						                                    *
 * Retorno:    dado lido					                                            *
\****************************************************************************************/
unsigned int le_word_eeprom_i2c( unsigned long end_eeprom )
{
    union unsigned_int word;
    
    word.byte_high = le_byte_eeprom_i2c( end_eeprom++ );
    word.byte_low  = le_byte_eeprom_i2c( end_eeprom   );
    
    return( word.value );
}
