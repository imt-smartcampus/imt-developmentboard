/****************************************************************************************\
 * 	                                    M�dulo UART                                   *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#ifndef _UART_H_
#define _UART_H_

#define MOD_UART
#include "..\..\fw\fw.h"                            // Arquivo de defini��o de pinos, vari�veis e fun��es do firmware


/****************************************************************************************\
 *******  	  	   	      				                                        *********
 *******  	                          MAPAS DE FLAGS      		                *********
 *******  	  	   	      				                                        *********
\****************************************************************************************/

extern union unsigned_int flags_uart;              // Defini��o de flags do m�dulo UART
/*****
 * . bit0:  F_UART_1_INI_TX
 * . bit1:  F_UART_1_TX
 * . bit2:  F_UART_1_PCT_RX
 * . bit3:  F_UART_2_INI_TX
 * . bit4:  F_UART_2_TX
 * . bit5:  F_UART_2_PCT_RX
 * . bit6:  F_UART_1_RTS
 * . bit7:  F_UART_2_RTS
 ****/


/****************************************************************************************\
 * 		                            Defini��o de constantes           		            *
\****************************************************************************************/

/********************************************\
 *                  Flags:                  *
\********************************************/

#define F_UART_1_INI_TX            flags_uart.bit0  // Inicia transmiss�o de pacote em UART1
#define F_UART_1_TX                flags_uart.bit1  // Indica se est� ou n�o transmitindo pacote em UART1
#define F_UART_1_PCT_RX            flags_uart.bit2  // Sinaliza recep��o de pacote em UART1
#define F_UART_2_INI_TX            flags_uart.bit3  // Inicia transmiss�o de pacote em UART2
#define F_UART_2_TX                flags_uart.bit4  // Indica se est� ou n�o transmitindo pacote em UART2
#define F_UART_2_PCT_RX            flags_uart.bit5  // Sinaliza recep��o de pacote em UART2
#define F_UART_1_RTS               flags_uart.bit6  // Estado do pino de sa�da RTS
#define F_UART_2_RTS               flags_uart.bit7  // Estado do pino de sa�da RTS

#define F_UART_3_INI_TX            flags_uart.bit8  // Inicia transmiss�o de pacote em UART2
#define F_UART_3_TX                flags_uart.bit9  // Indica se est� ou n�o transmitindo pacote em UART2
#define F_UART_3_PCT_RX            flags_uart.bit10  // Sinaliza recep��o de pacote em UART2
#define F_UART_3_RTS               flags_uart.bit11  // Estado do pino de sa�da RTS

/********************************************\
 *                Auxiliares:               *
\********************************************/

// Modos de opera��o:
#define CTRL_FLUXO_OFF              0
#define CTRL_FLUXO_ON               1
#define TIPO_UART_1                 CTRL_FLUXO_OFF
#define TIPO_UART_2                 CTRL_FLUXO_OFF
#define TIPO_UART_3                 CTRL_FLUXO_OFF

// Temporizadores:
#define TOUT_TX_1                   5               // x 1ms
#define TOUT_TX_2                   20              // x 1ms
#define TOUT_TX_3                   20              // x 1ms
#define TOUT_RX_1                   10              // x 1ms
#define TOUT_RX_2                   50              // x 1ms
#define TOUT_RX_3                   1              // x 1ms

// Baud-rate:
// 1) Para BRGH = 0: X = (FCY / (16 * br)) - 1
//               +------------+------------+------------+------------+------------+------------+
//               |    1 MHz   |    4 MHz   |    8 MHz   |   12 MHz   |   16 MHz   |   40 MHz   |
//  +------------+------------+------------+------------+------------+------------+------------+
//  |    110 bps |       567  |     2272   |     4544   |     6817   |     9090   |    22726   |
//  |    300 bps |       207  |      832   |     1666   |     2499   |     3332   |     8332   |
//  |   1200 bps |        51  |      207   |      416   |      624   |      832   |     2082   |
//  |   2400 bps |        25  |      103   |      207   |      312   |      416   |     1041   |
//  |   9600 bps |         6  |       25   |       51   |       77   |      103   |      259   |
//  |  19200 bps |         2  |       12   |       25   |       38   |       51   |      129   |
//  |  38400 bps |         1  |        6   |       12   |       19   |       25   |       64   |
//  |  57600 bps |         -  |        3   |        8   |       12   |       17   |       42   |
//  | 115200 bps |         -  |        1   |        3   |        6   |        8   |       21   |
//  +------------+------------+------------+------------+------------+------------+------------+
//
// 2) Para BRGH = 1: X = (FCY / (4 * br)) - 1
//               +------------+------------+------------+------------+------------+------------+
//               |    1 MHz   |    4 MHz   |    8 MHz   |   12 MHz   |   16 MHz   |   40 MHz   |
//  +------------+------------+------------+------------+------------+------------+------------+
//  |    110 bps |      2272  |     9090   |    18181   |    27272   |    36363   |    90908   |
//  |    300 bps |       832  |     3332   |     6666   |     9999   |    13332   |    33332   |
//  |   1200 bps |       207  |      832   |     1666   |     2499   |     3332   |     8332   |
//  |   2400 bps |       103  |      416   |      832   |     1249   |     1666   |     4166   |
//  |   4800 bps |        51  |      207   |      416   |      624   |      832   |     2082   |
//  |   9600 bps |        25  |      103   |      207   |      312   |      416   |     1041   |
//  |  19200 bps |        12  |       51   |      103   |      155   |      207   |      520   |
//  |  38400 bps |         6  |       25   |       51   |       77   |      103   |      259   |
//  |  57600 bps |         3  |       16   |       34   |       51   |       68   |      173   |
//  | 115200 bps |         1  |        8   |       16   |       25   |       34   |       86   |
//  +------------+------------+------------+------------+------------+------------+------------+

#define BR_110                      9090//36363
#define BR_300                      3332//13332
#define BR_1200                     832//3332
#define BR_2400                     416//1666
#define BR_4800                     207//822
#define BR_9600                     103//416
#define BR_19200                    51//207
#define BR_38400                    25//103
#define BR_57600                    16//68
#define BR_115200                   8//34


// Paridade:
#define PARIDADE_NONE               0
#define PARIDADE_ODD                1
#define PARIDADE_EVEN               2

// Buffers de transmiss�o e recep��o:
#define UART_1_QTD_TX               128
#define UART_2_QTD_TX               64
#define UART_3_QTD_TX               128
#define UART_1_QTD_RX               128
#define UART_2_QTD_RX               64
#define UART_3_QTD_RX               300

// UARTs:
#if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    #define UART_1                  0
#endif
#if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    #define UART_2                  1
#endif
#if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    #define UART_3                  2
#endif

// Mapeamento dos ports para a UART:
#if( TIPO_UART_1 == CTRL_FLUXO_ON )
    #define UART_1_RTS              RTS_1
    #define UART_1_CTS              CTS_1
#endif
#if( TIPO_UART_2 == CTRL_FLUXO_ON )
    #define UART_2_RTS              RTS_2
    #define UART_2_CTS              CTS_2
#endif
#if( TIPO_UART_3 == CTRL_FLUXO_ON )
    #define UART_3_RTS              RTS_3
    #define UART_3_CTS              CTS_3
#endif


/****************************************************************************************\
 * 	  	                      Defini��o de estruturas do m�dulo           		        *
\****************************************************************************************/

typedef struct
{
    #if( UART_1_QTD_TX != 0 )
        unsigned char tx[ UART_1_QTD_TX ];
        
        unsigned int  tam_tx;
        unsigned char contador_tx;
        unsigned char timeout_tx;
    #endif
    
    #if( UART_1_QTD_RX != 0 )
        unsigned char rx[ UART_1_QTD_RX ];
        unsigned int  tam_rx;
        
        unsigned char timeout_rx;
    #endif
} Uart_1;

typedef struct
{
    #if( UART_2_QTD_TX != 0 )
        unsigned char tx[ UART_2_QTD_TX ];
        
        unsigned int  tam_tx;
        unsigned char contador_tx;
        unsigned char timeout_tx;
    #endif
    
    #if( UART_2_QTD_RX != 0 )
        unsigned char rx[ UART_2_QTD_RX ];
        unsigned int  tam_rx;
        
        unsigned char timeout_rx;
    #endif
} Uart_2;

typedef struct
{
    #if( UART_3_QTD_TX != 0 )
        unsigned char tx[ UART_3_QTD_TX ];

        unsigned int  tam_tx;
        unsigned char contador_tx;
        unsigned char timeout_tx;
    #endif
    
    #if( UART_3_QTD_RX != 0 )
        unsigned char rx[ UART_3_QTD_RX ];
        unsigned int  tam_rx;

        unsigned char timeout_rx;
    #endif
} Uart_3;


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao sistema:
#if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    extern Uart_1 uart_1;
#endif
#if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    extern Uart_2 uart_2;
#endif
#if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    extern Uart_3 uart_3;
#endif


/****************************************************************************************\
 *           		                    Macros                 		                    *
\****************************************************************************************/




/****************************************************************************************\
 *           		                    Prototipagem           		                    *
\****************************************************************************************/

void inicializa_uart( unsigned char uart_sel, unsigned int baud_rate, unsigned char paridade );

void configura_baud_rate_uart( unsigned char uart_sel, unsigned int valor );
void configura_paridade_uart( unsigned char uart_sel, unsigned char paridade );

#if( UART_1_QTD_TX != 0 )
    void tx_byte_uart_1( unsigned char byte );
    void tx_pct_uart_1( void );
    void tx_string_uart_1( unsigned char *str );
    void tx_string_flash_uart_1( const unsigned char *str );
    
    void insere_byte_uart_1( unsigned char byte );
    void insere_bytes_uart_1( unsigned char *bytes, unsigned int total_bytes );
    void insere_bytes_flash_uart_1( const unsigned char *bytes, unsigned int total_bytes );
    
    void insere_string_uart_1( unsigned char *str );
    void insere_string_flash_uart_1( const unsigned char *str );
#endif
inline void rts_on_uart_1( void );
inline void rts_off_uart_1( void );
inline unsigned char cts_uart_1( void );

#if( UART_2_QTD_TX != 0 )
    void tx_byte_uart_2( unsigned char byte );
    void tx_pct_uart_2( void );
    void tx_string_uart_2( unsigned char *str );
    void tx_string_flash_uart_2( const unsigned char *str );
    
    void insere_byte_uart_2( unsigned char byte );
    void insere_bytes_uart_2( unsigned char *bytes, unsigned int total_bytes );
    void insere_bytes_flash_uart_2( const unsigned char *bytes, unsigned int total_bytes );
    
    void insere_string_uart_2( unsigned char *str );
    void insere_string_flash_uart_2( const unsigned char *str );
#endif
    
inline void rts_on_uart_2( void );
inline void rts_off_uart_2( void );
inline unsigned char cts_uart_2( void );

#if( UART_3_QTD_TX != 0 )
    void tx_byte_uart_3( unsigned char byte );
    void tx_pct_uart_3( void );
    void tx_string_uart_3( unsigned char *str );
    void tx_string_flash_uart_3( const unsigned char *str );

    void insere_byte_uart_3( unsigned char byte );
    void insere_bytes_uart_3( unsigned char *bytes, unsigned int total_bytes );
    void insere_bytes_flash_uart_3( const unsigned char *bytes, unsigned int total_bytes );

    void insere_string_uart_3( unsigned char *str );
    void insere_string_flash_uart_3( const unsigned char *str );
#endif

inline void rts_on_uart_3( void );
inline void rts_off_uart_3( void );
inline unsigned char cts_uart_3( void );

inline void trata_uart( void );

#if( UART_1_QTD_TX != 0 )
    inline void testa_tx_pct_uart_1( void );
#endif
#if( UART_2_QTD_TX != 0 )
    inline void testa_tx_pct_uart_2( void );
#endif
#if( UART_3_QTD_TX != 0 )
    inline void testa_tx_pct_uart_3( void );
#endif

#if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    inline void testa_timeout_tx_rx_uart_1( void );
#endif
#if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    inline void testa_timeout_tx_rx_uart_2( void );
#endif
#if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    inline void testa_timeout_tx_rx_uart_3( void );
#endif

#define tx_string_flash_porta_serial( s )       tx_string_flash_uart_1( s )
#define tx_string_porta_serial( s )             tx_string_uart_1( s )
#define tx_byte_porta_serial( b )               tx_byte_uart_1( b )

#define insere_byte_porta_serial( b )           insere_byte_uart_1( b )
#define insere_string_flash_porta_serial( s )   insere_string_flash_uart_1( s )
#define insere_string_porta_serial( s )         insere_string_uart_1( s )
#define tx_pacote_porta_serial()                tx_pct_uart_1()

#define PORTA_SERIAL_QTD_TX                     UART_1_QTD_TX
#define PORTA_SERIAL_QTD_RX                     UART_1_QTD_RX
#define F_PORTA_SERIAL_TX                       F_UART_1_TX
#define F_PORTA_SERIAL_PCT_RX                   F_UART_1_PCT_RX
#define PORTA_SERIAL                            UART_1
#define porta_serial                            uart_1
    
#endif // _UART_H_
