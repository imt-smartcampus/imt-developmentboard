/****************************************************************************************\
 * 	                                    M�dulo UART                                   *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "uart.h"                                   // Arquivo de defini��o vari�veis e fun��es do m�dulo UART


/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

union unsigned_int flags_uart;                     // Defini��o de flags do m�dulo UART


/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:


// - Globais ao sistema:



/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned int u1mode;
unsigned int u2mode;
unsigned int u3mode;

// - Globais ao sistema:
#if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    Uart_1 uart_1;
#endif
#if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    Uart_2 uart_2;
#endif

#if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    Uart_3 uart_3;
#endif


/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/




/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/

/****************************************************************************************\
 *                     U1RX Interrupt Service Routine - recep��o serial                 *
 *                                                                                      *
 * Descri��o: Trata a recep��o de dados vindos da serial                                *
 * Prioridade: 4 (intermedi�ria)                                                        *
\****************************************************************************************/
void _ISR_NO_PSV _U1RXInterrupt( void )
{
    #if( UART_1_QTD_RX != 0 )
        volatile unsigned char temp;
    #endif
    
    IFS0bits.U1RXIF = 0;                            // Limpa flag de interrup��o serial
    
    #if( UART_1_QTD_RX != 0 )
        if( ( U1STAbits.FERR ) ||
            ( U1STAbits.PERR ) )    	            // Est� tratando byte recebido ou ocorreu frame error e/ou parity error?
        {                                           // Sim
            U1MODE = 0x0000;                        // UART2 desabilitada
            
            temp = U1RXREG;				            // Despreza os valores recebidos at� ent�o
            temp = U1RXREG;				            // ...
            temp = U1RXREG;				            // ...
            temp = U1RXREG;				            // ...
            
            U1STAbits.FERR = 0;			    		// Limpa flag de frame error
            U1STAbits.OERR = 0;                     // Limpa flag de overrun error
            U1STAbits.PERR = 0;                     // Limpa flag de parity error
            
            // Reconfigura UART1
            U1MODE = u1mode;                        // UART1 habilitada, sem controle de fluxo por hardware (ERRATA: n�o funciona controle de fluxo), BRGH = 1 (4x Baud Clock, Standard mode), 8bits, sem paridade, 1 stop bit
            #if( UART_1_QTD_TX == 0 )
                U1STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U1STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U1STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif
            
            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_1 ) )
                    descarta_modbus();
                #endif
            #endif
        }
        else                                        // Recep��o OK
        {
            temp = U1RXREG;                         // L� byte recebido
            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_1 ) )
                    trata_rx_modbus( temp );        // Trata recep��o do modbus
                #else
                    if( uart_1.tam_rx < UART_1_QTD_RX )     // Est� no limite do buffer?
                    {                                       // N�o
                        uart_1.rx[ uart_1.tam_rx ] = temp;  // Insere byte recebido
                        uart_1.tam_rx++;                    // Incrementa o contador de bytes recebidos
                    }
                    
                    if( uart_1.tam_rx == UART_1_QTD_RX )    // Chegou ao limite do buffer?
                    {                                       // Sim
                        F_UART_1_PCT_RX = 1;                // Ent�o informa chegada de novo pacote  
                    }
                #endif
            #else
                if( uart_1.tam_rx < UART_1_QTD_RX )         // Est� no limite do buffer?
                {                                           // N�o
                    uart_1.rx[ uart_1.tam_rx ] = temp;      // Insere byte recebido

                    if ( (uart_1.rx[ uart_1.tam_rx-1 ] == '\r') && (uart_1.rx[ uart_1.tam_rx ] == '\n'))
                    {
                        F_UART_1_PCT_RX = 1;                // Ent�o informa chegada de novo pacote
                    }
                    uart_1.tam_rx++;                        // Incrementa o contador de bytes recebidos
                }
                else if( uart_1.tam_rx == UART_1_QTD_RX )        // Chegou ao limite do buffer?
                {                                           // Sim
                    F_UART_1_PCT_RX = 1;                    // Ent�o informa chegada de novo pacote  
                }
            #endif
            
            if( U1STAbits.OERR )                    // Overrun?
            {                                       // Sim
                U1STAbits.OERR = 0;                 // Limpa o bit de overrun, caso tenha ocorrido, a fim de resetar a FIFO
            }
            
    	    uart_1.timeout_rx = TOUT_RX_1;          // Recarrega timeout de recep��o
        }
    #endif
}


/****************************************************************************************\
 *                     U2RX Interrupt Service Routine - recep��o serial                 *
 *                                                                                      *
 * Descri��o: Trata a recep��o de dados vindos da serial                                *
 * Prioridade: 4 (intermedi�ria)                                                        *
\****************************************************************************************/
void _ISR_NO_PSV _U2RXInterrupt( void )
{
    #if( UART_2_QTD_RX != 0 )
        volatile unsigned char temp;
    #endif

    IFS1bits.U2RXIF = 0;                            // Limpa flag de interrup��o serial

    #if( UART_2_QTD_RX != 0 )
        if( ( U2STAbits.FERR ) ||
            ( U2STAbits.PERR ) )    	            // Est� tratando byte recebido ou ocorreu frame error e/ou parity error?
        {                                           // Sim
            U2MODE = 0x0000;                        // UART2 desabilitada

            temp = U2RXREG;				            // Despreza os valores recebidos at� ent�o
            temp = U2RXREG;				            // ...
            temp = U2RXREG;				            // ...
            temp = U2RXREG;				            // ...

            U2STAbits.FERR = 0;			    		// Limpa flag de frame error
            U2STAbits.OERR = 0;                     // Limpa flag de overrun error
            U2STAbits.PERR = 0;                     // Limpa flag de parity error

            // Reconfigura UART2
            U2MODE = u2mode;                        // UART2 habilitada, sem controle de fluxo por hardware (ERRATA: n�o funciona controle de fluxo), BRGH = 1 (4x Baud Clock, Standard mode), 8bits, sem paridade, 1 stop bit
            #if( UART_2_QTD_TX == 0 )
                U2STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U2STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U2STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif

            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_2 ) )
                    descarta_modbus();
                #endif
            #endif
        }
        else                                        // Recep��o OK
        {
            temp = U2RXREG;                         // L� byte recebido
            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_2 ) )
                    trata_rx_modbus( temp );        // Trata recep��o do modbus
                #else
                    if( uart_2.tam_rx < UART_2_QTD_RX )     // Est� no limite do buffer?
                    {                                       // N�o
                        uart_2.rx[ uart_2.tam_rx ] = temp;  // Insere byte recebido
                        uart_2.tam_rx++;                    // Incrementa o contador de bytes recebidos
                    }

                    if( uart_2.tam_rx == UART_2_QTD_RX )    // Chegou ao limite do buffer?
                    {                                       // Sim
                        F_UART_2_PCT_RX = 1;                // Ent�o informa chegada de novo pacote
                    }
                #endif
            #else
                if( uart_2.tam_rx < UART_2_QTD_RX )         // Est� no limite do buffer?
                {                                           // N�o
                    uart_2.rx[ uart_2.tam_rx ] = temp;      // Insere byte recebido
                    if ( (uart_2.rx[ uart_2.tam_rx-1 ] == '\r') && (uart_2.rx[ uart_2.tam_rx ] == '\n'))
                    {
                        F_UART_2_PCT_RX = 1;                // Ent�o informa chegada de novo pacote
                    }
                    uart_2.tam_rx++;
                }
                else if( uart_2.tam_rx == UART_2_QTD_RX )        // Chegou ao limite do buffer?
                {                                           // Sim
                    F_UART_2_PCT_RX = 1;                    // Ent�o informa chegada de novo pacote
                }
            #endif

            if( U2STAbits.OERR )                    // Overrun?
            {                                       // Sim
                U2STAbits.OERR = 0;                 // Limpa o bit de overrun, caso tenha ocorrido, a fim de resetar a FIFO
            }

    	    uart_2.timeout_rx = TOUT_RX_2;          // Recarrega timeout de recep��o
        }
    #endif
}

/****************************************************************************************\
 *                     U2RX Interrupt Service Routine - recep��o serial                 *
 *                                                                                      *
 * Descri��o: Trata a recep��o de dados vindos da serial                                *
 * Prioridade: 4 (intermedi�ria)                                                        *
\****************************************************************************************/
void _ISR_NO_PSV _U3RXInterrupt( void )
{
    #if( UART_3_QTD_RX != 0 )
        volatile unsigned char temp;
    #endif

    IFS5bits.U3RXIF = 0;                            // Limpa flag de interrup��o serial

    #if( UART_3_QTD_RX != 0 )
        if( ( U3STAbits.FERR ) ||
            ( U3STAbits.PERR ) )    	            // Est� tratando byte recebido ou ocorreu frame error e/ou parity error?
        {                                           // Sim
            U3MODE = 0x0000;                        // UART2 desabilitada

            temp = U3RXREG;				            // Despreza os valores recebidos at� ent�o
            temp = U3RXREG;				            // ...
            temp = U3RXREG;				            // ...
            temp = U3RXREG;				            // ...

            U3STAbits.FERR = 0;			    		// Limpa flag de frame error
            U3STAbits.OERR = 0;                     // Limpa flag de overrun error
            U3STAbits.PERR = 0;                     // Limpa flag de parity error

            // Reconfigura UART3
            U3MODE = u3mode;                        // UART3 habilitada, sem controle de fluxo por hardware (ERRATA: n�o funciona controle de fluxo), BRGH = 1 (4x Baud Clock, Standard mode), 8bits, sem paridade, 1 stop bit
            #if( UART_3_QTD_TX == 0 )
                U3STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U3STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U3STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif

            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_2 ) )
                    descarta_modbus();
                #endif
            #endif
        }
        else                                        // Recep��o OK
        {
            temp = U3RXREG;                         // L� byte recebido
            #if( defined( MOD_MODBUS ) )
                #if( ( TIPO_MODBUS == MODBUS_UART ) && \
                     ( MODBUS_N_UART == UART_3 ) )
                    trata_rx_modbus( temp );        // Trata recep��o do modbus
                #else
                    if( uart_3.tam_rx < UART_3_QTD_RX )     // Est� no limite do buffer?
                    {                                       // N�o
                        uart_3.rx[ uart_3.tam_rx ] = temp;  // Insere byte recebido
                        uart_3.tam_rx++;                    // Incrementa o contador de bytes recebidos
                    }

                    if( uart_3.tam_rx == UART_3_QTD_RX )    // Chegou ao limite do buffer?
                    {                                       // Sim
                        F_UART_3_PCT_RX = 1;                // Ent�o informa chegada de novo pacote
                    }
                #endif
            #else
                if( uart_3.tam_rx < UART_3_QTD_RX )         // Est� no limite do buffer?
                {                                           // N�o
                    uart_3.rx[ uart_3.tam_rx ] = temp;      // Insere byte recebido
                    if ( (uart_3.rx[ uart_3.tam_rx-1 ] == '\r') && (uart_3.rx[ uart_3.tam_rx ] == '\n'))
                    {
                        F_UART_3_PCT_RX = 1;                // Ent�o informa chegada de novo pacote
                    }
                    uart_3.tam_rx++;
                }
                else if( uart_3.tam_rx == UART_3_QTD_RX )        // Chegou ao limite do buffer?
                {                                           // Sim
                    F_UART_3_PCT_RX = 1;                    // Ent�o informa chegada de novo pacote
                }
            #endif

            if( U3STAbits.OERR )                    // Overrun?
            {                                       // Sim
                U3STAbits.OERR = 0;                 // Limpa o bit de overrun, caso tenha ocorrido, a fim de resetar a FIFO
            }

    	    uart_3.timeout_rx = TOUT_RX_2;          // Recarrega timeout de recep��o
        }
    #endif
}


/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/********************************************************************************\
 * inicializa_uart                                                              *
 * Rotina de inicializa��o do UART                                              *
 *                                                                              *
 * Par�metros: UART a ser configurada, �ndice da tabela de baud-rate (BR_...) e *
 *             paridade (PARIDADE_NONE, PARIDADE_EVEN ou PARIDADE_ODD)          *
 * Retorno   : void							                                    *
\********************************************************************************/
void inicializa_uart( unsigned char uart_sel, unsigned int baud_rate, unsigned char paridade )
{
    unsigned char temp;
    
    flags_uart.value = 0;                           // Zera flags do m�dulo UART
    
    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
        if( uart_sel == UART_1 )
        {
            #if( UART_1_QTD_TX != 0 )
                uart_1.tam_tx = 0;                  // Zera vari�veis de transmiss�o do m�dulo UART1
                uart_1.contador_tx = 0;
                uart_1.timeout_tx = 0;
            #endif
            #if( UART_1_QTD_RX != 0 )
                uart_1.tam_rx = 0;                  // Zera vari�veis de recep��o do m�dulo UART1
                uart_1.timeout_rx = 0;
            #endif
            
            U1MODE = 0x2808;                        // UART1 desabilitada, controle de fluxo OFF, high baud-rate ativado, 8bits, sem paridade, 1 stop bit
            #if( UART_1_QTD_TX == 0 )
                U1STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U1STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U1STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif
            
            temp = U1RXREG;                         // Descarta buffer de recep��o
            temp = U1RXREG;
            temp = U1RXREG;
            temp = U1RXREG;
        }
    #endif
    #if( TIPO_UART_1 == CTRL_FLUXO_ON )
        rts_on_uart_1();
    #endif
    
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
        if( uart_sel == UART_2 )
        {
            #if( UART_2_QTD_TX != 0 )
                uart_2.tam_tx = 0;                  // Zera vari�veis de transmiss�o do m�dulo UART2
                uart_2.contador_tx = 0;
                uart_2.timeout_tx = 0;
            #endif
            #if( UART_2_QTD_RX != 0 )
                uart_2.tam_rx = 0;                  // Zera vari�veis de recep��o do m�dulo UART2
                uart_2.timeout_rx = 0;
            #endif
            
            U2MODE = 0x2800;                        // UART2 desabilitada, controle de fluxo OFF, high baud-rate desativado, 8bits, sem paridade, 1 stop bit
            #if( UART_2_QTD_TX == 0 )
                U2STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U2STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U2STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif
            
            temp = U2RXREG;                         // Descarta buffer de recep��o
            temp = U2RXREG;
            temp = U2RXREG;
            temp = U2RXREG;
        }
    #endif
    #if( TIPO_UART_2 == CTRL_FLUXO_ON )
        rts_on_uart_2();
    #endif


    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
        if( uart_sel == UART_3 )
        {
            #if( UART_3_QTD_TX != 0 )
                uart_3.tam_tx = 0;                  // Zera vari�veis de transmiss�o do m�dulo UART2
                uart_3.contador_tx = 0;
                uart_3.timeout_tx = 0;
            #endif
            #if( UART_3_QTD_RX != 0 )
                uart_3.tam_rx = 0;                  // Zera vari�veis de recep��o do m�dulo UART2
                uart_3.timeout_rx = 0;
            #endif

            U3MODE = 0x2800;                        // UART2 desabilitada, controle de fluxo OFF, high baud-rate desativado, 8bits, sem paridade, 1 stop bit
            #if( UART_3_QTD_TX == 0 )
                U2STA = 0x2000;                     // Transmiss�o desabilitada, interrup��o a cada byte recebido
            #else
                U3STA = 0x2400;                     // Transmiss�o habilitada, interrup��o a cada byte recebido
                U3STAbits.UTXEN = 1;                // Habilita transmiss�o
            #endif

            temp = U3RXREG;                         // Descarta buffer de recep��o
            temp = U3RXREG;
            temp = U3RXREG;
            temp = U3RXREG;
        }
    #endif
    #if( TIPO_UART_3 == CTRL_FLUXO_ON )
        rts_on_uart_3();
    #endif

    configura_baud_rate_uart( uart_sel, baud_rate );// Configura baud-rate da UART1
    configura_paridade_uart( uart_sel, paridade );  // Configura paridade da UART1
    
    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
        if( uart_sel == UART_1 )
        {
            IPC2bits.U1RXIP = 4;                    // N�vel de prioridade: 4 (intermedi�ria)
            IFS0bits.U1RXIF = 0;                    // Limpa flag de interrup��o serial
            #if( UART_1_QTD_RX != 0 )
                IEC0bits.U1RXIE = 1;                // Habilita interrup��o serial
            #endif
            
            #if( UART_1_QTD_TX != 0 )               // Limpa buffer de transmiss�o
                delay_ms( 1 );
            #endif
        }
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
        if( uart_sel == UART_2 )
        {
            IPC7bits.U2RXIP = 4;                    // N�vel de prioridade: 4 (intermedi�ria)
            IFS1bits.U2RXIF = 0;                    // Limpa flag de interrup��o serial
            #if( UART_2_QTD_RX != 0 )
                IEC1bits.U2RXIE = 1;                // Habilita interrup��o serial
            #endif
            
            #if( UART_2_QTD_TX != 0 )               // Limpa buffer de transmiss�o
                delay_ms( 1 );
            #endif
        }
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
        if( uart_sel == UART_3 )
        {
            IPC20bits.U3RXIP = 4;                    // N�vel de prioridade: 4 (intermedi�ria)
            IFS5bits.U3RXIF = 0;                    // Limpa flag de interrup��o serial
            #if( UART_3_QTD_RX != 0 )
                IEC5bits.U3RXIE = 1;                // Habilita interrup��o serial
            #endif

            #if( UART_3_QTD_TX != 0 )               // Limpa buffer de transmiss�o
                delay_ms( 1 );
            #endif
        }
    #endif
}


/********************************************************************************\
 * configura_baud_rate_uart     				                                *
 * Rotina de configura��o do baud-rate 			                                *
 *                                                                              *
 * Par�metros: UART a ser configurada e inabela de baud-rate (BR_...)           *
 * Retorno   : void             			                                    *
\********************************************************************************/
void configura_baud_rate_uart( unsigned char uart_sel, unsigned int brg )
{
    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    	if( uart_sel == UART_1 )
    	{
        	U1MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART1
        }
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    	if( uart_sel == UART_2 )
    	{
    		U2MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART2
        }
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    	if( uart_sel == UART_3 )
    	{
    		U3MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART2
        }
    #endif

    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    	if( uart_sel == UART_1 )
    	{
        	U1BRG = brg;                            // Atualiza BRG da UART1
    		U1MODEbits.UARTEN = 1;				    // Habilita UART1
    		
    		u1mode = U1MODE;                        // Salva �ltimo estado do registrador
    	}
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    if( uart_sel == UART_2 )
    {
            U2BRG = brg;                            // Atualiza BRG da UART2
            U2MODEbits.UARTEN = 1;				    // Habilita UART2

            u2mode = U2MODE;                        // Salva �ltimo estado do registrador
    }
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    if( uart_sel == UART_3 )
    {
            U3BRG = brg;                            // Atualiza BRG da UART2
            U3MODEbits.UARTEN = 1;				    // Habilita UART2

            u3mode = U3MODE;                        // Salva �ltimo estado do registrador
    }
    #endif

    if( uart_sel == UART_1 )
    {
    #if( UART_1_QTD_TX == 0 )
        U1STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
    #else
        U1STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
        U1STAbits.UTXEN = 1;                    // Habilita transmiss�o
    #endif
    }
    else if( uart_sel == UART_2 )
    {
    	#if( UART_2_QTD_TX == 0 )
            U2STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
        #else
            U2STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
            U2STAbits.UTXEN = 1;                    // Habilita transmiss�o
        #endif
    }
    else if( uart_sel == UART_3 )
    {
    	#if( UART_3_QTD_TX == 0 )
            U3STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
        #else
            U3STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
            U3STAbits.UTXEN = 1;                    // Habilita transmiss�o
        #endif
    }
}


/********************************************************************************\
 * configura_paridade_uart   					                                *
 * Rotina de configura��o da paridade 			                                *
 *                                                                              *
 * Par�metros: UART a ser configurada e valor da nova paridade                  *
 * Retorno   : void             			                                    *
\********************************************************************************/
void configura_paridade_uart( unsigned char uart_sel, unsigned char paridade )
{
	unsigned int paridade_desejada;
    
    switch( paridade )
    {
    case PARIDADE_NONE:
        paridade_desejada = 0x2808;                  // UART desabilitada, controle de fluxo OFF, high baud-rate desativado, 8bits, sem paridade, 2 stop bit
        break;
        
    case PARIDADE_EVEN:
        paridade_desejada = 0x280A;                  // UART desabilitada, controle de fluxo OFF, high baud-rate desativado, 8bits, paridade even, 1 stop bit
        break;
        
    case PARIDADE_ODD:
        paridade_desejada = 0x280C;                  // UART desabilitada, controle de fluxo OFF, high baud-rate desativado, 8bits, paridade odd, 1 stop bit
        break;
        
    default:
        return;
    }
    
    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    	if( uart_sel == UART_1 )
    	{
        	U1MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART1
        }
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    	if( uart_sel == UART_2 )
    	{
    		U2MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART2
        }
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    	if( uart_sel == UART_3 )
    	{
    		U3MODEbits.UARTEN = 0;                  // Desabilita m�dulo UART3
        }
    #endif

    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
    if( uart_sel == UART_1 )
    {
            U1MODE = paridade_desejada;             // Atualiza paridade da UART1
            U1MODEbits.UARTEN = 1;				    // Habilita UART1

            u1mode = U1MODE;                        // Salva �ltimo estado do registrador
    }
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
    if( uart_sel == UART_2 )
    {
            U2MODE = paridade_desejada;             // Atualiza paridade da UART2
            U2MODEbits.UARTEN = 1;				    // Habilita UART2

            u2mode = U2MODE;                        // Salva �ltimo estado do registrador
    }
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
    if( uart_sel == UART_3 )
    {
            U3MODE = paridade_desejada;             // Atualiza paridade da UART3
            U3MODEbits.UARTEN = 1;				    // Habilita UART3

            u3mode = U3MODE;                        // Salva �ltimo estado do registrador
    }
    #endif
    if( uart_sel == UART_1 )
    {
    	#if( UART_1_QTD_TX == 0 )
            U1STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
        #else
            U1STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
            U1STAbits.UTXEN = 1;                    // Habilita transmiss�o
        #endif
    }
    else if( uart_sel == UART_2 )
    {
    	#if( UART_2_QTD_TX == 0 )
            U2STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
        #else
            U2STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
            U2STAbits.UTXEN = 1;                    // Habilita transmiss�o
        #endif
    }
    else if( uart_sel == UART_3 )
    {
    	#if( UART_3_QTD_TX == 0 )
            U3STA = 0x2000;                         // Transmiss�o desabilitada, interrup��o a cada byte recebido
        #else
            U3STA = 0x2400;                         // Transmiss�o habilitada, interrup��o a cada byte recebido
            U3STAbits.UTXEN = 1;                    // Habilita transmiss�o
        #endif
    }
}


/********************************************************************************\
 * tx_byte_uart_1       						                                *
 * Rotina para transmitir dados pelo primeiro canal da serial                   *
 *                                                                              *
 * Par�metros: byte a transmitir                                                *
 * Retorno   : void							                                    *
\********************************************************************************/
void tx_byte_uart_1( unsigned char byte )
{
    #if( TIPO_UART_1 == CTRL_FLUXO_ON )
    volatile unsigned int vezes_cts = 5000;
    #endif
    
    #if( UART_1_QTD_TX != 0 )
        #if( TIPO_UART_1 == CTRL_FLUXO_ON )
            rts_on_uart_1();                        // Envia Request-To-Send ao DCE
            while( !cts_uart_1() )                  // Aguarda Clear-To-Send do DCE
            {
                vezes_cts--;
                if( vezes_cts )
                {
                    delay_us( 1 );
                }
                else
                {
                    return;
                }
            }
        #endif
                                      // ...
        U1STAbits.UTXEN = 1;                        // Transmite o dado via serial
     	U1TXREG = byte;				                // Carrega transmiss�o
        Nop();
        Nop();
        Nop();
        while( !U1STAbits.TRMT )                    // Aguarda fim da transmiss�o
     	    ;                                       // ...
  	#endif
}


/****************************************************************************************\
 * tx_pct_uart_1                                                                        *
 * Rotina de transmiss�o de pacote de bytes, via UART1                                  *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_pct_uart_1( void )
{
    #if( UART_1_QTD_TX != 0 )
        F_UART_1_INI_TX = 1;
    #endif
}


/****************************************************************************************\
 * tx_string_uart_1                                                                     *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de dados, via UART1 *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_uart_1( unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_1_QTD_TX != 0 )
            tx_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * tx_string_flash_uart_1                                                               *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de programa, via    *
 * UART1                                                                                *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_flash_uart_1( const unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_1_QTD_TX != 0 )
            tx_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_byte_uart_1                                                                   *
 * Rotina de inser��o de um byte no buffer de transmiss�o da UART1                      *
 *                                                                                      *
 * Par�metros: byte a ser enviado                                                       *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_byte_uart_1( unsigned char byte )
{
    #if( UART_1_QTD_TX != 0 )
        if( uart_1.tam_tx < UART_1_QTD_TX )
        {
            uart_1.tx[ uart_1.tam_tx++ ] = byte;
        }
    #endif
}


/****************************************************************************************\
 * insere_bytes_uart_1                                                                  *
 * Rotina de inser��o no buffer de transmiss�o da UART1 de bytes armazenados em mem�ria *
 * de dados                                                                             *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_uart_1( unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;
    
    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_1_QTD_TX != 0 )
            insere_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_bytes_flash_uart_1                                                            *
 * Rotina de inser��o no buffer de transmiss�o da UART1 de bytes armazenados em mem�ria *
 * de programa                                                                          *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_flash_uart_1( const unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;
    
    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_1_QTD_TX != 0 )
            insere_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_uart_1                                                                 *
 * Rotina de inser��o no buffer de transmiss�o da UART1 de uma string armazenada em me- *
 * m�ria de dados                                                                       *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_uart_1( unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_1_QTD_TX != 0 )
            insere_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_flash_uart_1                                                           *
 * Rotina de inser��o no buffer de transmiss�o da UART1 de uma string armazenada em me- *
 * m�ria de programa                                                                    *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_flash_uart_1( const unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_1_QTD_TX != 0 )
            insere_byte_uart_1( c );
        #endif
    }
}


/****************************************************************************************\
 * rts_on_uart_1                                                                        *
 * Rotina para requisitar ao DCE um pedido de transmiss�o pela UART 1 ou para sinalizar *
 * ao DCE que est� apto a receber um dado                                               *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_on_uart_1( void )
{
    #if( TIPO_UART_1 == CTRL_FLUXO_ON )
        UART_1_RTS = 0;
        F_UART_1_RTS = 1;
    #endif
}


/****************************************************************************************\
 * rts_off_uart_1                                                                       *
 * Rotina para sinalizar ao DCE que N�O est� apto a receber um dado                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_off_uart_1( void )
{
    #if( TIPO_UART_1 == CTRL_FLUXO_ON )
        UART_1_RTS = 1;
        F_UART_1_RTS = 0;
    #endif
}


/****************************************************************************************\
 * cts_uart_1                                                                           *
 * Rotina para verificar se o DCE est� ou n�o apto a receber um dado. Usado geralmente  *
 * ap�s um request-to-send                                                              *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : 1 caso DCE esteja apto a receber um dado, 0 caso contr�rio               *
\****************************************************************************************/
inline unsigned char cts_uart_1( void )
{
    #if( TIPO_UART_1 == CTRL_FLUXO_ON )
        return( !UART_1_CTS );
    #else
        return( 1 );
    #endif
}


/********************************************************************************\
 * tx_byte_uart_2       						                                *
 * Rotina para transmitir dados pelo segundo canal da serial                    *
 *                                                                              *
 * Par�metros: byte a transmitir                                                *
 * Retorno   : void							                                    *
\********************************************************************************/
void tx_byte_uart_2( unsigned char byte )
{
    #if( TIPO_UART_2 == CTRL_FLUXO_ON )
    volatile unsigned int vezes_cts = 5000;
    #endif
    
    #if( UART_2_QTD_TX != 0 )
        #if( TIPO_UART_2 == CTRL_FLUXO_ON )
            rts_on_uart_2();                        // Envia Request-To-Send ao DCE
            while( !cts_uart_2() )                  // Aguarda Clear-To-Send do DCE
            {
                vezes_cts--;
                if( vezes_cts )
                {
                    delay_us( 1 );
                }
                else
                {
                    return;
                }
            }
        #endif
    	
        U2STAbits.UTXEN = 1;                        // Transmite o dado via serial
        U2TXREG = byte;				                // Carrega transmiss�o
        
        while( !U2STAbits.TRMT )                    // Aguarda fim da transmiss�o
    	    ;                                       // ...
    #endif
}


/****************************************************************************************\
 * tx_pct_uart_2                                                                        *
 * Rotina de transmiss�o de pacote de bytes, via UART2                                  *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_pct_uart_2( void )
{
    #if( UART_2_QTD_TX != 0 )
        F_UART_2_INI_TX = 1;
    #endif
}


/****************************************************************************************\
 * tx_string_uart_2                                                                     *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de dados, via UART2 *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_uart_2( unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_2_QTD_TX != 0 )
            tx_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * tx_string_flash_uart_2                                                               *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de programa, via    *
 * UART2                                                                                *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_flash_uart_2( const unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_2_QTD_TX != 0 )
            tx_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_byte_uart_2                                                                   *
 * Rotina de inser��o de um byte no buffer de transmiss�o da UART2                      *
 *                                                                                      *
 * Par�metros: byte a ser enviado                                                       *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_byte_uart_2( unsigned char byte )
{
    #if( UART_2_QTD_TX != 0 )
        if( uart_2.tam_tx < UART_2_QTD_TX )
        {
            uart_2.tx[ uart_2.tam_tx++ ] = byte;
        }
    #endif
}


/****************************************************************************************\
 * insere_bytes_uart_2                                                                  *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de bytes armazenados em mem�ria *
 * de dados                                                                             *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_uart_2( unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;
    
    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_2_QTD_TX != 0 )
            insere_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_bytes_flash_uart_2                                                            *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de bytes armazenados em mem�ria *
 * de programa                                                                          *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_flash_uart_2( const unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;
    
    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_2_QTD_TX != 0 )
            insere_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_uart_2                                                                 *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de uma string armazenada em me- *
 * m�ria de dados                                                                       *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_uart_2( unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_2_QTD_TX != 0 )
            insere_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_flash_uart_2                                                           *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de uma string armazenada em me- *
 * m�ria de programa                                                                    *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_flash_uart_2( const unsigned char *str )
{
    unsigned char c;
    
    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_2_QTD_TX != 0 )
            insere_byte_uart_2( c );
        #endif
    }
}


/****************************************************************************************\
 * rts_on_uart_2                                                                        *
 * Rotina para requisitar ao DCE um pedido de transmiss�o pela UART 2 ou para sinalizar *
 * ao DCE que est� apto a receber um dado                                               *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_on_uart_2( void )
{
    #if( TIPO_UART_2 == CTRL_FLUXO_ON )
        UART_2_RTS = 0;
        F_UART_2_RTS = 0;
    #endif
}


/****************************************************************************************\
 * rts_off_uart_2                                                                       *
 * Rotina para sinalizar ao DCE que N�O est� apto a receber um dado                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_off_uart_2( void )
{
    #if( TIPO_UART_2 == CTRL_FLUXO_ON )
        UART_2_RTS = 1;
        F_UART_2_RTS = 1;
    #endif
}


/****************************************************************************************\
 * cts_uart_2                                                                           *
 * Rotina para verificar se o DCE est� ou n�o apto a receber um dado. Usado geralmente  *
 * ap�s um request-to-send                                                              *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : 1 caso DCE esteja apto a receber um dado, 0 caso contr�rio               *
\****************************************************************************************/
inline unsigned char cts_uart_2( void )
{
    #if( TIPO_UART_2 == CTRL_FLUXO_ON )
        return( !UART_2_CTS );
    #else
        return( 1 );
    #endif
}

// uart3


/********************************************************************************\
 * tx_byte_uart_3       						                                *
 * Rotina para transmitir dados pelo segundo canal da serial                    *
 *                                                                              *
 * Par�metros: byte a transmitir                                                *
 * Retorno   : void							                                    *
\********************************************************************************/
void tx_byte_uart_3( unsigned char byte )
{
    #if( TIPO_UART_3 == CTRL_FLUXO_ON )
    volatile unsigned int vezes_cts = 5000;
    #endif

    #if( UART_3_QTD_TX != 0 )
        #if( TIPO_UART_3 == CTRL_FLUXO_ON )
            rts_on_uart_3();                        // Envia Request-To-Send ao DCE
            while( !cts_uart_3() )                  // Aguarda Clear-To-Send do DCE
            {
                vezes_cts--;
                if( vezes_cts )
                {
                    delay_us( 1 );
                }
                else
                {
                    return;
                }
            }
        #endif

        U3STAbits.UTXEN = 1;                        // Transmite o dado via serial
        U3TXREG = byte;				                // Carrega transmiss�o

        while( !U3STAbits.TRMT )                    // Aguarda fim da transmiss�o
    	    ;                                       // ...
    #endif
}


/****************************************************************************************\
 * tx_pct_uart_2                                                                        *
 * Rotina de transmiss�o de pacote de bytes, via UART2                                  *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_pct_uart_3( void )
{
    #if( UART_3_QTD_TX != 0 )
        F_UART_3_INI_TX = 1;
    #endif
}


/****************************************************************************************\
 * tx_string_uart_3                                                                     *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de dados, via UART2 *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_uart_3( unsigned char *str )
{
    unsigned char c;

    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_3_QTD_TX != 0 )
            tx_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * tx_string_flash_uart_2                                                               *
 * Rotina de transmiss�o direta de uma string armazenada em mem�ria de programa, via    *
 * UART2                                                                                *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void tx_string_flash_uart_3( const unsigned char *str )
{
    unsigned char c;

    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_3_QTD_TX != 0 )
            tx_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_byte_uart_2                                                                   *
 * Rotina de inser��o de um byte no buffer de transmiss�o da UART2                      *
 *                                                                                      *
 * Par�metros: byte a ser enviado                                                       *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_byte_uart_3( unsigned char byte )
{
    #if( UART_3_QTD_TX != 0 )
        if( uart_3.tam_tx < UART_3_QTD_TX )
        {
            uart_3.tx[ uart_3.tam_tx++ ] = byte;
        }
    #endif
}


/****************************************************************************************\
 * insere_bytes_uart_3                                                                  *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de bytes armazenados em mem�ria *
 * de dados                                                                             *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_uart_3( unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;

    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_3_QTD_TX != 0 )
            insere_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_bytes_flash_uart_3                                                            *
 * Rotina de inser��o no buffer de transmiss�o da UART3 de bytes armazenados em mem�ria *
 * de programa                                                                          *
 *                                                                                      *
 * Par�metros: buffer com os bytes a serem enviados e total de bytes                    *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_bytes_flash_uart_3( const unsigned char *bytes, unsigned int total_bytes )
{
    unsigned char c;

    while( total_bytes-- )
    {
        c = *bytes++;
        #if( UART_3_QTD_TX != 0 )
            insere_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_uart_3                                                                 *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de uma string armazenada em me- *
 * m�ria de dados                                                                       *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_uart_3( unsigned char *str )
{
    unsigned char c;

    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_3_QTD_TX != 0 )
            insere_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * insere_string_flash_uart_3                                                           *
 * Rotina de inser��o no buffer de transmiss�o da UART2 de uma string armazenada em me- *
 * m�ria de programa                                                                    *
 *                                                                                      *
 * Par�metros: string a ser enviada                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void insere_string_flash_uart_3( const unsigned char *str )
{
    unsigned char c;

    while( ( c = *str++ ) != '\0' )
    {
        #if( UART_3_QTD_TX != 0 )
            insere_byte_uart_3( c );
        #endif
    }
}


/****************************************************************************************\
 * rts_on_uart_2                                                                        *
 * Rotina para requisitar ao DCE um pedido de transmiss�o pela UART 2 ou para sinalizar *
 * ao DCE que est� apto a receber um dado                                               *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_on_uart_3( void )
{
    #if( TIPO_UART_3 == CTRL_FLUXO_ON )
        UART_3_RTS = 0;
        F_UART_3_RTS = 0;
    #endif
}


/****************************************************************************************\
 * rts_off_uart_3                                                                       *
 * Rotina para sinalizar ao DCE que N�O est� apto a receber um dado                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void rts_off_uart_3( void )
{
    #if( TIPO_UART_3 == CTRL_FLUXO_ON )
        UART_3_RTS = 1;
        F_UART_3_RTS = 1;
    #endif
}


/****************************************************************************************\
 * cts_uart_3                                                                           *
 * Rotina para verificar se o DCE est� ou n�o apto a receber um dado. Usado geralmente  *
 * ap�s um request-to-send                                                              *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : 1 caso DCE esteja apto a receber um dado, 0 caso contr�rio               *
\****************************************************************************************/
inline unsigned char cts_uart_3( void )
{
    #if( TIPO_UART_3 == CTRL_FLUXO_ON )
        return( !UART_3_CTS );
    #else
        return( 1 );
    #endif
}

/****************************************************************************************\
 * trata_uart                                                                           *
 * Rotina para enviar pacotes de dados pelas seriais e testar timeouts de transmiss�o e *
 * recep��o                                                                             *
 * Esta rotina deve ser chamada em uma base de tempo de 1ms                             *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void             			                                            *
\****************************************************************************************/
inline void trata_uart( void )
{
    #if( UART_1_QTD_TX != 0 )
        testa_tx_pct_uart_1();
    #endif
    #if( UART_2_QTD_TX != 0 )
        testa_tx_pct_uart_2();
    #endif
    #if( UART_3_QTD_TX != 0 )
        testa_tx_pct_uart_3();
    #endif

    #if( ( UART_1_QTD_TX != 0 ) || ( UART_1_QTD_RX != 0 ) )
        testa_timeout_tx_rx_uart_1();
    #endif
    #if( ( UART_2_QTD_TX != 0 ) || ( UART_2_QTD_RX != 0 ) )
        testa_timeout_tx_rx_uart_2();
    #endif
    #if( ( UART_3_QTD_TX != 0 ) || ( UART_3_QTD_RX != 0 ) )
        testa_timeout_tx_rx_uart_3();
    #endif
}


/****************************************************************************************\
 * testa_tx_pct_uart_1                                                                  *
 * Rotina que efetivamente realiza a transmiss�o do pacote via UART1                    *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
inline void testa_tx_pct_uart_1( void )
{
    #if( UART_1_QTD_TX != 0 )
        if( F_UART_1_INI_TX )                       // Solicita��o de in�cio de transmiss�o de pacote?
        {                                           // Sim
            F_UART_1_INI_TX = 0;                    // Zera flag
            F_UART_1_TX     = 1;                    // Sinaliza que est� enviando
            
            uart_1.contador_tx = 0;                 // Zera contador de bytes j� transmitidos
        }
        
        if( F_UART_1_TX )                           // Transmitindo?
        {                                           // Sim
            if( uart_1.contador_tx < uart_1.tam_tx )// H� bytes para transmitir?
            {                                       // Sim
                tx_byte_uart_1( uart_1.tx[ uart_1.contador_tx++ ] ); // Transmite byte atual
            }
            else                                    // H� bytes para transmitir?
            {                                       // N�o
                F_UART_1_TX = 0;                    // Sinaliza fim de transmiss�o
                
                uart_1.tam_tx = 0;                  // Zera pacote de transmiss�o
            }
        }
    #endif
}


/****************************************************************************************\
 * testa_timeout_tx_rx_uart_1                                                           *
 * Rotina para verificar se h� um novo pacote no buffer de recep��o e, se estiver trans-*
 * mitindo, conta tempo (usado para controle de fluxo por software)                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void testa_timeout_tx_rx_uart_1( void )
{
    #if( UART_1_QTD_TX != 0 )
        if( uart_1.timeout_tx )                     // Decrementa timeout de transmiss�o serial
            uart_1.timeout_tx--;                    // ...
    #endif
    
    #if( UART_1_QTD_RX != 0 )
        if( !F_UART_1_PCT_RX )                      // Tratando buffer recebido?
        {                                           // N�o
            #if( TIPO_UART_1 == CTRL_FLUXO_ON )     // H� controle de fluxo?
                if( !F_UART_1_RTS )                 // Sim. Est� pronto para receber?
                {                                   // N�o
                    return;                         // Ent�o retorna
                }
            #endif
            
            if( uart_1.tam_rx > 0 )                 // Algum byte no buffer?
            {                                       // Sim
                uart_1.timeout_rx--;                // Conta tempo para fim de pacote
                if( !uart_1.timeout_rx )            // Tempo de espera por fim pacote chegou ao final?
                {                                   // Sim
                    F_UART_1_PCT_RX = 1;            // Informa novo pacote recebido, para ser tratado
                }
            }
        }
    #endif
}


/****************************************************************************************\
 * testa_tx_pct_uart_2                                                                  *
 * Rotina que efetivamente realiza a transmiss�o do pacote via UART2                    *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
inline void testa_tx_pct_uart_2( void )
{
    #if( UART_2_QTD_TX != 0 )
        if( F_UART_2_INI_TX )                       // Solicita��o de in�cio de transmiss�o de pacote?
        {                                           // Sim
            F_UART_2_INI_TX = 0;                    // Zera flag
            F_UART_2_TX     = 1;                    // Sinaliza que est� enviando
            
            uart_2.contador_tx = 0;                 // Zera contador de bytes j� transmitidos
        }
        
        if( F_UART_2_TX )                           // Transmitindo?
        {                                           // Sim
            if( uart_2.contador_tx < uart_2.tam_tx )// H� bytes para transmitir?
            {                                       // Sim
                tx_byte_uart_2( uart_2.tx[ uart_2.contador_tx++ ] ); // Transmite byte atual
            }
            else                                    // H� bytes para transmitir?
            {                                       // N�o
                F_UART_2_TX = 0;                    // Sinaliza fim de transmiss�o
                
                uart_2.tam_tx = 0;                  // Zera pacote de transmiss�o
            }
        }
    #endif
}


/****************************************************************************************\
 * testa_timeout_tx_rx_uart_2                                                           *
 * Rotina para verificar se h� um novo pacote no buffer de recep��o e, se estiver trans-*
 * mitindo, conta tempo (usado para controle de fluxo por software)                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void testa_timeout_tx_rx_uart_2( void )
{
    #if( UART_2_QTD_TX != 0 )
        if( uart_2.timeout_tx )                     // Decrementa timeout de transmiss�o serial
            uart_2.timeout_tx--;                    // ...
    #endif
    
    #if( UART_2_QTD_RX != 0 )
        if( !F_UART_2_PCT_RX )                      // Tratando buffer recebido?
        {                                           // N�o
            #if( TIPO_UART_2 == CTRL_FLUXO_ON )     // H� controle de fluxo?
                if( !F_UART_2_RTS )                 // Sim. Est� pronto para receber?
                {                                   // N�o
                    return;                         // Ent�o retorna
                }
            #endif
            
            if( uart_2.tam_rx > 0 )                 // Algum byte no buffer?
            {                                       // Sim
                uart_2.timeout_rx--;                // Conta tempo para fim de pacote
                if( !uart_2.timeout_rx )            // Tempo de espera por fim pacote chegou ao final?
                {                                   // Sim
                    F_UART_2_PCT_RX = 1;            // Informa novo pacote recebido, para ser tratado
                }
            }
        }
    #endif
}



/****************************************************************************************\
 * testa_tx_pct_uart_3                                                                  *
 * Rotina que efetivamente realiza a transmiss�o do pacote via UART2                    *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void                                                                     *
\****************************************************************************************/
inline void testa_tx_pct_uart_3( void )
{
    #if( UART_3_QTD_TX != 0 )
        if( F_UART_3_INI_TX )                       // Solicita��o de in�cio de transmiss�o de pacote?
        {                                           // Sim
            F_UART_3_INI_TX = 0;                    // Zera flag
            F_UART_3_TX     = 1;                    // Sinaliza que est� enviando

            uart_3.contador_tx = 0;                 // Zera contador de bytes j� transmitidos
        }

        if( F_UART_3_TX )                           // Transmitindo?
        {                                           // Sim
            if( uart_3.contador_tx < uart_3.tam_tx )// H� bytes para transmitir?
            {                                       // Sim
                tx_byte_uart_3( uart_3.tx[ uart_3.contador_tx++ ] ); // Transmite byte atual
            }
            else                                    // H� bytes para transmitir?
            {                                       // N�o
                F_UART_3_TX = 0;                    // Sinaliza fim de transmiss�o

                uart_3.tam_tx = 0;                  // Zera pacote de transmiss�o
            }
        }
    #endif
}


/****************************************************************************************\
 * testa_timeout_tx_rx_uart_3                                                           *
 * Rotina para verificar se h� um novo pacote no buffer de recep��o e, se estiver trans-*
 * mitindo, conta tempo (usado para controle de fluxo por software)                     *
 *                                                                                      *
 * Par�metros: void							                                            *
 * Retorno   : void							                                            *
\****************************************************************************************/
inline void testa_timeout_tx_rx_uart_3( void )
{
    #if( UART_3_QTD_TX != 0 )
        if( uart_3.timeout_tx )                     // Decrementa timeout de transmiss�o serial
            uart_3.timeout_tx--;                    // ...
    #endif

    #if( UART_3_QTD_RX != 0 )
        if( !F_UART_3_PCT_RX )                      // Tratando buffer recebido?
        {                                           // N�o
            #if( TIPO_UART_3 == CTRL_FLUXO_ON )     // H� controle de fluxo?
                if( !F_UART_3_RTS )                 // Sim. Est� pronto para receber?
                {                                   // N�o
                    return;                         // Ent�o retorna
                }
            #endif

            if( uart_3.tam_rx > 0 )                 // Algum byte no buffer?
            {                                       // Sim
                uart_3.timeout_rx--;                // Conta tempo para fim de pacote
                if( !uart_3.timeout_rx )            // Tempo de espera por fim pacote chegou ao final?
                {                                   // Sim
                    F_UART_3_PCT_RX = 1;            // Informa novo pacote recebido, para ser tratado
                }
            }
        }
    #endif
}


