/****************************************************************************************\
 * 	                               M�dulo SPI master (HW)                               *
 *									                  *
 *       Desenvolvido pelo Centro de Pesquisa do Instituto Mau� de Tecnologia             *
 *									                  *
 *  15/10/16 Fernando Martins - IMT/CP-DET                                                *
 *									                  *
\****************************************************************************************/

#include "spi_master_hw.h"                      // Arquivo de defini��o de vari�veis e fun��es do m�dulo SPI por HW

/****************************************************************************************\
 * 	  	                                Flags do m�dulo                                 *
\****************************************************************************************/

/****************************************************************************************\
 * 	  	            Defini��o de vari�veis do m�dulo em mem�ria de programa          	*
\****************************************************************************************/

// - Globais ao m�dulo:

// - Globais ao sistema:

/****************************************************************************************\
 * 	  	              Defini��o de vari�veis do m�dulo em mem�ria de dados          	*
\****************************************************************************************/

// - Globais ao m�dulo:
unsigned char spi1_hw_iniciada = 0;
unsigned char spi2_hw_iniciada = 0;

// - Globais ao sistema:

/****************************************************************************************\
 * 	  	                            Fun��es est�ticas                                  	*
\****************************************************************************************/

/****************************************************************************************\
 *                                Vetores de interrup��o    	                        *
\****************************************************************************************/

/****************************************************************************************\
 *           		             Implementa��o das fun��es  		                    *
\****************************************************************************************/

/****************************************************************************************\
 * inicializa_spi1_master_hw                                                            *
 * Rotina de inicializa��o do m�dulo SPI master por HW                                  *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void               			                                            *
\****************************************************************************************/
void inicializa_spi1_master_hw( void )
{
    if( !spi1_hw_iniciada )                         // M�dulo j� iniciado?
    {                                               // N�o. Ent�o inicializa
        SPI1BUF  = 0x0000;                          // Zera buffer SPI

        SPI1STAT = 0x2000;                          // SPI desativada
        SPI1CON1 = 0x0000;                          // ...
        SPI1CON2 = 0x0000;                          // Modo Framed desativado
        SPI1STATbits.SPIROV = 0;                    // Limpa flag de overflow
        SPI1CON1bits.PPRE   = 1;                    // FOSC = 80MHz
        SPI1CON1bits.SPRE   = 3;                    // 1MHz
        SPI1CON1bits.DISSCK = 0;                    // SCK utilizado pelo m�dulo SPI
        SPI1CON1bits.DISSDO = 0;                    // SDO utilizado pelo m�dulo SPI
        SPI1CON1bits.MODE16 = 0;                    // 8 bits
        SPI1CON1bits.SMP    = 1;                    // Dados de entrada s�o amostrados no meio do bit
        SPI1CON1bits.CKE    = 0;                    // Dado enviado na borda de subida
        SPI1CON1bits.CKP    = 1;                    // Repouso em n�vel '0'
        SPI1CON1bits.MSTEN  = 1;                    // Habilita modo master
        SPI1STATbits.SPIEN  = 1;                    // Habilita m�dulo SPI

        spi1_hw_iniciada = 1;                       // Informa que SPI foi inicializada
    }
}

/****************************************************************************************\
 * le_byte_spi1_master_hw                                                               *
 * Rotina de leitura do buffer da SPI master por HW                                     *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : retorna dado lido                                                        *
\****************************************************************************************/
unsigned char le_byte_spi1_master_hw( void )
{
    return( SPI1BUF );                              // Retorna o dado lido do buffer
}

/****************************************************************************************\
 * escreve_byte_spi1_master_hw                                                          *
 * Rotina de escrita no buffer da SPI master por HW                                     *
 *                                                                                      *
 * Par�metros: dado a escrever                                                          *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_byte_spi1_master_hw( unsigned char dado )
{
    unsigned char temp;

    IFS0bits.SPI1IF = 0;                            // Limpa flag de interrup��o de fim de transmiss�o

    temp = SPI1BUF;                                 // L� dado presente no buffer (impede overflow)
    SPI1BUF = dado;                                 // Envia o dado para o buffer

    while( !IFS0bits.SPI1IF )                       // Aguarda buffer de transmiss�o esvaziar
        ;
}

/****************************************************************************************\
 * inicializa_spi2_master_hw                                                            *
 * Rotina de inicializa��o do m�dulo SPI master por HW                                  *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : void               			                                            *
\****************************************************************************************/
void inicializa_spi2_master_hw( void )
{
    if( !spi2_hw_iniciada )                         // M�dulo j� iniciado?
    {                                               // N�o. Ent�o inicializa
        SPI2BUF  = 0x0000;                          // Zera buffer SPI

        SPI2STAT = 0x2000;                          // SPI desativada
        SPI2CON1 = 0x0000;                          // ...
        SPI2CON2 = 0x0000;                          // Modo Framed desativado
        SPI2STATbits.SPIROV = 0;                    // Limpa flag de overflow
        SPI2CON1bits.PPRE   = 3;                    // FOSC = 80MHz
        SPI2CON1bits.SPRE   = 4;                    // 100kHz
        SPI2CON1bits.DISSCK = 0;                    // SCK utilizado pelo m�dulo SPI
        SPI2CON1bits.DISSDO = 0;                    // SDO utilizado pelo m�dulo SPI
        SPI2CON1bits.MODE16 = 0;                    // 8 bits
        SPI2CON1bits.SMP    = 1;                    // Dados de entrada s�o amostrados no meio do bit
        SPI2CON1bits.CKE    = 1;                    // Dado enviado na borda de subida
        SPI2CON1bits.CKP    = 0;                    // Repouso em n�vel '0'
        SPI2CON1bits.MSTEN  = 1;                    // Habilita modo master
        SPI2STATbits.SPIEN  = 1;                    // Habilita m�dulo SPI

        spi2_hw_iniciada = 1;                       // Informa que SPI foi inicializada
    }
}

/****************************************************************************************\
 * le_byte_spi2_master_hw                                                               *
 * Rotina de leitura do buffer da SPI master por HW                                     *
 *                                                                                      *
 * Par�metros: void                                                                     *
 * Retorno   : retorna dado lido                                                        *
\****************************************************************************************/
unsigned char le_byte_spi2_master_hw( void )
{
    return( SPI2BUF );                              // Retorna o dado lido do buffer
}

/****************************************************************************************\
 * escreve_byte_spi2_master_hw                                                          *
 * Rotina de escrita no buffer da SPI master por HW                                     *
 *                                                                                      *
 * Par�metros: dado a escrever                                                          *
 * Retorno   : void                                                                     *
\****************************************************************************************/
void escreve_byte_spi2_master_hw( unsigned char dado )
{
    unsigned char temp;

    IFS2bits.SPI2IF = 0;                            // Limpa flag de interrup��o de fim de transmiss�o

    temp = SPI2BUF;                                 // L� dado presente no buffer (impede overflow)
    SPI2BUF = dado;                                 // Envia o dado para o buffer

    while( !IFS2bits.SPI2IF )                       // Aguarda buffer de transmiss�o esvaziar
        ;
}
